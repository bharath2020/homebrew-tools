"""Request simulation rules for Jaala."""

from __future__ import annotations

import os
from dataclasses import dataclass
from collections.abc import Callable, Mapping

from .filtering import build_matcher, load_merged_config

ENV_CONFIG = "JAALA_CONFIG"

REQUEST_KEYS = ("request_header", "request_body_replace")
RUNTIME_REQUEST_RULES_KEY = "_jaala_runtime_request_rules"


def _normalize(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _split_once(value: str, separator: str, label: str) -> tuple[str, str]:
    left, found, right = value.partition(separator)
    if not found or not left.strip() or not right.strip():
        raise ValueError(f"Invalid {label} rule {value!r}")
    return left.strip(), right.strip()


def _content_bytes(content: bytes | bytearray | memoryview | None) -> bytes:
    if content is None:
        return b""
    if isinstance(content, bytes):
        return content
    if isinstance(content, bytearray):
        return bytes(content)
    if isinstance(content, memoryview):
        return content.tobytes()
    return bytes(content)


def _decode_body(content: bytes | bytearray | memoryview | None) -> str | None:
    data = _content_bytes(content)
    if not data:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _set_header(headers, name: str, value: str) -> None:
    headers[name] = value


@dataclass(slots=True)
class RequestRuleSet:
    request_header: tuple[Callable[[str], bool], tuple[str, str]] | None = None
    request_body_replace: tuple[Callable[[str], bool], tuple[str, str]] | None = None

    def _url(self, flow) -> str:
        return getattr(flow.request, "pretty_url", "")

    def _apply_request_body_replace(self, flow) -> bool:
        if self.request_body_replace is None:
            return False

        matcher, (search, replace) = self.request_body_replace
        if not matcher(self._url(flow)):
            return False

        request = flow.request
        text = _decode_body(getattr(request, "content", None))
        if text is None or search not in text:
            return False

        new_text = text.replace(search, replace)
        request.content = new_text.encode("utf-8")
        try:
            _set_header(request.headers, "content-length", str(len(request.content)))
        except Exception:
            pass
        return True

    def _apply_request_header(self, flow) -> bool:
        if self.request_header is None:
            return False

        matcher, (name, value) = self.request_header
        if not matcher(self._url(flow)):
            return False

        _set_header(flow.request.headers, name, value)
        return True

    def apply_request(self, flow) -> bool:
        mutated = False
        mutated |= self._apply_request_header(flow)
        mutated |= self._apply_request_body_replace(flow)
        return mutated


def _runtime_request_rules(settings: Mapping[str, object]) -> list[dict[str, object]]:
    raw_rules = settings.get(RUNTIME_REQUEST_RULES_KEY)
    if not isinstance(raw_rules, list):
        return []
    return [rule for rule in raw_rules if isinstance(rule, dict)]


def _active_runtime_request_rule(
    settings: Mapping[str, object],
    rule_type: str,
) -> dict[str, object] | None:
    active: dict[str, object] | None = None
    for rule in _runtime_request_rules(settings):
        if rule.get("type") != rule_type or not rule.get("enabled", True):
            continue
        active = rule
    return active


def build_request_rules(settings: Mapping[str, object] | None = None) -> RequestRuleSet:
    settings = settings or {}

    request_header = _normalize(settings.get("request_header"))
    request_body_replace = _normalize(settings.get("request_body_replace"))

    compiled = RequestRuleSet()

    if request_header is not None:
        pattern, header_text = _split_once(request_header, "=", "request-header")
        matcher = build_matcher(pattern)
        header_name, header_value = _split_once(header_text, ":", "request-header header")
        compiled.request_header = (matcher, (header_name, header_value))

    if request_body_replace is not None:
        pattern, replacement_text = _split_once(request_body_replace, "=", "request-body-replace")
        matcher = build_matcher(pattern)
        search, replace = _split_once(replacement_text, ">>>", "request-body-replace replacement")
        compiled.request_body_replace = (matcher, (search, replace))

    active_request_header = _active_runtime_request_rule(settings, "request_header")
    if active_request_header is not None:
        match_url = _normalize(str(active_request_header.get("match_url", "")))
        header_name = _normalize(str(active_request_header.get("header_name", "")))
        header_value = active_request_header.get("header_value")
        if match_url is None or header_name is None or not isinstance(header_value, str):
            raise ValueError(f"Invalid runtime request_header rule {active_request_header!r}")
        compiled.request_header = (build_matcher(match_url), (header_name, header_value))

    return compiled


def load_request_config(path: str | None, profile: str | None = None) -> dict[str, object]:
    data = load_merged_config(path, profile=profile)

    result: dict[str, object] = {}
    for key in REQUEST_KEYS:
        value = data.get(key)
        if value is None:
            continue
        if not isinstance(value, str):
            raise ValueError(f"Request config {path!r} field {key!r} must be a string")
        normalized = _normalize(value)
        if normalized is not None:
            result[key] = normalized
    runtime_metadata = data.get("_jaala_runtime")
    if isinstance(runtime_metadata, dict):
        rules = runtime_metadata.get("rules")
        if isinstance(rules, list):
            result[RUNTIME_REQUEST_RULES_KEY] = [
                rule
                for rule in rules
                if isinstance(rule, dict) and rule.get("type") in {"request_header"}
            ]
    return result


def resolve_request_settings(
    *,
    config_path: str | None = None,
    config_profile: str | None = None,
    env: Mapping[str, str] | None = None,
    request_header: str | None = None,
    request_body_replace: str | None = None,
) -> dict[str, object]:
    env = env or os.environ
    resolved = load_request_config(config_path or env.get(ENV_CONFIG), profile=config_profile)

    cli_request_header = _normalize(request_header)
    if cli_request_header is not None:
        resolved["request_header"] = cli_request_header

    cli_request_body_replace = _normalize(request_body_replace)
    if cli_request_body_replace is not None:
        resolved["request_body_replace"] = cli_request_body_replace

    return resolved
