from __future__ import annotations

import json

from jaala.runtime_rules import (
    add_body_replace_rule,
    add_json_replace_rule,
    add_request_header_rule,
    build_runtime_http_config,
    list_runtime_rules,
    load_runtime_config,
    normalize_runtime_config,
    remove_runtime_rule,
    set_runtime_rule_enabled,
    write_runtime_config,
)


def test_build_runtime_http_config_promotes_startup_body_replace_into_named_rule():
    config = build_runtime_http_config(
        filter_settings={},
        response_settings={"body_replace": "wikipedia.org=OpenAI>>>JAALA TEMP ITEM"},
        request_settings={},
        network_condition_settings={},
    )

    rules = config["_jaala_runtime"]["rules"]
    assert rules[0]["name"] == "startup-body-replace"
    assert rules[0]["match_url"] == "wikipedia.org"
    assert rules[0]["search"] == "OpenAI"
    assert rules[0]["replace"] == "JAALA TEMP ITEM"


def test_build_runtime_http_config_promotes_startup_json_replace_into_named_rule():
    config = build_runtime_http_config(
        filter_settings={},
        response_settings={
            "json_replace": {
                "match_url": "feed/featured",
                "json_path": "tfa.description",
                "value": "JAALA JSON DEMO",
            }
        },
        request_settings={},
        network_condition_settings={},
    )

    rules = config["_jaala_runtime"]["rules"]
    assert rules[0]["name"] == "startup-json-replace"
    assert rules[0]["type"] == "json_replace"
    assert rules[0]["match_url"] == "feed/featured"
    assert rules[0]["json_path"] == "tfa.description"
    assert rules[0]["value"] == "JAALA JSON DEMO"


def test_add_body_replace_rule_updates_runtime_config_and_legacy_projection(tmp_path):
    runtime_config = tmp_path / "runtime.json"
    write_runtime_config(runtime_config, {"_jaala_runtime": {"rules": []}})

    add_body_replace_rule(
        runtime_config,
        name="wiki-openai-temp",
        match_url="wikipedia.org",
        search="OpenAI",
        replace="JAALA TEMP ITEM",
    )

    config = load_runtime_config(runtime_config)
    assert config["body_replace"] == "wikipedia.org=OpenAI>>>JAALA TEMP ITEM"
    assert list_runtime_rules(runtime_config)[0]["name"] == "wiki-openai-temp"


def test_normalize_runtime_config_uses_latest_enabled_body_replace_rule():
    config = {
        "_jaala_runtime": {
            "rules": [
                {
                    "name": "first",
                    "type": "body_replace",
                    "enabled": True,
                    "match_url": "wikipedia.org",
                    "search": "OpenAI",
                    "replace": "ONE",
                },
                {
                    "name": "second",
                    "type": "body_replace",
                    "enabled": True,
                    "match_url": "wikipedia.org",
                    "search": "OpenAI",
                    "replace": "TWO",
                },
            ]
        }
    }

    normalized = normalize_runtime_config(config)

    assert normalized["body_replace"] == "wikipedia.org=OpenAI>>>TWO"


def test_add_request_header_rule_updates_runtime_config_and_legacy_projection(tmp_path):
    runtime_config = tmp_path / "runtime.json"
    write_runtime_config(runtime_config, {"_jaala_runtime": {"rules": []}})

    add_request_header_rule(
        runtime_config,
        name="wiki-summary-bust-etag",
        match_url="page/summary/OpenAI",
        header_name="If-None-Match",
        header_value='W/"force-miss"',
    )

    config = load_runtime_config(runtime_config)
    assert config["request_header"] == 'page/summary/OpenAI=If-None-Match:W/"force-miss"'
    assert list_runtime_rules(runtime_config)[0]["name"] == "wiki-summary-bust-etag"


def test_add_json_replace_rule_updates_runtime_config_metadata(tmp_path):
    runtime_config = tmp_path / "runtime.json"
    write_runtime_config(runtime_config, {"_jaala_runtime": {"rules": []}})

    add_json_replace_rule(
        runtime_config,
        name="wiki-featured-description",
        match_url="feed/featured",
        json_path="tfa.description",
        value="JAALA JSON DEMO",
    )

    rules = list_runtime_rules(runtime_config)
    assert rules[0]["name"] == "wiki-featured-description"
    assert rules[0]["type"] == "json_replace"
    assert rules[0]["json_path"] == "tfa.description"
    assert rules[0]["value"] == "JAALA JSON DEMO"


def test_write_runtime_config_preserves_startup_json_replace_settings(tmp_path):
    runtime_config = tmp_path / "runtime.json"

    write_runtime_config(
        runtime_config,
        {
            "json_replace": {
                "match_url": "feed/featured",
                "json_path": "tfa.description",
                "value": "JAALA JSON DEMO",
            },
            "_jaala_runtime": {"rules": []},
        },
    )

    config = load_runtime_config(runtime_config)
    assert config["json_replace"] == {
        "match_url": "feed/featured",
        "json_path": "tfa.description",
        "value": "JAALA JSON DEMO",
    }


def test_set_runtime_rule_enabled_preserves_latest_enabled_projection(tmp_path):
    runtime_config = tmp_path / "runtime.json"
    write_runtime_config(
        runtime_config,
        {
            "_jaala_runtime": {
                "rules": [
                    {
                        "name": "first",
                        "type": "body_replace",
                        "enabled": True,
                        "match_url": "wikipedia.org",
                        "search": "OpenAI",
                        "replace": "ONE",
                    },
                    {
                        "name": "second",
                        "type": "body_replace",
                        "enabled": True,
                        "match_url": "wikipedia.org",
                        "search": "OpenAI",
                        "replace": "TWO",
                    },
                ]
            }
        },
    )

    disabled = set_runtime_rule_enabled(runtime_config, name="second", enabled=False)
    assert disabled["body_replace"] == "wikipedia.org=OpenAI>>>ONE"
    assert [rule["enabled"] for rule in list_runtime_rules(runtime_config) if rule["name"] == "second"] == [False]

    enabled = set_runtime_rule_enabled(runtime_config, name="second", enabled=True)
    assert enabled["body_replace"] == "wikipedia.org=OpenAI>>>TWO"


def test_remove_runtime_rule_deletes_named_rule_and_recomputes_projection(tmp_path):
    runtime_config = tmp_path / "runtime.json"
    write_runtime_config(
        runtime_config,
        {
            "_jaala_runtime": {
                "rules": [
                    {
                        "name": "first",
                        "type": "body_replace",
                        "enabled": True,
                        "match_url": "wikipedia.org",
                        "search": "OpenAI",
                        "replace": "ONE",
                    },
                    {
                        "name": "second",
                        "type": "body_replace",
                        "enabled": True,
                        "match_url": "wikipedia.org",
                        "search": "OpenAI",
                        "replace": "TWO",
                    },
                ]
            }
        },
    )

    normalized = remove_runtime_rule(runtime_config, name="second")
    assert normalized["body_replace"] == "wikipedia.org=OpenAI>>>ONE"
    assert [rule["name"] for rule in list_runtime_rules(runtime_config)] == ["first"]
