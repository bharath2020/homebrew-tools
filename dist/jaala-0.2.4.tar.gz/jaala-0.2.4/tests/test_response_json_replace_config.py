from __future__ import annotations

import json

import pytest

from jaala.response_rules import build_response_rules, load_response_config


def test_load_response_config_reads_json_replace_object(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "json_replace": {
                    "match_url": "feed/featured",
                    "json_path": "tfa.description",
                    "value": {"text": "JAALA"},
                }
            }
        ),
        encoding="utf-8",
    )

    config = load_response_config(str(config_path))

    assert config == {
        "json_replace": {
            "match_url": "feed/featured",
            "json_path": "tfa.description",
            "value": {"text": "JAALA"},
        }
    }


def test_load_response_config_rejects_json_replace_without_value(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "json_replace": {
                    "match_url": "feed/featured",
                    "json_path": "tfa.description",
                }
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="requires a 'value'"):
        load_response_config(str(config_path))


def test_build_response_rules_rejects_invalid_startup_json_replace_path():
    with pytest.raises(ValueError, match="Invalid json-replace path"):
        build_response_rules(
            {
                "json_replace": {
                    "match_url": "feed/featured",
                    "json_path": "tfa..description",
                    "value": "JAALA",
                }
            }
        )
