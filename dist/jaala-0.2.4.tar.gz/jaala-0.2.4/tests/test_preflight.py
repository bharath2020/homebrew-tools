"""Tests for preflight checks."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from jaala import preflight


class TestCheckMitmdump:
    @patch("shutil.which", return_value="/usr/local/bin/mitmdump")
    def test_found(self, mock_which):
        preflight.check_mitmdump()

    @patch("shutil.which", return_value=None)
    def test_not_found_exits(self, mock_which):
        with pytest.raises(SystemExit):
            preflight.check_mitmdump()


class TestCheckXcrun:
    @patch("subprocess.run")
    @patch("shutil.which", return_value="/usr/bin/xcrun")
    def test_found_and_simctl_works(self, mock_which, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        preflight.check_xcrun()

    @patch("shutil.which", return_value=None)
    def test_not_found_exits(self, mock_which):
        with pytest.raises(SystemExit):
            preflight.check_xcrun()

    @patch("subprocess.run")
    @patch("shutil.which", return_value="/usr/bin/xcrun")
    def test_simctl_fails_exits(self, mock_which, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        with pytest.raises(SystemExit):
            preflight.check_xcrun()


class TestCheckNetworksetup:
    @patch("shutil.which", return_value="/usr/sbin/networksetup")
    def test_found(self, mock_which):
        preflight.check_networksetup()

    @patch("shutil.which", return_value=None)
    def test_not_found_exits(self, mock_which):
        with pytest.raises(SystemExit):
            preflight.check_networksetup()


class TestRunAll:
    @patch.object(preflight, "check_networksetup")
    @patch.object(preflight, "check_xcrun")
    @patch.object(preflight, "check_mitmdump")
    def test_calls_all(self, mock_mitm, mock_xcrun, mock_net):
        preflight.run_all()
        mock_mitm.assert_called_once()
        mock_xcrun.assert_called_once()
        mock_net.assert_called_once()
