from __future__ import annotations

import json
import os
from unittest.mock import patch

from jaala.addon import JaalaAddon

from .test_addon import make_flow, write_config


def _run_stream(flow, chunks):
    output = []
    for chunk in [*chunks, b""]:
        transformed = flow.response.stream(chunk)
        if isinstance(transformed, bytes):
            output.append(transformed)
        else:
            output.extend(transformed)
    return b"".join(output)


def test_responseheaders_captures_server_stream_chunks_to_json_file(tmp_path):
    json_path = tmp_path / "stream.jsonl"
    with patch.dict(os.environ, {"JAALA_JSON_FILE": str(json_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_headers={"Content-Type": "text/event-stream"})
    addon.responseheaders(flow)

    assert callable(flow.response.stream)
    assert _run_stream(flow, [b"data: one\n\n", b"data: two\n\n"]) == b"data: one\n\ndata: two\n\n"

    records = [json.loads(line) for line in json_path.read_text(encoding="utf-8").splitlines()]
    assert [record["type"] for record in records] == ["http_stream_chunk", "http_stream_chunk"]
    assert records[0]["url"] == "https://api.example.com/data"
    assert records[0]["chunk"]["text"] == "data: one\n\n"
    assert records[0]["chunk"]["modified"] is False
    assert records[1]["sequence"] == 2


def test_body_replace_mutates_matching_server_stream_chunks_across_boundaries(tmp_path):
    config_path = write_config(tmp_path, {"body_replace": "api.example.com=hello>>>world"})
    json_path = tmp_path / "stream.jsonl"
    with patch.dict(
        os.environ,
        {"JAALA_CONFIG": str(config_path), "JAALA_JSON_FILE": str(json_path)},
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_flow(resp_headers={"Content-Type": "text/event-stream", "Content-Length": "999"})
    addon.responseheaders(flow)

    assert callable(flow.response.stream)
    assert "Content-Length" not in flow.response.headers
    assert _run_stream(flow, [b"data: he", b"llo\n\n"]) == b"data: world\n\n"

    records = [json.loads(line) for line in json_path.read_text(encoding="utf-8").splitlines()]
    assert any(record["chunk"]["modified"] for record in records)
    assert "".join(record["chunk"].get("text", "") for record in records) == "data: world\n\n"
    assert flow.metadata["jaala_stream_body_replace_state"]["mutated_chunks"] == 1


def test_body_replace_stream_forwards_final_empty_chunk_after_tail(tmp_path):
    config_path = write_config(tmp_path, {"body_replace": "api.example.com=hello>>>world"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_headers={"Content-Type": "text/event-stream"})
    addon.responseheaders(flow)

    first = flow.response.stream(b"data: he")
    second = flow.response.stream(b"llo")
    final = flow.response.stream(b"")

    assert first == [b"data"]
    assert second == [b": w"]
    assert final == [b"orld"]


def test_streaming_response_skips_final_buffered_http_capture(tmp_path, capsys):
    json_path = tmp_path / "stream.jsonl"
    with patch.dict(os.environ, {"JAALA_JSON_FILE": str(json_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_headers={"Content-Type": "text/event-stream"})
    addon.responseheaders(flow)
    _run_stream(flow, [b"data: one\n\n"])
    addon.response(flow)

    records = [json.loads(line) for line in json_path.read_text(encoding="utf-8").splitlines()]
    assert [record["type"] for record in records] == ["http_stream_chunk"]
    assert "status=200 |" not in capsys.readouterr().out


def test_non_streaming_response_without_stream_body_replace_does_not_install_stream(tmp_path):
    with patch.dict(os.environ, {}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_headers={"Content-Type": "application/json", "Content-Length": "11"})
    addon.responseheaders(flow)

    assert not hasattr(flow.response, "stream")


def test_non_streaming_body_replace_stays_on_buffered_response_path(tmp_path):
    config_path = write_config(tmp_path, {"body_replace": "api.example.com=hello>>>world"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_headers={"Content-Type": "text/plain", "Content-Length": "16"}, resp_body=b"hello from Jaala")
    addon.responseheaders(flow)
    assert not hasattr(flow.response, "stream")

    addon.response(flow)
    assert flow.response.content == b"world from Jaala"


def test_runtime_stream_send_injects_queued_chunk(tmp_path):
    config_path = write_config(
        tmp_path,
        {
            "_jaala_runtime": {
                "stream_events": [
                    {
                        "id": "stream-1",
                        "type": "stream_send",
                        "match_url": "api.example.com/data",
                        "chunk": "event: message\ndata: {\"ok\":true}\n\n",
                    }
                ]
            }
        },
    )
    json_path = tmp_path / "stream.jsonl"
    with patch.dict(
        os.environ,
        {"JAALA_CONFIG": str(config_path), "JAALA_JSON_FILE": str(json_path)},
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_flow(resp_headers={"Content-Type": "text/event-stream"})
    addon.responseheaders(flow)

    assert _run_stream(flow, [b"data: upstream\n\n"]) == b'event: message\ndata: {"ok":true}\n\ndata: upstream\n\n'

    records = [json.loads(line) for line in json_path.read_text(encoding="utf-8").splitlines()]
    assert records[0]["type"] == "http_stream_chunk"
    assert records[0]["chunk"]["text"] == 'event: message\ndata: {"ok":true}\n\n'
