from __future__ import annotations

import json
import os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from jaala.addon import JaalaAddon


class CaseInsensitiveDict(dict):
    def get(self, key, default=None):
        for existing_key, value in self.items():
            if existing_key.lower() == key.lower():
                return value
        return default


def make_flow(url="https://api.example.com/data", req_body=b"", resp_body=b'{"ok":true}'):
    request = SimpleNamespace(
        method="GET",
        pretty_url=url,
        headers=CaseInsensitiveDict({"Host": "api.example.com", "Content-Type": "application/json"}),
        content=req_body,
        timestamp_start=1000.0,
        http_version="HTTP/2.0",
    )
    response = SimpleNamespace(
        status_code=200,
        headers=CaseInsensitiveDict({"Content-Type": "application/json"}),
        content=resp_body,
        timestamp_end=1000.150,
        http_version="HTTP/2.0",
    )
    return SimpleNamespace(request=request, response=response, metadata={})


def test_json_file_opens_handle(tmp_path):
    json_path = tmp_path / "traffic.jsonl"
    with patch.dict(os.environ, {"JAALA_JSON_FILE": str(json_path)}, clear=False):
        addon = JaalaAddon()

    assert addon.json_file == str(json_path)
    assert addon._json_file_handle is not None
    addon._json_file_handle.close()


def test_json_file_invalid_path_is_non_fatal():
    with patch.dict(os.environ, {"JAALA_JSON_FILE": "/nonexistent/dir/traffic.jsonl"}, clear=False):
        addon = JaalaAddon()

    assert addon.json_file == "/nonexistent/dir/traffic.jsonl"
    assert addon._json_file_handle is None


def test_json_file_writes_lines(tmp_path):
    json_path = tmp_path / "traffic.jsonl"
    with patch.dict(os.environ, {"JAALA_JSON_FILE": str(json_path)}, clear=False):
        addon = JaalaAddon()

    addon.response(make_flow())
    addon._json_file_handle.close()

    lines = Path(json_path).read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1
    record = json.loads(lines[0])
    assert record["type"] == "http"
    assert record["method"] == "GET"
    assert record["url"] == "https://api.example.com/data"


def test_json_file_and_stdout_both_receive_capture(tmp_path, capsys):
    json_path = tmp_path / "traffic.jsonl"
    with patch.dict(os.environ, {"JAALA_JSON_FILE": str(json_path), "JAALA_JSON": "1"}, clear=False):
        addon = JaalaAddon()

    addon.response(make_flow())
    addon._json_file_handle.close()

    file_record = json.loads(Path(json_path).read_text(encoding="utf-8").strip())
    stdout_record = json.loads(capsys.readouterr().out.strip())
    assert file_record["type"] == "http"
    assert stdout_record["type"] == "http"
    assert file_record["method"] == "GET"
    assert stdout_record["method"] == "GET"


def test_done_closes_json_handle(tmp_path):
    json_path = tmp_path / "traffic.jsonl"
    with patch.dict(os.environ, {"JAALA_JSON_FILE": str(json_path)}, clear=False):
        addon = JaalaAddon()

    assert addon._json_file_handle is not None
    addon.done()
    assert addon._json_file_handle.closed
