"""mitmproxy addon for capturing and exporting Jaala traffic."""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REPO_ROOT = str(Path(__file__).resolve().parent.parent)
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from jaala.filtering import ENV_CONFIG, build_matcher, resolve_filter_settings
from jaala.network_conditions import (
    build_network_condition_rules,
    resolve_network_condition_settings,
)
from jaala.request_rules import (
    build_request_rules,
    resolve_request_settings,
)
from jaala.response_rules import (
    _CONDITIONAL_BODY_REPLACE_WARNING,
    _RESPONSE_RULE_EVENTS,
    build_response_rules,
    resolve_response_settings,
)
from jaala.runtime_controls import (
    build_runtime_stream_events,
    build_runtime_websocket_events,
    inject_runtime_websocket_events,
    matching_stream_events,
    matching_websocket_events,
)
from jaala.runtime_rules import load_runtime_config
from jaala.websocket_message_rules import (
    ENV_WEBSOCKET_DROP_MESSAGE,
    ENV_WEBSOCKET_DELAY,
    ENV_WEBSOCKET_FAIL_RATE,
    ENV_WEBSOCKET_MESSAGE_REPLACE,
    ENV_WEBSOCKET_THROTTLE,
    _drop_message,
    build_websocket_message_rules,
    resolve_websocket_message_settings,
)
from jaala.websocket_replay import (
    ENV_WEBSOCKET_REPLAY_FILE,
    ENV_WEBSOCKET_REPLAY_PATTERN,
    build_websocket_replay,
    inject_replay_messages,
    resolve_websocket_replay_settings,
)

ENV_JSON = "JAALA_JSON"
ENV_JSON_FILE = "JAALA_JSON_FILE"
ENV_HAR_FILE = "JAALA_HAR_FILE"
ENV_NO_HEADERS = "JAALA_NO_HEADERS"
ENV_NO_BODY = "JAALA_NO_BODY"
ENV_WEBSOCKETS = "JAALA_WEBSOCKETS"
ENV_NO_WEBSOCKETS = "JAALA_NO_WEBSOCKETS"
ENV_QUIET = "JAALA_QUIET"
ENV_VERBOSE = "JAALA_VERBOSE"
ENV_RUNTIME_STATUS_FILE = "JAALA_RUNTIME_STATUS_FILE"
_STREAM_CAPTURED_KEY = "jaala_streaming_response_captured"
_STREAM_PROCESSOR_KEY = "jaala_stream_response_text_replace_processor"
_STREAM_HAR_CAPTURED_KEY = "jaala_streaming_har_captured"


def _env_flag(name: str, default: bool = False) -> bool:
    return os.environ.get(name, "1" if default else "0") == "1"


def _content_bytes(content: bytes | bytearray | memoryview | None) -> bytes:
    if content is None:
        return b""
    if isinstance(content, bytes):
        return content
    if isinstance(content, str):
        return content.encode("utf-8")
    if isinstance(content, bytearray):
        return bytes(content)
    if isinstance(content, memoryview):
        return content.tobytes()
    return bytes(content)


def _decode_body(content: bytes | bytearray | memoryview | None) -> str | None:
    data = _content_bytes(content)
    if not data:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _parse_body(content: bytes | bytearray | memoryview | None, content_type: str) -> str | dict | list | None:
    text = _decode_body(content)
    if text is None:
        return None
    if "json" in content_type.lower():
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
    return text


def _format_headers(headers) -> list[str]:
    return [f"{name}: {value}" for name, value in headers.items()]


def _format_body(content: bytes | bytearray | memoryview | None, content_type: str) -> list[str]:
    body = _parse_body(content, content_type)
    if body is None:
        return []
    if isinstance(body, (dict, list)):
        rendered = json.dumps(body, indent=2, ensure_ascii=False).splitlines()
    else:
        rendered = str(body).splitlines() or [""]
    return rendered


def _timestamp(value: float | None) -> str:
    if value is None:
        return datetime.now(timezone.utc).isoformat()
    return datetime.fromtimestamp(value, tz=timezone.utc).isoformat()


def _iso_millis(value: float | None) -> str:
    return _timestamp(value).replace("+00:00", "Z")


def _is_server_streaming_response(flow) -> bool:
    response = getattr(flow, "response", None)
    if response is None:
        return False
    headers = getattr(response, "headers", {}) or {}
    content_type = headers.get("content-type", "").lower()
    transfer_encoding = headers.get("transfer-encoding", "").lower()
    if "text/event-stream" in content_type:
        return True
    if "application/x-ndjson" in content_type or "application/json-seq" in content_type:
        return True
    if "x-json-stream" in content_type or "stream+json" in content_type:
        return True
    return "chunked" in transfer_encoding


class JaalaAddon:
    """mitmproxy addon that displays traffic and exports capture artifacts."""

    def __init__(self) -> None:
        self.config_path = os.environ.get(ENV_CONFIG, "")
        self.json_mode = _env_flag(ENV_JSON)
        self.json_file = os.environ.get(ENV_JSON_FILE, "")
        self.har_file = os.environ.get(ENV_HAR_FILE, "")
        self._bootstrap_filter_pattern = os.environ.get("JAALA_FILTER", "")
        self._bootstrap_filter_user_agent = os.environ.get("JAALA_FILTER_USER_AGENT", "")
        self.filter_pattern = ""
        self.filter_user_agent = ""
        self.websockets = _env_flag(ENV_WEBSOCKETS, default=True)
        self.no_websockets = _env_flag(ENV_NO_WEBSOCKETS)
        self.websocket_message_replace = os.environ.get(ENV_WEBSOCKET_MESSAGE_REPLACE, "")
        self.websocket_drop_message = os.environ.get(ENV_WEBSOCKET_DROP_MESSAGE, "")
        self.websocket_fail_rate = os.environ.get(ENV_WEBSOCKET_FAIL_RATE, "")
        self.websocket_delay = os.environ.get(ENV_WEBSOCKET_DELAY, "")
        self.websocket_throttle = os.environ.get(ENV_WEBSOCKET_THROTTLE, "")
        self.websocket_replay_file = os.environ.get(ENV_WEBSOCKET_REPLAY_FILE, "")
        self.websocket_replay_pattern = os.environ.get(ENV_WEBSOCKET_REPLAY_PATTERN, "")
        self.map_local = ""
        self.map_remote = ""
        self.status_code = ""
        self.add_header = ""
        self.response_text_replace = ""
        self.request_header = ""
        self.request_body_replace = ""
        self.delay: list[str] = []
        self.throttle: list[str] = []
        self.drop_connection: list[str] = []
        self.fail_rate: list[str] = []
        self.show_headers = not _env_flag(ENV_NO_HEADERS)
        self.show_body = not _env_flag(ENV_NO_BODY)
        self.quiet = _env_flag(ENV_QUIET)
        self.verbose = _env_flag(ENV_VERBOSE)
        self.runtime_status_file = os.environ.get(ENV_RUNTIME_STATUS_FILE, "")
        self._json_file_handle = None
        self.har_entries: list[dict] = []
        self._runtime_websocket_events = []
        self._runtime_stream_events = []
        self._sent_runtime_websocket_event_ids: set[str] = set()
        self._sent_runtime_stream_event_ids: set[str] = set()
        self._config_signature: tuple[bool, int | None, int | None] | None = None
        self._reload_status: dict[str, Any] = {
            "outcome": "pending",
            "reason": "startup",
            "active_response_text_replace": None,
            "last_successful_outcome": None,
            "last_successful_reason": None,
            "last_successful_active_response_text_replace": None,
            "last_error": None,
        }
        self._reload_runtime_settings(force=True)

        if self.json_file:
            try:
                self._json_file_handle = open(self.json_file, "w", encoding="utf-8")
            except OSError as exc:
                print(f"Error: cannot open JSON log file '{self.json_file}': {exc}", file=sys.stderr)

    def _current_config_signature(self) -> tuple[bool, int | None, int | None]:
        if not self.config_path:
            return (False, None, None)
        path = Path(self.config_path)
        try:
            stat = path.stat()
        except OSError:
            return (False, None, None)
        return (True, stat.st_mtime_ns, stat.st_size)

    def _reload_runtime_settings(self, force: bool = False) -> None:
        signature = self._current_config_signature()
        if not force and signature == self._config_signature:
            self._record_reload_status(
                "skipped",
                "unchanged",
                active_response_text_replace=self._reload_status.get("active_response_text_replace"),
            )
            self._verbose(
                "runtime reload skipped: unchanged signature "
                f"{self._reload_status.get('config_signature')}"
            )
            return

        try:
            filter_settings = resolve_filter_settings(
                config_path=self.config_path or None,
            )
            response_settings = resolve_response_settings(
                config_path=self.config_path or None,
            )
            request_settings = resolve_request_settings(
                config_path=self.config_path or None,
            )
            websocket_message_settings = resolve_websocket_message_settings(
                config_path=self.config_path or None,
                websocket_message_replace=self.websocket_message_replace,
                websocket_drop_message=self.websocket_drop_message,
                websocket_fail_rate=self.websocket_fail_rate,
                websocket_delay=self.websocket_delay,
                websocket_throttle=self.websocket_throttle,
            )
            websocket_replay_settings = resolve_websocket_replay_settings(
                config_path=self.config_path or None,
                replay_file=self.websocket_replay_file or None,
                replay_pattern=self.websocket_replay_pattern or None,
            )
            network_condition_settings = resolve_network_condition_settings(
                config_path=self.config_path or None,
            )
            runtime_config = load_runtime_config(self.config_path) if self.config_path else {}

            self.filter_pattern = filter_settings.get("filter") or self._bootstrap_filter_pattern
            self.filter_user_agent = filter_settings.get("filter_user_agent") or self._bootstrap_filter_user_agent
            self.map_local = response_settings.get("map_local", "")
            self.map_remote = response_settings.get("map_remote", "")
            self.status_code = response_settings.get("status_code", "")
            self.add_header = response_settings.get("add_header", "")
            self.response_text_replace = response_settings.get("response_text_replace", "")
            self.request_header = request_settings.get("request_header", "")
            self.request_body_replace = request_settings.get("request_body_replace", "")
            self.delay = list(network_condition_settings.get("delay", []))
            self.throttle = list(network_condition_settings.get("throttle", []))
            self.drop_connection = list(network_condition_settings.get("drop_connection", []))
            self.fail_rate = list(network_condition_settings.get("fail_rate", []))

            self._filter_matcher = build_matcher(self.filter_pattern)
            self._filter_user_agent_matcher = build_matcher(self.filter_user_agent)
            self._response_rules = build_response_rules(response_settings)
            self._request_rules = build_request_rules(request_settings)
            self._websocket_message_rules = build_websocket_message_rules(websocket_message_settings)
            self._websocket_replay = build_websocket_replay(
                replay_file=websocket_replay_settings.get("websocket_replay"),
                replay_pattern=websocket_replay_settings.get("websocket_replay_pattern"),
            )
            self._runtime_websocket_events = build_runtime_websocket_events(runtime_config)
            self._runtime_stream_events = build_runtime_stream_events(runtime_config)
            self._network_condition_rules = build_network_condition_rules(network_condition_settings)
        except Exception as exc:
            self._record_reload_status("failed", "validation_failed", error=str(exc))
            self._verbose(f"runtime reload failed: {exc}")
            return

        self._config_signature = signature
        reason = "initial_load" if force else "signature_changed"
        active_response_text_replace = response_settings.get("response_text_replace")
        self._record_reload_status(
            "reloaded",
            reason,
            active_response_text_replace=active_response_text_replace,
            last_successful_outcome="reloaded",
            last_successful_reason=reason,
            last_successful_active_response_text_replace=active_response_text_replace,
        )
        self._verbose(
            f"runtime reload {reason}: active response_text_replace={active_response_text_replace or '-'} "
            f"signature={list(signature)}"
        )

    def _verbose(self, message: str) -> None:
        if not self.verbose:
            return
        print(f"[jaala verbose] {message}", file=sys.stderr)

    def _emit_rule_events(self, flow) -> None:
        if not self.verbose:
            return
        metadata = getattr(flow, "metadata", {}) or {}
        events = metadata.pop(_RESPONSE_RULE_EVENTS, None)
        if not isinstance(events, list):
            return
        for event in events:
            if not isinstance(event, dict):
                continue
            name = event.get("event", "unknown")
            details = ", ".join(
                f"{key}={value!r}" for key, value in event.items() if key != "event"
            )
            suffix = f" | {details}" if details else ""
            self._verbose(f"response-rule {name}{suffix}")

    def _record_reload_status(
        self,
        outcome: str,
        reason: str,
        *,
        error: str | None = None,
        active_response_text_replace: str | None = None,
        last_successful_outcome: str | None = None,
        last_successful_reason: str | None = None,
        last_successful_active_response_text_replace: str | None = None,
    ) -> None:
        previous = self._reload_status
        if active_response_text_replace is None:
            active_response_text_replace = previous.get("active_response_text_replace")
        if last_successful_outcome is None:
            last_successful_outcome = previous.get("last_successful_outcome")
        if last_successful_reason is None:
            last_successful_reason = previous.get("last_successful_reason")
        if last_successful_active_response_text_replace is None:
            last_successful_active_response_text_replace = previous.get("last_successful_active_response_text_replace")
        status = {
            "outcome": outcome,
            "reason": reason,
            "config_path": self.config_path or None,
            "config_signature": list(self._current_config_signature()),
            "active_response_text_replace": active_response_text_replace,
            "last_successful_outcome": last_successful_outcome,
            "last_successful_reason": last_successful_reason,
            "last_successful_active_response_text_replace": last_successful_active_response_text_replace,
            "last_error": error,
        }
        self._reload_status = status
        if not self.runtime_status_file:
            return
        try:
            with open(self.runtime_status_file, "w", encoding="utf-8") as handle:
                json.dump(status, handle, indent=2, sort_keys=True)
        except OSError:
            pass

    def _flow_matches_filters(self, flow) -> bool:
        req = flow.request
        if self._filter_matcher is not None and not self._filter_matcher(getattr(req, "pretty_url", "")):
            return False

        if self._filter_user_agent_matcher is not None:
            user_agent = req.headers.get("user-agent", "")
            if not self._filter_user_agent_matcher(user_agent):
                return False

        return True

    def _build_json_record(self, flow) -> dict:
        req = flow.request
        resp = flow.response
        record: dict = {
            "type": "http",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "method": req.method,
            "url": req.pretty_url,
            "status": resp.status_code,
        }

        duration_ms = None
        if getattr(req, "timestamp_start", None) is not None and getattr(resp, "timestamp_end", None) is not None:
            duration_ms = int(round((resp.timestamp_end - req.timestamp_start) * 1000))
        if duration_ms is not None:
            record["duration_ms"] = duration_ms

        request: dict = {}
        response: dict = {}

        if self.show_headers:
            request["headers"] = dict(req.headers)
            response["headers"] = dict(resp.headers)

        if self.show_body:
            req_ct = req.headers.get("content-type", "")
            resp_ct = resp.headers.get("content-type", "")
            req_body = _parse_body(req.content, req_ct)
            resp_body = _parse_body(resp.content, resp_ct)
            if req_body is not None:
                request["body"] = req_body
            if resp_body is not None:
                response["body"] = resp_body
            response["size"] = len(_content_bytes(resp.content))

        record["request"] = request
        record["response"] = response
        return record

    def _build_websocket_record(self, flow, message) -> dict:
        req = flow.request
        content = getattr(message, "content", None)
        opcode = "text" if getattr(message, "is_text", False) else "binary"
        text = None
        if opcode == "text":
            text = getattr(message, "text", None)
            if text is None:
                text = _decode_body(content)

        record: dict = {
            "type": "websocket_message",
            "timestamp": _timestamp(getattr(message, "timestamp", None)),
            "url": getattr(req, "pretty_url", ""),
            "direction": "client_to_server" if getattr(message, "from_client", True) else "server_to_client",
            "opcode": opcode,
            "message": {
                "size": len(_content_bytes(content)),
            },
        }
        if text is not None:
            record["message"]["text"] = text
        if self.show_headers:
            record["request"] = {"headers": dict(req.headers)}
        else:
            record["request"] = {}
        return record

    def _build_stream_chunk_record(
        self,
        flow,
        *,
        sequence: int,
        original: bytes,
        chunk: bytes,
    ) -> dict:
        req = flow.request
        resp = flow.response
        text = _decode_body(chunk)
        record: dict = {
            "type": "http_stream_chunk",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "method": req.method,
            "url": req.pretty_url,
            "status": resp.status_code,
            "sequence": sequence,
            "chunk": {
                "size": len(chunk),
                "original_size": len(original),
                "modified": chunk != original,
            },
        }
        if text is not None and self.show_body:
            record["chunk"]["text"] = text
        if self.show_headers:
            record["request"] = {"headers": dict(req.headers)}
            record["response"] = {"headers": dict(resp.headers)}
        else:
            record["request"] = {}
            record["response"] = {}
        return record

    def _emit_json_record(self, record: dict) -> None:
        print(json.dumps(record, ensure_ascii=False, separators=(",", ":")))
        sys.stdout.flush()

    def _write_json_record(self, record: dict) -> None:
        handle = self._json_file_handle
        if handle is None:
            return
        if getattr(handle, "closed", False):
            self._json_file_handle = None
            return
        try:
            handle.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
            handle.flush()
        except (OSError, ValueError):
            self._json_file_handle = None

    def _print_human_flow(self, flow) -> None:
        req = flow.request
        resp = flow.response
        duration_ms = None
        if getattr(req, "timestamp_start", None) is not None and getattr(resp, "timestamp_end", None) is not None:
            duration_ms = int((resp.timestamp_end - req.timestamp_start) * 1000)

        parts = [
            f"{req.method} {req.pretty_url}",
            f"status={resp.status_code}",
        ]
        if duration_ms is not None:
            parts.append(f"{duration_ms}ms")
        parts.append(f"{len(_content_bytes(resp.content))} bytes")
        print(" | ".join(parts))

        if self.show_headers:
            if req.headers:
                print("Request Headers:")
                for line in _format_headers(req.headers):
                    print(f"  {line}")
            if resp.headers:
                print("Response Headers:")
                for line in _format_headers(resp.headers):
                    print(f"  {line}")

        if self.show_body:
            req_ct = req.headers.get("content-type", "")
            resp_ct = resp.headers.get("content-type", "")
            req_body_lines = _format_body(req.content, req_ct)
            resp_body_lines = _format_body(resp.content, resp_ct)
            if req_body_lines:
                print("Request Body:")
                for line in req_body_lines:
                    print(f"  {line}")
            if resp_body_lines:
                print("Response Body:")
                for line in resp_body_lines:
                    print(f"  {line}")
        sys.stdout.flush()

    def _print_human_websocket_message(self, flow, message) -> None:
        req = flow.request
        direction = "client->server" if getattr(message, "from_client", True) else "server->client"
        opcode = "text" if getattr(message, "is_text", False) else "binary"
        size = len(_content_bytes(getattr(message, "content", None)))
        parts = [
            f"WS {direction} {req.pretty_url}",
            f"opcode={opcode}",
            f"{size} bytes",
        ]
        print(" | ".join(parts))
        if self.show_headers and req.headers:
            print("Request Headers:")
            for line in _format_headers(req.headers):
                print(f"  {line}")
        if self.show_body and opcode == "text":
            text = getattr(message, "text", None)
            if text is None:
                text = _decode_body(getattr(message, "content", None))
            if text:
                print("Message:")
                for line in str(text).splitlines() or [""]:
                    print(f"  {line}")
        sys.stdout.flush()

    def _build_har_entry(self, flow) -> dict:
        req = flow.request
        resp = flow.response
        started = _iso_millis(getattr(req, "timestamp_start", None))

        if getattr(req, "timestamp_start", None) is not None and getattr(resp, "timestamp_end", None) is not None:
            elapsed_ms = int(round((resp.timestamp_end - req.timestamp_start) * 1000))
        else:
            elapsed_ms = 0

        entry: dict = {
            "startedDateTime": started,
            "time": elapsed_ms,
            "request": {
                "method": req.method,
                "url": req.pretty_url,
                "httpVersion": getattr(req, "http_version", ""),
                "headers": [{"name": name, "value": value} for name, value in req.headers.items()],
                "queryString": [],
                "headersSize": -1,
                "bodySize": len(_content_bytes(req.content)),
            },
            "response": {
                "status": resp.status_code,
                "statusText": "",
                "httpVersion": getattr(resp, "http_version", ""),
                "headers": [{"name": name, "value": value} for name, value in resp.headers.items()],
                "content": {
                    "size": len(_content_bytes(resp.content)),
                    "mimeType": resp.headers.get("content-type", ""),
                },
                "redirectURL": "",
                "headersSize": -1,
                "bodySize": len(_content_bytes(resp.content)),
            },
            "cache": {},
            "timings": {
                "send": -1,
                "wait": elapsed_ms,
                "receive": -1,
            },
        }

        req_body = _decode_body(req.content)
        if req_body is not None:
            entry["request"]["postData"] = {
                "mimeType": req.headers.get("content-type", ""),
                "text": req_body,
            }

        resp_body = _decode_body(resp.content)
        if resp_body is not None:
            entry["response"]["content"]["text"] = resp_body

        return entry

    def _collect_har_entry(self, flow) -> None:
        if not self.har_file:
            return
        try:
            self.har_entries.append(self._build_har_entry(flow))
        except Exception:
            pass

    def _capture_stream_chunk(self, flow, *, sequence: int, original: bytes, chunk: bytes) -> None:
        if not self._flow_matches_filters(flow):
            return
        record = self._build_stream_chunk_record(flow, sequence=sequence, original=original, chunk=chunk)
        self._write_json_record(record)
        if self.json_mode:
            self._emit_json_record(record)
        elif not self.quiet:
            text = _decode_body(chunk)
            suffix = f" | {text}" if text and self.show_body else ""
            print(
                f"STREAM {flow.request.method} {flow.request.pretty_url} "
                f"status={flow.response.status_code} chunk={sequence} {len(chunk)} bytes{suffix}"
            )
            sys.stdout.flush()

    def _build_stream_transformer(self, flow):
        processor = flow.metadata.get(_STREAM_PROCESSOR_KEY)
        sequence = 0
        finished = False

        def transform(chunk):
            nonlocal sequence, finished
            self._reload_runtime_settings()
            original = _content_bytes(chunk)
            if original:
                output = processor.process(original) if processor is not None else original
            elif processor is not None and not finished:
                output = processor.finish()
                self._response_rules.record_stream_response_text_replace_result(flow, processor)
                self._emit_rule_events(flow)
                finished = True
            else:
                output = original

            pending_stream_events = matching_stream_events(
                flow,
                self._runtime_stream_events,
                self._sent_runtime_stream_event_ids,
            )
            event_chunks = [event.chunk for event in pending_stream_events]
            for event in pending_stream_events:
                self._sent_runtime_stream_event_ids.add(event.id)

            chunks = [*event_chunks]
            if output:
                chunks.append(output)

            transformed = []
            for item in chunks:
                sequence += 1
                self._capture_stream_chunk(flow, sequence=sequence, original=original, chunk=item)
                transformed.append(item)
            return transformed

        return transform

    def responseheaders(self, flow) -> None:
        self._reload_runtime_settings()
        if flow.metadata.get("jaala_dropped", False):
            return
        if getattr(flow, "response", None) is None:
            return

        self._response_rules.apply_response_headers(flow)
        self._emit_rule_events(flow)
        is_streaming = _is_server_streaming_response(flow)
        processor = self._response_rules.build_stream_response_text_replace_processor(flow) if is_streaming else None
        should_capture = is_streaming and self._flow_matches_filters(flow)
        if processor is None and not should_capture:
            return

        flow.metadata[_STREAM_CAPTURED_KEY] = True
        if should_capture and not flow.metadata.get(_STREAM_HAR_CAPTURED_KEY, False):
            self._collect_har_entry(flow)
            flow.metadata[_STREAM_HAR_CAPTURED_KEY] = True
        if processor is not None:
            flow.metadata[_STREAM_PROCESSOR_KEY] = processor
            try:
                for name in ("content-length", "content-md5", "digest", "etag", "last-modified"):
                    keys = [key for key in flow.response.headers.keys() if key.lower() == name]
                    for key in keys:
                        del flow.response.headers[key]
            except Exception:
                pass
        flow.response.stream = self._build_stream_transformer(flow)

    def save_har(self) -> None:
        if not self.har_file:
            return

        har = {
            "log": {
                "version": "1.2",
                "creator": {
                    "name": "jaala",
                    "version": "0.1.0",
                },
                "entries": self.har_entries,
            }
        }

        try:
            with open(self.har_file, "w", encoding="utf-8") as handle:
                json.dump(har, handle, indent=2, ensure_ascii=False)
        except OSError as exc:
            print(f"Error saving HAR file: {exc}", file=sys.stderr)
        else:
            print(f"HAR file saved: {self.har_file} ({len(self.har_entries)} entries)", file=sys.stderr)

    def response(self, flow) -> None:
        self._reload_runtime_settings()
        if flow.metadata.get("jaala_dropped", False):
            return
        if flow.metadata.get(_STREAM_CAPTURED_KEY, False):
            return
        self._response_rules.apply_response(flow)
        self._network_condition_rules.apply_response(flow)
        self._emit_rule_events(flow)
        if not self._flow_matches_filters(flow):
            return
        record = self._build_json_record(flow)
        self._collect_har_entry(flow)
        self._write_json_record(record)
        if self.json_mode:
            self._emit_json_record(record)
        else:
            self._print_human_flow(flow)

    def request(self, flow) -> None:
        self._reload_runtime_settings()
        self._request_rules.apply_request(flow)
        if self._network_condition_rules.apply_request(flow):
            return
        self._response_rules.apply_request(flow)
        self._emit_rule_events(flow)
        warning = flow.metadata.pop(_CONDITIONAL_BODY_REPLACE_WARNING, None)
        if warning:
            headers = ", ".join(warning.get("headers", []))
            url = warning.get("url", "")
            print(
                "Warning: request matches a response-text-replace rule but includes conditional cache "
                f"headers ({headers}) for {url}. Upstream may return 304 Not Modified, leaving "
                "no response body for Jaala to mutate. Remove those headers explicitly if you "
                "want mutation to apply.",
                file=sys.stderr,
            )

    def websocket_message(self, flow) -> None:
        self._reload_runtime_settings()
        if not self.websockets or self.no_websockets:
            return
        if flow.metadata.get("jaala_dropped", False):
            return
        if not self._flow_matches_filters(flow):
            return

        websocket = getattr(flow, "websocket", None)
        messages = getattr(websocket, "messages", None)
        if not messages:
            return
        message = messages[-1]
        if (
            not getattr(message, "from_client", True)
            and flow.metadata.get("jaala_runtime_websocket_drop_live_server")
            and not getattr(message, "injected", False)
        ):
            _drop_message(message)
            return
        pending_runtime_events = matching_websocket_events(
            flow,
            self._runtime_websocket_events,
            self._sent_runtime_websocket_event_ids,
        )
        if pending_runtime_events:
            injected_count = inject_runtime_websocket_events(flow, pending_runtime_events)
            if injected_count:
                for event in pending_runtime_events[:injected_count]:
                    self._sent_runtime_websocket_event_ids.add(event.id)
                if any(event.drop_live_server_messages for event in pending_runtime_events[:injected_count]):
                    flow.metadata["jaala_runtime_websocket_drop_live_server"] = True
        if self._websocket_replay.should_inject_after(flow, message):
            injected_count = inject_replay_messages(flow, self._websocket_replay.messages_for(flow))
            if injected_count:
                self._websocket_replay.mark_injected(flow, injected_count)
        if self._websocket_replay.should_drop_live_server_message(flow, message):
            self._websocket_replay.mark_live_server_dropped(flow, message)
            return
        if self._websocket_message_rules.apply_websocket_message(flow, message):
            return
        record = self._build_websocket_record(flow, message)
        self._write_json_record(record)
        if self.json_mode:
            self._emit_json_record(record)
        else:
            self._print_human_websocket_message(flow, message)

    def done(self) -> None:
        self.save_har()
        if self._json_file_handle is not None:
            try:
                self._json_file_handle.close()
            except OSError:
                pass
            finally:
                self._json_file_handle = None


addons = [JaalaAddon()]
