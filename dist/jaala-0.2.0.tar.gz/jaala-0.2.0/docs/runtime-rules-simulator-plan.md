# Runtime Rules Incremental Plan

Every commit in this plan must pass a real iOS Simulator validation with the Wikipedia app.

Tests support the change, but they do not replace simulator validation.

## Standing Acceptance Checklist

For every commit:

1. Start a fresh Jaala session.
2. Start a fresh Wikipedia app state in Simulator.
3. Capture a baseline screenshot showing real upstream content in the app.
4. Trigger the feature for that commit only through the supported Jaala CLI path.
5. Capture a second screenshot showing the visible in-app effect.
6. Record the exact command output used for the runtime change.
7. Do not count the commit as complete unless the Simulator scenario succeeds end to end.

## Incremental Commits

### 1. `prototype-hot-reload-body-replace`

- Goal: prove live rule injection works.
- Acceptance:
  - start Jaala
  - Wikipedia search shows real `Anthropic` subtitle
  - run `jaala rules add body-replace ...`
  - the same search shows `JAALA TEMP ITEM`
  - no Jaala restart

### 2. `runtime-rules-foundation`

- Goal: make runtime rule store and session metadata explicit and reliable.
- Acceptance:
  - rerun the same Wikipedia Simulator scenario
  - active session metadata resolves to the correct runtime rules store
  - visible before/after mutation still succeeds

### 3. `http-rules-config-first-reload`

- Goal: move HTTP runtime behavior to a config-first reload path.
- Acceptance:
  - rerun the same Wikipedia Simulator scenario
  - rule change is picked up from canonical runtime state
  - visible mutation still succeeds with no Jaala restart

### 4. `rules-inspection-cli`

- Goal: expose active rules and runtime diagnostics.
- Acceptance:
  - rerun the same Wikipedia Simulator scenario
  - `jaala rules show` reflects the active rule used in the successful mutation
  - `jaala rules status` reflects the running session after the mutation scenario

### 5. `rules-mutation-cli`

- Goal: productize CLI-managed runtime rule updates.
- Acceptance:
  - operator adds the runtime rule only through the CLI
  - Wikipedia visible mutation scenario succeeds without direct file edits
  - no Jaala restart

### 6. `runtime-rule-separator-escaping`

- Goal: fix runtime rule serialization/parsing so rule values containing separators such as `=` round-trip correctly through the CLI and runtime store.
- Acceptance:
  - rerun a real Wikipedia Places Simulator scenario
  - baseline shows a real place title such as `Union Square, San Francisco`
  - add a live rule through Jaala CLI using a `--match-url` value that includes `=`, such as `generator=search`
  - rerun the same Places flow without restarting Jaala
  - the visible Places UI shows the replacement string
  - no workaround substring such as `nearcoord:` is needed

### 7. `structured-json-replace`

- Goal: add structured nested JSON replacement.
- Acceptance:
  - use a real Wikipedia JSON-backed field that is visibly rendered, if available
  - if Wikipedia cannot visibly exercise nested JSON replacement, use another real Simulator app flow only after that limitation is clearly established
  - do not replace the real Simulator validation with tests

### 8. `mutated-body-header-invariants`

- Goal: guarantee body and header consistency after mutation.
- Acceptance:
  - rerun the same Wikipedia live mutation scenario
  - verify the app renders the mutation and does not fall into error states
  - prove the wire-format invariants preserve app behavior

### 9. `preserve-supported-encodings`

- Goal: preserve supported encodings, starting with `gzip`.
- Acceptance:
  - rerun the Wikipedia live mutation scenario against a compressed response path
  - confirm visible mutation still works in the app
  - no Jaala restart

### 10. `wikipedia-e2e-validation`

- Goal: codify the scenario as the release gate.
- Acceptance:
  - run the full end-to-end Simulator scenario again and record evidence
  - baseline and mutated screenshots must both be captured from the app

### 11. `remove-http-rule-env-vars`

- Goal: remove deprecated HTTP rule env-var resolution from the runtime path.
- Acceptance:
  - rerun the same Wikipedia Simulator scenario using only the supported CLI/runtime path
  - visible mutation must still work

### 12. `websocket-followup-gate`

- Goal: defer websocket hot reload until HTTP behavior is clearly validated and stable.
- Acceptance:
  - no websocket implementation in this commit
  - document that websocket work remains blocked on preserving the already validated HTTP Simulator scenario
