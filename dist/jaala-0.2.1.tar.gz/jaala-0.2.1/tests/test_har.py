from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from jaala.addon import JaalaAddon


class CaseInsensitiveDict(dict):
    def get(self, key, default=None):
        for existing_key, value in self.items():
            if existing_key.lower() == key.lower():
                return value
        return default


def make_flow(
    method="GET",
    url="https://api.example.com/data",
    status=200,
    req_headers=None,
    resp_headers=None,
    req_body=b"",
    resp_body=b'{"ok":true}',
    ts_start=1000.0,
    ts_end=1000.150,
):
    request = SimpleNamespace(
        method=method,
        pretty_url=url,
        headers=CaseInsensitiveDict(req_headers or {"Host": "api.example.com", "Content-Type": "application/json"}),
        content=req_body,
        timestamp_start=ts_start,
        http_version="HTTP/2.0",
    )
    response = SimpleNamespace(
        status_code=status,
        headers=CaseInsensitiveDict(resp_headers or {"Content-Type": "application/json"}),
        content=resp_body,
        timestamp_end=ts_end,
        http_version="HTTP/2.0",
    )
    return SimpleNamespace(request=request, response=response, metadata={})


def test_build_har_entry_structure():
    with patch.dict(os.environ, {"JAALA_HAR_FILE": "out.har"}, clear=False):
        addon = JaalaAddon()

    entry = addon._build_har_entry(make_flow(method="POST", url="https://api.example.com/users", req_body=b'{"name":"alice"}', resp_body=b'{"id":1}', status=201))

    assert entry["startedDateTime"].endswith("Z")
    assert entry["time"] == 150
    assert entry["request"]["method"] == "POST"
    assert entry["response"]["status"] == 201
    assert entry["request"]["postData"]["text"] == '{"name":"alice"}'
    assert entry["response"]["content"]["text"] == '{"id":1}'


def test_collect_har_entry_appends_when_enabled():
    with patch.dict(os.environ, {"JAALA_HAR_FILE": "out.har"}, clear=False):
        addon = JaalaAddon()

    addon._collect_har_entry(make_flow())
    assert len(addon.har_entries) == 1


def test_collect_har_entry_skips_when_disabled():
    with patch.dict(os.environ, {}, clear=False):
        addon = JaalaAddon()

    addon._collect_har_entry(make_flow())
    assert len(addon.har_entries) == 0


def test_streaming_response_collects_har_entry_from_headers():
    with patch.dict(os.environ, {"JAALA_HAR_FILE": "out.har"}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://api.example.com/stream",
        resp_headers={"Content-Type": "text/event-stream"},
        resp_body=b"",
        ts_end=None,
    )

    addon.responseheaders(flow)
    addon.response(flow)

    assert len(addon.har_entries) == 1
    assert addon.har_entries[0]["request"]["url"] == "https://api.example.com/stream"


def test_save_har_writes_expected_file(tmp_path):
    har_path = tmp_path / "traffic.har"
    with patch.dict(os.environ, {"JAALA_HAR_FILE": str(har_path)}, clear=False):
        addon = JaalaAddon()

    addon._collect_har_entry(make_flow())
    addon.save_har()

    data = json.loads(Path(har_path).read_text(encoding="utf-8"))
    assert data["log"]["creator"]["name"] == "jaala"
    assert len(data["log"]["entries"]) == 1


def test_save_har_prints_success_message(tmp_path, capsys):
    har_path = tmp_path / "traffic.har"
    with patch.dict(os.environ, {"JAALA_HAR_FILE": str(har_path)}, clear=False):
        addon = JaalaAddon()

    addon._collect_har_entry(make_flow())
    addon.save_har()

    assert "HAR file saved" in capsys.readouterr().err


def test_done_saves_har_and_closes_json_handle(tmp_path):
    har_path = tmp_path / "traffic.har"
    json_path = tmp_path / "traffic.jsonl"
    with patch.dict(
        os.environ,
        {"JAALA_HAR_FILE": str(har_path), "JAALA_JSON_FILE": str(json_path)},
        clear=False,
    ):
        addon = JaalaAddon()

    addon._collect_har_entry(make_flow())
    addon.done()

    data = json.loads(Path(har_path).read_text(encoding="utf-8"))
    assert len(data["log"]["entries"]) == 1
    assert addon._json_file_handle.closed is True


def test_started_datetime_is_parseable():
    with patch.dict(os.environ, {"JAALA_HAR_FILE": "out.har"}, clear=False):
        addon = JaalaAddon()

    entry = addon._build_har_entry(make_flow(ts_start=1704067200.123, ts_end=1704067200.223))
    parsed = datetime.fromisoformat(entry["startedDateTime"].replace("Z", "+00:00"))
    assert parsed.tzinfo == timezone.utc
