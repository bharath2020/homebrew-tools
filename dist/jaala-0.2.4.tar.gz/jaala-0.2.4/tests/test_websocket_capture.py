from __future__ import annotations

import json
import os
from types import SimpleNamespace
from unittest.mock import patch

from jaala.addon import JaalaAddon


class CaseInsensitiveDict(dict):
    def get(self, key, default=None):
        for existing_key, value in self.items():
            if existing_key.lower() == key.lower():
                return value
        return default


def make_websocket_flow(
    *,
    url="wss://ws.example.com/socket",
    from_client=True,
    is_text=True,
    text="jaala websocket ping",
    content=b"jaala websocket ping",
    timestamp=1700000000.25,
    headers=None,
):
    request = SimpleNamespace(
        method="GET",
        pretty_url=url,
        headers=CaseInsensitiveDict(headers or {"Host": "ws.example.com", "User-Agent": "JaalaSample/1.0"}),
        content=b"",
        timestamp_start=1700000000.0,
        http_version="HTTP/1.1",
    )
    message = SimpleNamespace(
        from_client=from_client,
        is_text=is_text,
        text=text if is_text else None,
        content=content,
        timestamp=timestamp,
    )
    websocket = SimpleNamespace(messages=[message])
    return SimpleNamespace(request=request, websocket=websocket, metadata={})


def test_websocket_json_record_includes_expected_fields():
    with patch.dict(os.environ, {"JAALA_JSON": "1"}, clear=False):
        addon = JaalaAddon()

    flow = make_websocket_flow()
    record = addon._build_websocket_record(flow, flow.websocket.messages[-1])

    assert record["type"] == "websocket_message"
    assert record["url"] == "wss://ws.example.com/socket"
    assert record["direction"] == "client_to_server"
    assert record["opcode"] == "text"
    assert record["message"]["size"] == len(b"jaala websocket ping")
    assert record["message"]["text"] == "jaala websocket ping"
    assert record["request"]["headers"]["User-Agent"] == "JaalaSample/1.0"


def test_websocket_message_emits_json_line(capsys):
    with patch.dict(os.environ, {"JAALA_JSON": "1"}, clear=False):
        addon = JaalaAddon()

    addon.websocket_message(make_websocket_flow())

    record = json.loads(capsys.readouterr().out.strip())
    assert record["type"] == "websocket_message"
    assert record["direction"] == "client_to_server"
    assert record["opcode"] == "text"
    assert record["message"]["text"] == "jaala websocket ping"


def test_websocket_filter_matching_url_emits_json_line(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_FILTER": "ws.example.com/socket"},
        clear=False,
    ):
        addon = JaalaAddon()

    addon.websocket_message(make_websocket_flow())

    record = json.loads(capsys.readouterr().out.strip())
    assert record["type"] == "websocket_message"
    assert record["url"] == "wss://ws.example.com/socket"


def test_websocket_filter_nonmatching_url_skips_capture(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_FILTER": "payments"},
        clear=False,
    ):
        addon = JaalaAddon()

    addon.websocket_message(make_websocket_flow())

    assert capsys.readouterr().out == ""


def test_websocket_filter_matching_user_agent_emits_json_line(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_FILTER_USER_AGENT": "JaalaSample"},
        clear=False,
    ):
        addon = JaalaAddon()

    addon.websocket_message(make_websocket_flow())

    record = json.loads(capsys.readouterr().out.strip())
    assert record["type"] == "websocket_message"
    assert record["request"]["headers"]["User-Agent"] == "JaalaSample/1.0"


def test_websocket_filter_nonmatching_user_agent_skips_capture(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_FILTER_USER_AGENT": "re:JaalaSample/2\\."},
        clear=False,
    ):
        addon = JaalaAddon()

    addon.websocket_message(make_websocket_flow())

    assert capsys.readouterr().out == ""


def test_websocket_binary_messages_omit_text_field(capsys):
    with patch.dict(os.environ, {"JAALA_JSON": "1"}, clear=False):
        addon = JaalaAddon()

    addon.websocket_message(
        make_websocket_flow(
            from_client=False,
            is_text=False,
            content=b"\x00\x01\x02",
            text=None,
            url="wss://ws.example.com/binary",
        )
    )

    record = json.loads(capsys.readouterr().out.strip())
    assert record["type"] == "websocket_message"
    assert record["direction"] == "server_to_client"
    assert record["opcode"] == "binary"
    assert record["message"]["size"] == 3
    assert "text" not in record["message"]


def test_no_websockets_flag_disables_capture(capsys):
    with patch.dict(os.environ, {"JAALA_JSON": "1", "JAALA_NO_WEBSOCKETS": "1"}, clear=False):
        addon = JaalaAddon()

    addon.websocket_message(make_websocket_flow())

    assert capsys.readouterr().out == ""


def test_websocket_message_replace_mutates_client_text_message(capsys):
    with patch.dict(
        os.environ,
        {
            "JAALA_JSON": "1",
            "JAALA_WEBSOCKET_MESSAGE_REPLACE": "ws.example.com/socket=hello>>>world",
        },
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow(text="hello from jaala", content=b"hello from jaala")
    addon.websocket_message(flow)

    record = json.loads(capsys.readouterr().out.strip())
    assert flow.websocket.messages[-1].content == b"world from jaala"
    assert flow.websocket.messages[-1].text == "world from jaala"
    assert record["direction"] == "client_to_server"
    assert record["message"]["text"] == "world from jaala"


def test_websocket_message_replace_mutates_server_text_message(capsys):
    with patch.dict(
        os.environ,
        {
            "JAALA_JSON": "1",
            "JAALA_WEBSOCKET_MESSAGE_REPLACE": "ws.example.com/socket=hello>>>world",
        },
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow(
        from_client=False,
        text="hello from jaala",
        content=b"hello from jaala",
    )
    addon.websocket_message(flow)

    record = json.loads(capsys.readouterr().out.strip())
    assert flow.websocket.messages[-1].content == b"world from jaala"
    assert flow.websocket.messages[-1].text == "world from jaala"
    assert record["direction"] == "server_to_client"
    assert record["message"]["text"] == "world from jaala"


def test_websocket_message_replace_skips_nonmatching_url(capsys):
    with patch.dict(
        os.environ,
        {
            "JAALA_JSON": "1",
            "JAALA_WEBSOCKET_MESSAGE_REPLACE": "payments=hello>>>world",
        },
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow(text="hello from jaala", content=b"hello from jaala")
    addon.websocket_message(flow)

    record = json.loads(capsys.readouterr().out.strip())
    assert flow.websocket.messages[-1].content == b"hello from jaala"
    assert flow.websocket.messages[-1].text == "hello from jaala"
    assert record["message"]["text"] == "hello from jaala"


def test_websocket_message_replace_skips_binary_message(capsys):
    with patch.dict(
        os.environ,
        {
            "JAALA_JSON": "1",
            "JAALA_WEBSOCKET_MESSAGE_REPLACE": "ws.example.com/socket=hello>>>world",
        },
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow(from_client=False, is_text=False, text=None, content=b"\x00\x01\x02")
    addon.websocket_message(flow)

    record = json.loads(capsys.readouterr().out.strip())
    assert flow.websocket.messages[-1].content == b"\x00\x01\x02"
    assert flow.websocket.messages[-1].text is None
    assert record["opcode"] == "binary"
    assert "text" not in record["message"]


def test_websocket_drop_message_skips_capture(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_WEBSOCKET_DROP_MESSAGE": json.dumps(["ws.example.com/socket"])},
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow()
    addon.websocket_message(flow)

    assert capsys.readouterr().out == ""
    assert flow.metadata["jaala_websocket_dropped"] is True
    assert flow.metadata["jaala_websocket_drop_message"] is True
    assert flow.websocket.messages[-1].dropped is True


def test_websocket_drop_message_uses_message_drop_method(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_WEBSOCKET_DROP_MESSAGE": json.dumps(["ws.example.com/socket"])},
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow()
    dropped = []

    def drop():
        dropped.append(True)

    flow.websocket.messages[-1].drop = drop
    addon.websocket_message(flow)

    assert capsys.readouterr().out == ""
    assert dropped == [True]


def test_websocket_fail_rate_drops_matching_message(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_WEBSOCKET_FAIL_RATE": json.dumps(["ws.example.com/socket=100"])},
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow()
    addon.websocket_message(flow)

    assert capsys.readouterr().out == ""
    assert flow.metadata["jaala_websocket_dropped"] is True
    assert flow.metadata["jaala_websocket_fail_rate"] is True
    assert flow.metadata["jaala_websocket_fail_rate_percent"] == 100


def test_websocket_delay_sleeps_and_captures_message(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_WEBSOCKET_DELAY": json.dumps(["ws.example.com/socket=250"])},
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow()
    with patch("jaala.websocket_message_rules.time.sleep") as mock_sleep:
        addon.websocket_message(flow)

    record = json.loads(capsys.readouterr().out.strip())
    mock_sleep.assert_called_once_with(0.25)
    assert flow.metadata["jaala_websocket_delayed_ms"] == 250
    assert record["message"]["text"] == "jaala websocket ping"


def test_websocket_throttle_sleeps_based_on_message_size(capsys):
    with patch.dict(
        os.environ,
        {"JAALA_JSON": "1", "JAALA_WEBSOCKET_THROTTLE": json.dumps(["ws.example.com/socket=1"])},
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow(text="abcd", content=b"abcd")
    with patch("jaala.websocket_message_rules.time.sleep") as mock_sleep:
        addon.websocket_message(flow)

    record = json.loads(capsys.readouterr().out.strip())
    mock_sleep.assert_called_once_with(4 / 1024)
    assert flow.metadata["jaala_websocket_throttled_kbps"] == 1
    assert record["message"]["text"] == "abcd"
