"""Response simulation rules for Jaala."""

from __future__ import annotations

import json
import mimetypes
import os
import time
import gzip
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import unquote_plus
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from collections.abc import Callable, Mapping

from .filtering import build_matcher, load_merged_config

ENV_CONFIG = "JAALA_CONFIG"

RESPONSE_KEYS = ("map_local", "map_remote", "status_code", "add_header", "response_text_replace")
RUNTIME_RESPONSE_RULES_KEY = "_jaala_runtime_response_rules"
_DROP_HEADERS = {"connection", "content-length", "transfer-encoding"}
_MUTATED_BODY_DROP_HEADERS = {
    "accept-ranges",
    "content-encoding",
    "content-md5",
    "content-range",
    "digest",
    "etag",
    "last-modified",
}
_CONDITIONAL_REQUEST_DROP_HEADERS = {
    "if-modified-since",
    "if-none-match",
}
_CONDITIONAL_BODY_REPLACE_WARNING = "jaala_conditional_response_text_replace_warning"
_RESPONSE_RULE_EVENTS = "jaala_response_rule_events"
_STREAM_BODY_REPLACE_STATE = "jaala_stream_response_text_replace_state"
_REQ_CONTAINS_MARKERS = ("?req_contains=", "&req_contains=")


class CaseInsensitiveHeaders(dict):
    def get(self, key, default=None):  # noqa: D401
        for existing_key, value in self.items():
            if existing_key.lower() == key.lower():
                return value
        return default


def _normalize(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _split_once(value: str, separator: str, label: str) -> tuple[str, str]:
    left, found, right = value.partition(separator)
    if not found or not left.strip() or not right.strip():
        raise ValueError(f"Invalid {label} rule {value!r}")
    return left.strip(), right.strip()


def _split_response_text_replace_rule(value: str) -> tuple[str, str | None, str, str]:
    left, found, replace = value.partition(">>>")
    if not found or not left.strip() or not replace.strip():
        raise ValueError(f"Invalid response-text-replace replacement rule {value!r}")

    for marker in _REQ_CONTAINS_MARKERS:
        marker_index = left.find(marker)
        if marker_index < 0:
            continue
        request_body_start = marker_index + len(marker)
        search_separator = left.find("=", request_body_start)
        if search_separator < 0:
            raise ValueError(f"Invalid response-text-replace rule {value!r}")
        pattern = left[:marker_index].strip()
        request_body_contains = unquote_plus(left[request_body_start:search_separator].strip())
        search = left[search_separator + 1 :].strip()
        if not pattern or not request_body_contains or not search:
            raise ValueError(f"Invalid response-text-replace rule {value!r}")
        return pattern, request_body_contains, search, replace.strip()

    pattern, search = _split_once(left, "=", "response-text-replace")
    return pattern, None, search, replace.strip()


def _content_bytes(content: bytes | bytearray | memoryview | None) -> bytes:
    if content is None:
        return b""
    if isinstance(content, bytes):
        return content
    if isinstance(content, bytearray):
        return bytes(content)
    if isinstance(content, memoryview):
        return content.tobytes()
    return bytes(content)


def _decode_body(content: bytes | bytearray | memoryview | None) -> str | None:
    data = _content_bytes(content)
    if not data:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _decode_compressed_body(content: bytes | bytearray | memoryview | None, headers) -> str | None:
    data = _content_bytes(content)
    if not data:
        return None

    encoding = _normalize(_case_insensitive_headers(headers).get("content-encoding"))
    if encoding is None:
        return _decode_body(data)

    try:
        if encoding == "gzip":
            return gzip.decompress(data).decode("utf-8")
        if encoding == "deflate":
            return zlib.decompress(data).decode("utf-8")
        if encoding == "br":
            import brotli  # type: ignore

            return brotli.decompress(data).decode("utf-8")
    except Exception:
        return _decode_body(data)

    return _decode_body(data)


def _parse_json_body(content: bytes | bytearray | memoryview | None, headers) -> object | None:
    text = _decode_compressed_body(content, headers)
    if text is None:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def _encode_json_body(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _parse_json_path(path: str) -> list[str]:
    parts = [part.strip() for part in path.split(".")]
    if not parts or any(not part for part in parts):
        raise ValueError(f"Invalid json-replace path {path!r}")
    return parts


def _normalize_json_replace_rule(rule: object, *, source: str) -> dict[str, object]:
    if not isinstance(rule, dict):
        raise ValueError(f"{source} field 'json_replace' must be an object")

    match_url = _normalize(rule.get("match_url"))
    json_path = _normalize(rule.get("json_path"))
    if match_url is None or json_path is None:
        raise ValueError(f"{source} field 'json_replace' requires non-empty 'match_url' and 'json_path'")

    _parse_json_path(json_path)

    if "value" not in rule:
        raise ValueError(f"{source} field 'json_replace' requires a 'value'")

    return {
        "match_url": match_url,
        "json_path": json_path,
        "value": rule.get("value"),
    }


def _replace_json_path(value: object, path: list[str], replacement: object) -> tuple[object, int]:
    if not path:
        return replacement, 1

    head, *tail = path

    if head == "*":
        if isinstance(value, dict):
            mutated = 0
            updated: dict[object, object] = {}
            for key, child in value.items():
                next_child, child_mutated = _replace_json_path(child, tail, replacement)
                updated[key] = next_child
                mutated += child_mutated
            return updated, mutated
        if isinstance(value, list):
            mutated = 0
            updated_list: list[object] = []
            for child in value:
                next_child, child_mutated = _replace_json_path(child, tail, replacement)
                updated_list.append(next_child)
                mutated += child_mutated
            return updated_list, mutated
        return value, 0

    if isinstance(value, list):
        try:
            index = int(head)
        except ValueError:
            return value, 0
        if index < 0 or index >= len(value):
            return value, 0
        next_child, mutated = _replace_json_path(value[index], tail, replacement)
        if mutated == 0:
            return value, 0
        updated_list = list(value)
        updated_list[index] = next_child
        return updated_list, mutated

    if isinstance(value, dict):
        if head not in value:
            return value, 0
        next_child, mutated = _replace_json_path(value[head], tail, replacement)
        if mutated == 0:
            return value, 0
        updated = dict(value)
        updated[head] = next_child
        return updated, mutated

    return value, 0


def _case_insensitive_headers(headers: Mapping[str, str] | None = None) -> CaseInsensitiveHeaders:
    return CaseInsensitiveHeaders(headers or {})


def _make_response(status_code: int, content: bytes, headers: Mapping[str, str]) -> object:
    try:
        from mitmproxy.http import Response
    except ImportError:
        return SimpleNamespace(
            status_code=status_code,
            headers=_case_insensitive_headers(headers),
            content=content,
            timestamp_end=time.time(),
            http_version="HTTP/1.1",
        )

    try:
        response = Response.make(status_code, content, dict(headers))
    except Exception:
        return SimpleNamespace(
            status_code=status_code,
            headers=_case_insensitive_headers(headers),
            content=content,
            timestamp_end=time.time(),
            http_version="HTTP/1.1",
        )
    return response


def _set_header(headers, name: str, value: str) -> None:
    _drop_header(headers, name)
    headers[name] = value


def _drop_header(headers, name: str) -> None:
    keys = [existing_key for existing_key in headers.keys() if existing_key.lower() == name.lower()]
    for key in keys:
        try:
            del headers[key]
        except Exception:
            pass


def _set_text_body(response, text: str) -> bytes:
    return _set_raw_body(response, text.encode("utf-8"))


def _set_raw_body(response, content: bytes) -> bytes:
    if hasattr(response, "raw_content"):
        try:
            response.raw_content = content
            return _content_bytes(getattr(response, "raw_content", None))
        except Exception:
            pass
    try:
        response.content = content
    except Exception:
        try:
            setattr(response, "content", content)
        except Exception:
            return _content_bytes(getattr(response, "content", None))
    return _content_bytes(getattr(response, "content", None))


def _encode_mutated_text_body(text: str, headers) -> tuple[bytes, str | None]:
    encoded = text.encode("utf-8")
    content_encoding = _normalize(_case_insensitive_headers(headers).get("content-encoding"))

    if content_encoding == "gzip":
        return gzip.compress(encoded), "gzip"

    return encoded, None


def _refresh_mutated_body_headers(headers, content: bytes, *, content_encoding: str | None = None) -> None:
    for name in _MUTATED_BODY_DROP_HEADERS:
        _drop_header(headers, name)
    _drop_header(headers, "transfer-encoding")
    if content_encoding is not None:
        _set_header(headers, "content-encoding", content_encoding)
    _set_header(headers, "content-length", str(len(content)))


def _content_encoding(headers) -> str | None:
    return _normalize(_case_insensitive_headers(headers).get("content-encoding"))


def _can_stream_text_replace(headers) -> bool:
    encoding = _content_encoding(headers)
    return encoding is None or encoding == "identity"


class StreamingBodyReplaceProcessor:
    """Apply text replacement to a byte stream without buffering the full body."""

    def __init__(self, search: str, replace: str) -> None:
        self.search = search
        self.replace = replace
        self._pending = ""
        self.mutated_chunks = 0

    def process(self, chunk: bytes | bytearray | memoryview | None) -> bytes:
        data = _content_bytes(chunk)
        if not data:
            return b""
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return data

        combined = self._pending + text
        replaced_combined = combined.replace(self.search, self.replace)
        if replaced_combined != combined:
            self.mutated_chunks += 1

        if len(self.search) <= 1:
            safe_text = replaced_combined
            self._pending = ""
        else:
            keep = min(len(self.search) - 1, len(replaced_combined))
            safe_text = replaced_combined[:-keep] if keep else replaced_combined
            self._pending = replaced_combined[-keep:] if keep else ""

        return safe_text.encode("utf-8")

    def finish(self) -> bytes:
        if not self._pending:
            return b""
        pending = self._pending
        self._pending = ""
        replaced = pending.replace(self.search, self.replace)
        if replaced != pending:
            self.mutated_chunks += 1
        return replaced.encode("utf-8")


def _build_local_response(path: str) -> object:
    file_path = Path(path)
    try:
        content = file_path.read_bytes()
    except OSError as exc:
        message = f"Jaala map-local error: {exc}".encode("utf-8")
        return _make_response(500, message, {"content-type": "text/plain; charset=utf-8"})

    headers: dict[str, str] = {}
    mime_type, _ = mimetypes.guess_type(file_path.name)
    if mime_type:
        headers["content-type"] = mime_type
    headers["content-length"] = str(len(content))
    return _make_response(200, content, headers)


def _build_remote_response(url: str) -> object:
    request = Request(url, headers={"User-Agent": "Jaala/0.1.0"})
    try:
        with urlopen(request, timeout=10) as upstream:
            content = upstream.read()
            status_code = getattr(upstream, "status", 200) or 200
            headers = {
                name: value
                for name, value in upstream.headers.items()
                if name.lower() not in _DROP_HEADERS
            }
    except (HTTPError, URLError, OSError) as exc:
        message = f"Jaala map-remote error: {exc}".encode("utf-8")
        return _make_response(502, message, {"content-type": "text/plain; charset=utf-8"})

    if "content-length" not in {name.lower() for name in headers}:
        headers["content-length"] = str(len(content))
    return _make_response(status_code, content, headers)


@dataclass(slots=True)
class ResponseTextReplaceRule:
    matcher: Callable[[str], bool]
    request_body_contains: str | None
    search: str
    replace: str

    def matches(self, flow, url: str) -> bool:
        if not self.matcher(url):
            return False
        if self.request_body_contains is None:
            return True
        request = getattr(flow, "request", None)
        text = _decode_body(getattr(request, "content", None))
        return text is not None and self.request_body_contains in text


@dataclass(slots=True)
class ResponseRuleSet:
    map_local: tuple[Callable[[str], bool], str] | None = None
    map_remote: tuple[Callable[[str], bool], str] | None = None
    status_code: tuple[Callable[[str], bool], int] | None = None
    add_header: tuple[Callable[[str], bool], tuple[str, str]] | None = None
    response_text_replace: list[ResponseTextReplaceRule] = field(default_factory=list)
    json_replace: tuple[Callable[[str], bool], tuple[list[str], object]] | None = None

    def _flow_metadata(self, flow) -> dict:
        metadata = getattr(flow, "metadata", None)
        if metadata is None:
            metadata = {}
            flow.metadata = metadata
        return metadata

    def _record_event(self, flow, event: str, **details) -> None:
        metadata = self._flow_metadata(flow)
        events = metadata.setdefault(_RESPONSE_RULE_EVENTS, [])
        if isinstance(events, list):
            payload = {"event": event}
            payload.update(details)
            events.append(payload)

    def _url(self, flow) -> str:
        return getattr(flow.request, "pretty_url", "")

    def _match(self, rule: tuple[Callable[[str], bool], object] | None, url: str) -> bool:
        if rule is None:
            return False
        matcher, _ = rule
        return matcher(url)

    def build_stream_response_text_replace_processor(self, flow) -> StreamingBodyReplaceProcessor | None:
        if not self.response_text_replace:
            return None
        url = self._url(flow)
        matched_rule: ResponseTextReplaceRule | None = None
        for rule in self.response_text_replace:
            if rule.matches(flow, url):
                matched_rule = rule
                break
        if matched_rule is None:
            return None
        response = getattr(flow, "response", None)
        headers = getattr(response, "headers", None)
        if not _can_stream_text_replace(headers):
            self._record_event(flow, "stream_response_text_replace_skipped_encoded", url=url)
            return None
        metadata = self._flow_metadata(flow)
        metadata[_STREAM_BODY_REPLACE_STATE] = {
            "url": url,
            "search": matched_rule.search,
            "replace": matched_rule.replace,
            "mutated_chunks": 0,
        }
        return StreamingBodyReplaceProcessor(matched_rule.search, matched_rule.replace)

    def record_stream_response_text_replace_result(self, flow, processor: StreamingBodyReplaceProcessor) -> None:
        metadata = self._flow_metadata(flow)
        state = metadata.get(_STREAM_BODY_REPLACE_STATE)
        url = self._url(flow)
        if isinstance(state, dict):
            state["mutated_chunks"] = processor.mutated_chunks
        if processor.mutated_chunks > 0:
            self._record_event(flow, "stream_response_text_replace_applied", url=url, chunks=processor.mutated_chunks)
        else:
            search = state.get("search") if isinstance(state, dict) else None
            self._record_event(flow, "stream_response_text_replace_search_not_found", url=url, search=search)

    def _build_synthetic_response(self, url: str) -> object | None:
        if self.map_local is not None and self.map_local[0](url):
            return _build_local_response(self.map_local[1])
        if self.map_remote is not None and self.map_remote[0](url):
            return _build_remote_response(self.map_remote[1])
        return None

    def _prepare_request_for_response_text_replace(self, flow) -> bool:
        if not self.response_text_replace:
            return False

        metadata = self._flow_metadata(flow)
        url = self._url(flow)
        if not any(rule.matches(flow, url) for rule in self.response_text_replace):
            return False

        request = flow.request
        present_headers: list[str] = []
        for name in _CONDITIONAL_REQUEST_DROP_HEADERS:
            if _case_insensitive_headers(request.headers).get(name) is not None:
                present_headers.append(name)
        if present_headers:
            metadata[_CONDITIONAL_BODY_REPLACE_WARNING] = {
                "url": url,
                "headers": sorted(present_headers),
            }
            self._record_event(flow, "response_text_replace_conditional_request", url=url, headers=sorted(present_headers))
        return False

    def _apply_post_response_rules(self, flow, response) -> bool:
        url = self._url(flow)
        mutated = False

        if self.status_code is not None and self.status_code[0](url):
            response.status_code = self.status_code[1]
            self._record_event(flow, "status_code_applied", url=url, status_code=self.status_code[1])
            mutated = True

        if self.add_header is not None and self.add_header[0](url):
            name, value = self.add_header[1]
            _set_header(response.headers, name, value)
            self._record_event(flow, "add_header_applied", url=url, header=name, value=value)
            mutated = True

        for rule in self.response_text_replace:
            if not rule.matches(flow, url):
                continue
            text = _decode_compressed_body(getattr(response, "content", None), getattr(response, "headers", None))
            if text is None:
                self._record_event(flow, "response_text_replace_skipped_undecodable", url=url)
                continue
            if rule.search not in text:
                self._record_event(flow, "response_text_replace_search_not_found", url=url, search=rule.search)
                continue
            new_text = text.replace(rule.search, rule.replace)
            encoded_content, preserved_encoding = _encode_mutated_text_body(new_text, response.headers)
            content = _set_raw_body(response, encoded_content)
            try:
                _refresh_mutated_body_headers(response.headers, content, content_encoding=preserved_encoding)
            except Exception:
                pass
            self._record_event(
                flow,
                "response_text_replace_applied",
                url=url,
                search=rule.search,
                replace=rule.replace,
                bytes=len(content),
            )
            mutated = True

        if self.json_replace is not None and self.json_replace[0](url):
            path, replacement = self.json_replace[1]
            parsed = _parse_json_body(getattr(response, "content", None), getattr(response, "headers", None))
            if parsed is None:
                self._record_event(flow, "json_replace_skipped_invalid_json", url=url, path=".".join(path))
            else:
                updated_value, mutated_count = _replace_json_path(parsed, path, replacement)
                if mutated_count > 0:
                    encoded_content, preserved_encoding = _encode_mutated_text_body(
                        _encode_json_body(updated_value),
                        response.headers,
                    )
                    content = _set_raw_body(response, encoded_content)
                    try:
                        _refresh_mutated_body_headers(response.headers, content, content_encoding=preserved_encoding)
                    except Exception:
                        pass
                    self._record_event(
                        flow,
                        "json_replace_applied",
                        url=url,
                        path=".".join(path),
                        matches=mutated_count,
                        bytes=len(content),
                    )
                    mutated = True
                else:
                    self._record_event(flow, "json_replace_path_not_found", url=url, path=".".join(path))

        return mutated

    def apply_response_headers(self, flow) -> bool:
        response = getattr(flow, "response", None)
        if response is None:
            return False
        url = self._url(flow)
        mutated = False

        if self.status_code is not None and self.status_code[0](url):
            response.status_code = self.status_code[1]
            self._record_event(flow, "status_code_applied", url=url, status_code=self.status_code[1])
            mutated = True

        if self.add_header is not None and self.add_header[0](url):
            name, value = self.add_header[1]
            _set_header(response.headers, name, value)
            self._record_event(flow, "add_header_applied", url=url, header=name, value=value)
            mutated = True

        return mutated

    def apply_request(self, flow) -> bool:
        metadata = self._flow_metadata(flow)
        if metadata.get("jaala_response_rules_applied"):
            return False

        if getattr(flow, "response", None) is not None:
            return False

        mutated = self._prepare_request_for_response_text_replace(flow)
        url = self._url(flow)
        synthetic = self._build_synthetic_response(url)
        if synthetic is None:
            return mutated

        flow.response = synthetic
        self._record_event(flow, "synthetic_response_created", url=url)
        self._apply_post_response_rules(flow, synthetic)
        metadata["jaala_response_rules_applied"] = True
        return True

    def apply_response(self, flow) -> bool:
        metadata = self._flow_metadata(flow)
        if metadata.get("jaala_response_rules_applied"):
            return False

        url = self._url(flow)
        synthetic = self._build_synthetic_response(url)
        if synthetic is not None:
            flow.response = synthetic
            self._record_event(flow, "synthetic_response_created", url=url)
            self._apply_post_response_rules(flow, synthetic)
            metadata["jaala_response_rules_applied"] = True
            return True

        response = getattr(flow, "response", None)
        if response is None:
            return False
        return self._apply_post_response_rules(flow, response)


def _runtime_response_rules(settings: Mapping[str, object]) -> list[dict[str, object]]:
    raw_rules = settings.get(RUNTIME_RESPONSE_RULES_KEY)
    if not isinstance(raw_rules, list):
        return []
    return [rule for rule in raw_rules if isinstance(rule, dict)]


def _active_runtime_response_rule(
    settings: Mapping[str, object],
    rule_type: str,
) -> dict[str, object] | None:
    active: dict[str, object] | None = None
    for rule in _runtime_response_rules(settings):
        if rule.get("type") != rule_type or not rule.get("enabled", True):
            continue
        active = rule
    return active


def build_response_rules(settings: Mapping[str, object] | None = None) -> ResponseRuleSet:
    settings = settings or {}

    map_local = _normalize(settings.get("map_local"))
    map_remote = _normalize(settings.get("map_remote"))
    status_code = _normalize(settings.get("status_code"))
    add_header = _normalize(settings.get("add_header"))
    response_text_replace = settings.get("response_text_replace")
    json_replace = settings.get("json_replace")

    compiled = ResponseRuleSet()

    if map_local is not None:
        pattern, path = _split_once(map_local, "=", "map-local")
        matcher = build_matcher(pattern)
        compiled.map_local = (matcher, path)

    if map_remote is not None:
        pattern, url = _split_once(map_remote, "=", "map-remote")
        matcher = build_matcher(pattern)
        compiled.map_remote = (matcher, url)

    if status_code is not None:
        pattern, code_text = _split_once(status_code, "=", "status-code")
        matcher = build_matcher(pattern)
        try:
            code = int(code_text)
        except ValueError as exc:
            raise ValueError(f"Invalid status-code rule {status_code!r}: {code_text!r} is not an integer") from exc
        if code < 100 or code > 599:
            raise ValueError(f"Invalid status-code rule {status_code!r}: code must be between 100 and 599")
        compiled.status_code = (matcher, code)

    if add_header is not None:
        pattern, header_text = _split_once(add_header, "=", "add-header")
        matcher = build_matcher(pattern)
        header_name, header_value = _split_once(header_text, ":", "add-header header")
        compiled.add_header = (matcher, (header_name, header_value))

    if isinstance(response_text_replace, str):
        normalized_response_text_replace = _normalize(response_text_replace)
        if normalized_response_text_replace is not None:
            pattern, request_body_contains, search, replace = _split_response_text_replace_rule(normalized_response_text_replace)
            matcher = build_matcher(pattern)
            compiled.response_text_replace.append(ResponseTextReplaceRule(matcher, request_body_contains, search, replace))
    elif isinstance(response_text_replace, list):
        for value in response_text_replace:
            if not isinstance(value, str):
                raise ValueError("Response settings field 'response_text_replace' list entries must be strings")
            normalized_response_text_replace = _normalize(value)
            if normalized_response_text_replace is None:
                continue
            pattern, request_body_contains, search, replace = _split_response_text_replace_rule(normalized_response_text_replace)
            matcher = build_matcher(pattern)
            compiled.response_text_replace.append(ResponseTextReplaceRule(matcher, request_body_contains, search, replace))
    elif response_text_replace is not None:
        raise ValueError("Response settings field 'response_text_replace' must be a string or list of strings")

    if json_replace is not None:
        normalized_json_replace = _normalize_json_replace_rule(json_replace, source="Response settings")
        compiled.json_replace = (
            build_matcher(str(normalized_json_replace["match_url"])),
            (_parse_json_path(str(normalized_json_replace["json_path"])), normalized_json_replace["value"]),
        )

    active_response_text_replace = _active_runtime_response_rule(settings, "response_text_replace")
    if active_response_text_replace is not None:
        match_url = _normalize(str(active_response_text_replace.get("match_url", "")))
        search = _normalize(str(active_response_text_replace.get("search", "")))
        request_body_contains_value = active_response_text_replace.get("request_body_contains")
        request_body_contains = (
            str(request_body_contains_value)
            if request_body_contains_value is not None
            else None
        )
        replace = active_response_text_replace.get("replace")
        if match_url is None or search is None or not isinstance(replace, str):
            raise ValueError(f"Invalid runtime response_text_replace rule {active_response_text_replace!r}")
        compiled.response_text_replace = [
            ResponseTextReplaceRule(build_matcher(match_url), request_body_contains, search, replace)
        ]

    active_json_replace = _active_runtime_response_rule(settings, "json_replace")
    if active_json_replace is not None:
        match_url = _normalize(str(active_json_replace.get("match_url", "")))
        json_path = _normalize(str(active_json_replace.get("json_path", "")))
        if match_url is None or json_path is None:
            raise ValueError(f"Invalid runtime json_replace rule {active_json_replace!r}")
        compiled.json_replace = (
            build_matcher(match_url),
            (_parse_json_path(json_path), active_json_replace.get("value")),
        )

    return compiled


def load_response_config(path: str | None, profile: str | None = None) -> dict[str, object]:
    data = load_merged_config(path, profile=profile)
    if "body_replace" in data:
        raise ValueError(
            f"Response config {path!r} field 'body_replace' is no longer supported; "
            "use 'response_text_replace'"
        )

    result: dict[str, object] = {}
    for key in RESPONSE_KEYS:
        value = data.get(key)
        if value is None:
            continue
        if key == "response_text_replace" and isinstance(value, list):
            normalized_values: list[str] = []
            for item in value:
                if not isinstance(item, str):
                    raise ValueError(f"Response config {path!r} field {key!r} list entries must be strings")
                normalized = _normalize(item)
                if normalized is not None:
                    normalized_values.append(normalized)
            if normalized_values:
                result[key] = normalized_values
            continue
        if not isinstance(value, str):
            raise ValueError(f"Response config {path!r} field {key!r} must be a string")
        normalized = _normalize(value)
        if normalized is not None:
            result[key] = normalized
    if "json_replace" in data:
        result["json_replace"] = _normalize_json_replace_rule(
            data.get("json_replace"),
            source=f"Response config {path!r}",
        )
    runtime_metadata = data.get("_jaala_runtime")
    if isinstance(runtime_metadata, dict):
        rules = runtime_metadata.get("rules")
        if isinstance(rules, list):
            result[RUNTIME_RESPONSE_RULES_KEY] = [
                rule
                for rule in rules
                if isinstance(rule, dict) and rule.get("type") in {"response_text_replace", "json_replace"}
            ]
    return result


def resolve_response_settings(
    *,
    config_path: str | None = None,
    config_profile: str | None = None,
    env: Mapping[str, str] | None = None,
    map_local: str | None = None,
    map_remote: str | None = None,
    status_code: str | None = None,
    add_header: str | None = None,
    response_text_replace: str | None = None,
) -> dict[str, object]:
    env = env or os.environ
    resolved = load_response_config(config_path or env.get(ENV_CONFIG), profile=config_profile)

    cli_map_local = _normalize(map_local)
    if cli_map_local is not None:
        resolved["map_local"] = cli_map_local

    cli_map_remote = _normalize(map_remote)
    if cli_map_remote is not None:
        resolved["map_remote"] = cli_map_remote

    cli_status_code = _normalize(status_code)
    if cli_status_code is not None:
        resolved["status_code"] = cli_status_code

    cli_add_header = _normalize(add_header)
    if cli_add_header is not None:
        resolved["add_header"] = cli_add_header

    cli_response_text_replace = _normalize(response_text_replace)
    if cli_response_text_replace is not None:
        resolved["response_text_replace"] = cli_response_text_replace

    return resolved
