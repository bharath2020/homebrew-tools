# Simulator-only mode investigation

Jaala intentionally does not support a simulator-only capture mode.

The short version: certificate trust is necessary for HTTPS interception, but it does not route traffic through the proxy. On this machine, `xcrun simctl help` shows keychain support, including `add-root-cert`, but it does not document any proxy-routing command for a booted Simulator. The supported and reliable capture path remains the macOS host proxy.

What that means in practice:

- `simctl keychain <device> add-root-cert` can trust the MITM CA inside the Simulator.
- That trust step alone does not force app traffic through Jaala.
- Without host proxy configuration, the Simulator app traffic still goes directly to the network.
- Jaala therefore uses the macOS host proxy path for real capture and replay validation.

Relevant references:

- mitmproxy documents the iOS Simulator setup as: configure the macOS machine running the emulator to use the proxy, then install and trust the CA in the Simulator: [mitmproxy certificates](https://docs.mitmproxy.org/stable/concepts/certificates/)
- Proxyman’s iOS Simulator guide also pairs certificate installation/trust with simulator setup and reset, rather than exposing a simulator-local routing command: [Proxyman iOS Simulator](https://docs.proxyman.com/debug-devices/ios-simulator)
- Apple’s deployment guide describes Global HTTP Proxy as a managed device-level setting that specifies proxy traffic for Apple devices, which aligns with the host-proxy approach: [Apple Global HTTP Proxy payload](https://support.apple.com/en-lamr/guide/deployment/dep7ba46fcd/web)

Conclusion: Jaala keeps one supported Simulator capture path, the macOS host proxy, because CA trust by itself is not a routing mechanism and no documented `simctl` proxy-routing command exists.
