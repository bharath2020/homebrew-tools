from __future__ import annotations

import json
import socket
import threading
import time
from unittest.mock import MagicMock, patch

import pytest

from jaala.proxy import ADDON_PATH, _find_upstream_trusted_ca, _wait_for_port, find_free_port, start_mitmdump


def test_find_free_port_returns_valid_port():
    port = find_free_port()
    assert isinstance(port, int)
    assert 1024 <= port <= 65535


def test_addon_path_exists():
    assert ADDON_PATH.exists()
    assert ADDON_PATH.name == "addon.py"


def test_wait_for_port_returns_true_when_listening():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 0))
    port = server.getsockname()[1]
    server.listen(1)
    try:
        assert _wait_for_port(port, timeout=2.0, interval=0.05) is True
    finally:
        server.close()


def test_wait_for_port_returns_false_when_not_listening():
    port = find_free_port()
    assert _wait_for_port(port, timeout=0.2, interval=0.05) is False


def test_wait_for_port_waits_for_delayed_listener():
    port = find_free_port()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def start_delayed():
        time.sleep(0.15)
        server.bind(("127.0.0.1", port))
        server.listen(1)

    thread = threading.Thread(target=start_delayed)
    thread.start()
    try:
        assert _wait_for_port(port, timeout=2.0, interval=0.05) is True
    finally:
        server.close()
        thread.join()


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_json_and_artifact_envs(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    result = start_mitmdump(
        port=8080,
        json_mode=True,
        json_file="/tmp/traffic.jsonl",
        save_har="/tmp/traffic.har",
        no_headers=True,
        no_body=True,
        output_file="/tmp/traffic.flow",
        quiet=True,
    )

    assert result is proc
    call_kwargs = mock_popen.call_args.kwargs
    env = call_kwargs["env"]
    assert env["JAALA_JSON"] == "1"
    assert env["JAALA_JSON_FILE"] == "/tmp/traffic.jsonl"
    assert env["JAALA_HAR_FILE"] == "/tmp/traffic.har"
    assert env["JAALA_NO_HEADERS"] == "1"
    assert env["JAALA_NO_BODY"] == "1"
    assert env["JAALA_WEBSOCKETS"] == "1"
    assert env["JAALA_NO_WEBSOCKETS"] == "0"
    assert env["JAALA_QUIET"] == "1"
    assert "-w" in mock_popen.call_args.args[0]
    assert "/tmp/traffic.flow" in mock_popen.call_args.args[0]


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_verbose_env_and_event_log_level(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(port=8080, verbose=True)

    env = mock_popen.call_args.kwargs["env"]
    cmd = mock_popen.call_args.args[0]
    assert env["JAALA_VERBOSE"] == "1"
    assert "console_eventlog_verbosity=info" in cmd


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_filter_envs(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(port=8080, config_path="/tmp/runtime-rules.json", runtime_status_file="/tmp/runtime-status.json")

    env = mock_popen.call_args.kwargs["env"]
    assert env["JAALA_CONFIG"] == "/tmp/runtime-rules.json"
    assert env["JAALA_RUNTIME_STATUS_FILE"] == "/tmp/runtime-status.json"


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_can_disable_websockets(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(port=8080, no_websockets=True)

    env = mock_popen.call_args.kwargs["env"]
    assert env["JAALA_WEBSOCKETS"] == "0"
    assert env["JAALA_NO_WEBSOCKETS"] == "1"


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_response_envs(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(port=8080)

    env = mock_popen.call_args.kwargs["env"]
    assert "JAALA_MAP_LOCAL" not in env
    assert "JAALA_MAP_REMOTE" not in env
    assert "JAALA_STATUS_CODE" not in env
    assert "JAALA_ADD_HEADER" not in env
    assert "JAALA_BODY_REPLACE" not in env


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_request_envs(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(port=8080)

    env = mock_popen.call_args.kwargs["env"]
    assert "JAALA_REQUEST_HEADER" not in env
    assert "JAALA_REQUEST_BODY_REPLACE" not in env


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_websocket_message_env(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(
        port=8080,
        websocket_message_replace="ws.example.com/socket=hello>>>world",
    )

    env = mock_popen.call_args.kwargs["env"]
    assert env["JAALA_WEBSOCKET_MESSAGE_REPLACE"] == "ws.example.com/socket=hello>>>world"


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_websocket_drop_envs(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(
        port=8080,
        websocket_drop_message=["ws.example.com/drop"],
        websocket_fail_rate=["ws.example.com/flaky=100"],
        websocket_delay=["ws.example.com/slow=250"],
        websocket_throttle=["ws.example.com/large=1"],
    )

    env = mock_popen.call_args.kwargs["env"]
    assert json.loads(env["JAALA_WEBSOCKET_DROP_MESSAGE"]) == ["ws.example.com/drop"]
    assert json.loads(env["JAALA_WEBSOCKET_FAIL_RATE"]) == ["ws.example.com/flaky=100"]
    assert json.loads(env["JAALA_WEBSOCKET_DELAY"]) == ["ws.example.com/slow=250"]
    assert json.loads(env["JAALA_WEBSOCKET_THROTTLE"]) == ["ws.example.com/large=1"]


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_websocket_replay_envs(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(
        port=8080,
        websocket_replay_file="/tmp/ws.jsonl",
        websocket_replay_pattern="ws.example.com/socket",
    )

    env = mock_popen.call_args.kwargs["env"]
    assert env["JAALA_WEBSOCKET_REPLAY_FILE"] == "/tmp/ws.jsonl"
    assert env["JAALA_WEBSOCKET_REPLAY_PATTERN"] == "ws.example.com/socket"


@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_passes_network_condition_envs(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    mock_popen.return_value = proc

    start_mitmdump(port=8080)

    env = mock_popen.call_args.kwargs["env"]
    assert "JAALA_DELAY" not in env
    assert "JAALA_THROTTLE" not in env
    assert "JAALA_DROP_CONNECTION" not in env
    assert "JAALA_FAIL_RATE" not in env


@patch("jaala.proxy._wait_for_port", return_value=False)
@patch("jaala.proxy.subprocess.Popen")
@patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
def test_start_mitmdump_exits_when_port_never_opens(mock_ca, mock_popen, mock_wait):
    proc = MagicMock()
    proc.poll.return_value = 1
    mock_popen.return_value = proc
    with pytest.raises(SystemExit):
        start_mitmdump(port=8080)


@patch("jaala.proxy._find_upstream_trusted_ca", return_value="/tmp/ca.pem")
@patch("jaala.proxy._wait_for_port", return_value=True)
@patch("jaala.proxy.subprocess.Popen")
def test_trusted_ca_bundle_passed_to_mitmdump(mock_popen, mock_wait, mock_ca):
    proc = MagicMock()
    mock_popen.return_value = proc
    start_mitmdump(port=8080)
    cmd = mock_popen.call_args.args[0]
    assert "ssl_verify_upstream_trusted_ca=/tmp/ca.pem" in cmd
