#!/usr/bin/env bash
# validate-streaming-axe.sh - Validate Jaala HTTP streaming capture and mutation end to end.

set -uo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

PASS=0
FAIL=0

APP_BUNDLE_ID="com.jaala.sample"
APP_PROJECT="$ROOT_DIR/sample-app/JaalaSample.xcodeproj"
APP_SCHEME="JaalaSample"
APP_DERIVED_DATA="$ROOT_DIR/sample-app/build"
APP_BINARY="$APP_DERIVED_DATA/Build/Products/Debug-iphonesimulator/JaalaSample.app"
STREAM_LABEL="HTTP stream: expect modified chunks"
ORIGINAL_TEXT="ORIGINAL_STREAM_VALUE"
REPLACED_TEXT="JAALA_STREAM_MODIFIED"
STREAM_DEMO_DURATION_SECONDS="${STREAM_DEMO_DURATION_SECONDS:-0}"
STREAM_SCROLL_LATEST="${STREAM_SCROLL_LATEST:-0}"

JAAALA_PORT=""
JAAALA_PID=""
STREAM_SERVER_PID=""
STREAM_PORT=""

OUTPUT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/jaala-streaming-XXXXXX")"
JAAALA_LOG="$OUTPUT_DIR/jaala.log"
STREAM_LOG="$OUTPUT_DIR/http-stream.log"
JSONL_FILE="$OUTPUT_DIR/traffic.jsonl"
HAR_FILE="$OUTPUT_DIR/traffic.har"
LATEST_SCREENSHOT="$OUTPUT_DIR/latest-stream-messages.png"
STREAM_PORT_FILE="$OUTPUT_DIR/stream-port.txt"
PROXY_BEFORE_HTTP="$OUTPUT_DIR/proxy-before-http.txt"
PROXY_BEFORE_HTTPS="$OUTPUT_DIR/proxy-before-https.txt"
PROXY_AFTER_HTTP="$OUTPUT_DIR/proxy-after-http.txt"
PROXY_AFTER_HTTPS="$OUTPUT_DIR/proxy-after-https.txt"
SIM_NAME=""
SIM_UDID=""
NETWORK_SERVICE=""
HOST_IP=""

cleanup() {
    if [[ -n "${SIM_UDID:-}" ]]; then
        xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
    fi
    stop_jaala >/dev/null 2>&1 || true

    if [[ -n "${STREAM_SERVER_PID:-}" ]] && kill -0 "$STREAM_SERVER_PID" >/dev/null 2>&1; then
        kill -TERM "$STREAM_SERVER_PID" >/dev/null 2>&1 || true
        for _ in {1..20}; do
            if ! kill -0 "$STREAM_SERVER_PID" >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
        if kill -0 "$STREAM_SERVER_PID" >/dev/null 2>&1; then
            kill -KILL "$STREAM_SERVER_PID" >/dev/null 2>&1 || true
        fi
        wait "$STREAM_SERVER_PID" >/dev/null 2>&1 || true
    fi

    if [[ -f "$HOME/.jaala/session.lock" ]]; then
        python3 -m jaala --cleanup >/dev/null 2>&1 || true
    fi
}

trap cleanup EXIT INT TERM

check() {
    local desc="$1"
    local result="${2:-false}"
    if [[ "$result" == "true" ]]; then
        echo -e "  ${GREEN}✓${NC} $desc"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}✗${NC} $desc"
        FAIL=$((FAIL + 1))
    fi
}

require_cmd() {
    local cmd="$1"
    if command -v "$cmd" >/dev/null 2>&1; then
        check "$cmd is installed" "true"
    else
        check "$cmd is installed" "false"
        exit 1
    fi
}

detect_active_service() {
    local service
    for service in "Wi-Fi" "Ethernet" "USB 10/100/1000 LAN"; do
        if networksetup -getinfo "$service" 2>/dev/null | grep -Fq "IP address"; then
            printf '%s' "$service"
            return 0
        fi
    done

    while IFS= read -r service; do
        service="${service#\*}"
        service="${service# }"
        service="${service% }"
        [[ -z "$service" ]] && continue
        if networksetup -getinfo "$service" 2>/dev/null | grep -Fq "IP address"; then
            printf '%s' "$service"
            return 0
        fi
    done < <(networksetup -listallnetworkservices 2>/dev/null | tail -n +2)

    return 1
}

detect_active_service_ip() {
    local info ip
    info="$(networksetup -getinfo "$NETWORK_SERVICE" 2>/dev/null || true)"
    ip="$(printf '%s\n' "$info" | awk -F': ' '/^IP address: / { print $2; exit }')"
    if [[ -z "$ip" ]]; then
        return 1
    fi
    printf '%s' "$ip"
}

capture_proxy_state() {
    networksetup -getwebproxy "$NETWORK_SERVICE" >"$PROXY_BEFORE_HTTP"
    networksetup -getsecurewebproxy "$NETWORK_SERVICE" >"$PROXY_BEFORE_HTTPS"
}

capture_proxy_state_after() {
    networksetup -getwebproxy "$NETWORK_SERVICE" >"$PROXY_AFTER_HTTP"
    networksetup -getsecurewebproxy "$NETWORK_SERVICE" >"$PROXY_AFTER_HTTPS"
}

assert_proxy_restored() {
    capture_proxy_state_after
    if cmp -s "$PROXY_BEFORE_HTTP" "$PROXY_AFTER_HTTP" && cmp -s "$PROXY_BEFORE_HTTPS" "$PROXY_AFTER_HTTPS"; then
        check "Host proxy settings are restored" "true"
    else
        check "Host proxy settings are restored" "false"
    fi
}

wait_for_port() {
    local host="$1"
    local port="$2"
    local timeout_seconds="$3"
    python3 - "$host" "$port" "$timeout_seconds" <<'PY'
import socket
import sys
import time

host = sys.argv[1]
port = int(sys.argv[2])
timeout = float(sys.argv[3])
deadline = time.monotonic() + timeout

while time.monotonic() < deadline:
    try:
        with socket.create_connection((host, port), timeout=0.2):
            sys.exit(0)
    except OSError:
        time.sleep(0.1)

sys.exit(1)
PY
}

wait_for_file() {
    local path="$1"
    local timeout_seconds="$2"
    local deadline=$(( $(date +%s) + timeout_seconds ))

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if [[ -s "$path" ]]; then
            return 0
        fi
        sleep 1
    done

    return 1
}

simulator_value() {
    local field="$1"
    printf '%s' "$SIM_JSON" | python3 -c '
import json
import sys

field = sys.argv[1]
data = json.load(sys.stdin)
for devices in data.get("devices", {}).values():
    for device in devices:
        if device.get("state") == "Booted":
            print(device.get(field, ""))
            raise SystemExit(0)
print("")
' "$field"
}

axe_wait_for_text() {
    local text="$1"
    local timeout_ms="$2"
    local deadline=$(( $(date +%s) + (timeout_ms + 999) / 1000 ))
    local ui=""

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        ui=$(axe describe-ui --udid "$SIM_UDID" 2>/dev/null || true)
        if printf '%s' "$ui" | grep -Fq "$text"; then
            return 0
        fi
        sleep 1
    done

    echo -e "  ${YELLOW}Last AXe UI snapshot did not contain: ${text}${NC}"
    if [[ -n "$ui" ]]; then
        printf '%s\n' "$ui" | sed -n '1,220p'
    fi
    return 1
}

stop_jaala() {
    if [[ -z "${JAAALA_PID:-}" ]]; then
        return 0
    fi

    if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        JAAALA_PID=""
        return 0
    fi

    kill -TERM "$JAAALA_PID" >/dev/null 2>&1 || true
    for _ in {1..30}; do
        if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done

    if kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        kill -KILL "$JAAALA_PID" >/dev/null 2>&1 || true
    fi

    wait "$JAAALA_PID" >/dev/null 2>&1 || true
    JAAALA_PID=""

    if [[ -f "$HOME/.jaala/session.lock" ]]; then
        python3 -m jaala --cleanup >/dev/null 2>&1 || true
    fi
}

start_stream_server() {
    python3 - "$STREAM_PORT_FILE" "$ORIGINAL_TEXT" "$STREAM_DEMO_DURATION_SECONDS" >"$STREAM_LOG" 2>&1 <<'PY' &
import socket
import sys
import time

port_file = sys.argv[1]
original = sys.argv[2]
duration_seconds = int(sys.argv[3])
first = f"data: {original[:8]}".encode("utf-8")
second = f"{original[8:]}\n\n".encode("utf-8")
third = b"data: stream-done\n\n"


def write_port(port):
    with open(port_file, "w", encoding="utf-8") as handle:
        handle.write(str(port))
        handle.flush()


def read_request(conn):
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = conn.recv(4096)
        if not chunk:
            return b""
        data += chunk
    return data


def send_chunk(conn, payload):
    conn.sendall(f"{len(payload):X}\r\n".encode("ascii") + payload + b"\r\n")


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(("0.0.0.0", 0))
server.listen(4)
write_port(server.getsockname()[1])
print(f"Streaming server listening on {server.getsockname()[1]}", flush=True)

while True:
    conn, _ = server.accept()
    try:
        conn.settimeout(max(60, duration_seconds + 10))
        request = read_request(conn)
        if request:
            first_line = request.split(b"\r\n", 1)[0].decode("latin1", errors="replace")
            print(f"Streaming request: {first_line}", flush=True)
        conn.sendall(
            b"HTTP/1.1 200 OK\r\n"
            b"Content-Type: text/event-stream; charset=utf-8\r\n"
            b"Cache-Control: no-cache\r\n"
            b"Transfer-Encoding: chunked\r\n"
            b"\r\n"
        )
        if duration_seconds > 0:
            for index in range(duration_seconds):
                payload = f"data: {original} tick {index + 1}\n\n".encode("utf-8")
                send_chunk(conn, payload)
                time.sleep(1)
            send_chunk(conn, third)
        else:
            for payload in (first, second, third):
                send_chunk(conn, payload)
                time.sleep(0.2)
        conn.sendall(b"0\r\n\r\n")
    except Exception as exc:
        print(f"Streaming server error: {exc}", flush=True)
    finally:
        try:
            conn.close()
        except Exception:
            pass
PY
    STREAM_SERVER_PID=$!

    if ! wait_for_file "$STREAM_PORT_FILE" 10; then
        echo -e "${RED}Streaming server did not write its port file.${NC}"
        sed -n '1,120p' "$STREAM_LOG"
        exit 1
    fi

    STREAM_PORT="$(cat "$STREAM_PORT_FILE")"
    if [[ -z "$STREAM_PORT" ]]; then
        echo -e "${RED}Streaming server did not provide a port.${NC}"
        exit 1
    fi

    if ! wait_for_port "127.0.0.1" "$STREAM_PORT" 10; then
        echo -e "${RED}Streaming server did not start listening on port ${STREAM_PORT}.${NC}"
        sed -n '1,120p' "$STREAM_LOG"
        exit 1
    fi
}

start_jaala() {
    capture_proxy_state
    python3 -m jaala \
        --quiet \
        --port "$JAAALA_PORT" \
        --json-file "$JSONL_FILE" \
        --save-har "$HAR_FILE" \
        --filter "${HOST_IP}:${STREAM_PORT}/stream" \
        --body-replace "${HOST_IP}:${STREAM_PORT}/stream=${ORIGINAL_TEXT}>>>${REPLACED_TEXT}" \
        >"$JAAALA_LOG" 2>&1 &
    JAAALA_PID=$!

    if ! wait_for_port "127.0.0.1" "$JAAALA_PORT" 30; then
        echo -e "${RED}Jaala did not start listening on port ${JAAALA_PORT}.${NC}"
        sed -n '1,220p' "$JAAALA_LOG"
        check "Jaala starts" "false"
        exit 1
    fi

    if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        echo -e "${RED}Jaala exited before validation could start.${NC}"
        sed -n '1,220p' "$JAAALA_LOG"
        check "Jaala starts" "false"
        exit 1
    fi

    check "Jaala starts" "true"
}

assert_stream_jsonl() {
    if python3 - "$JSONL_FILE" "http://${HOST_IP}:${STREAM_PORT}/stream" "$ORIGINAL_TEXT" "$REPLACED_TEXT" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
url = sys.argv[2]
original = sys.argv[3]
replaced = sys.argv[4]

records = [
    json.loads(line)
    for line in jsonl_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]
stream_records = [
    record
    for record in records
    if record.get("type") == "http_stream_chunk" and record.get("url") == url
]
http_records = [
    record
    for record in records
    if record.get("type") == "http" and record.get("url") == url
]

if len(stream_records) < 2:
    raise SystemExit(f"Expected at least 2 stream chunk records, found {len(stream_records)}")
if http_records:
    raise SystemExit(f"Expected no buffered http records for stream, found {len(http_records)}")
if not any(record.get("chunk", {}).get("modified") for record in stream_records):
    raise SystemExit("Expected at least one modified stream chunk record")

combined = "".join(record.get("chunk", {}).get("text", "") for record in stream_records)
if replaced not in combined:
    raise SystemExit(f"Modified stream text {replaced!r} was not captured: {combined!r}")
if original in combined:
    raise SystemExit(f"Original stream text {original!r} leaked through capture: {combined!r}")
PY
    then
        check "JSONL captures modified http_stream_chunk records" "true"
    else
        check "JSONL captures modified http_stream_chunk records" "false"
    fi
}

wait_for_stream_jsonl() {
    local timeout_seconds="$1"
    local deadline=$(( $(date +%s) + timeout_seconds ))

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if [[ -s "$JSONL_FILE" ]] && python3 - "$JSONL_FILE" "http://${HOST_IP}:${STREAM_PORT}/stream" "$REPLACED_TEXT" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
url = sys.argv[2]
replaced = sys.argv[3]

records = [
    json.loads(line)
    for line in jsonl_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]
combined = "".join(
    record.get("chunk", {}).get("text", "")
    for record in records
    if record.get("type") == "http_stream_chunk" and record.get("url") == url
)
if replaced not in combined:
    raise SystemExit(1)
PY
        then
            return 0
        fi
        sleep 1
    done

    return 1
}

wait_for_stream_chunk_count() {
    local timeout_seconds="$1"
    local min_chunks="$2"
    local deadline=$(( $(date +%s) + timeout_seconds ))

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if [[ -s "$JSONL_FILE" ]] && python3 - "$JSONL_FILE" "http://${HOST_IP}:${STREAM_PORT}/stream" "$min_chunks" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
url = sys.argv[2]
min_chunks = int(sys.argv[3])

records = [
    json.loads(line)
    for line in jsonl_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]
stream_records = [
    record
    for record in records
    if record.get("type") == "http_stream_chunk" and record.get("url") == url
]
if len(stream_records) < min_chunks:
    raise SystemExit(1)
PY
        then
            return 0
        fi
        sleep 1
    done

    return 1
}

scroll_to_latest_stream_messages() {
    for _ in {1..4}; do
        axe swipe \
            --udid "$SIM_UDID" \
            --start-x 200 \
            --start-y 720 \
            --end-x 200 \
            --end-y 220 \
            --duration 0.25 \
            --post-delay 0.2 >/dev/null 2>&1 || return 1
    done

    axe screenshot --udid "$SIM_UDID" --output "$LATEST_SCREENSHOT" >/dev/null 2>&1 || return 1
    [[ -s "$LATEST_SCREENSHOT" ]]
}

echo "========================================"
echo "  Jaala HTTP streaming AXe validation"
echo "========================================"
echo ""

echo "Step 0: Checking prerequisites..."
require_cmd python3
require_cmd xcodebuild
require_cmd xcrun
require_cmd axe
require_cmd mitmdump

SIM_JSON=$(xcrun simctl list devices booted -j 2>/dev/null)
SIM_UDID=$(simulator_value udid)
SIM_NAME=$(simulator_value name)

if [[ -z "$SIM_UDID" ]]; then
    echo -e "${RED}No booted simulator found. Boot a simulator and retry.${NC}"
    exit 1
fi

NETWORK_SERVICE="$(detect_active_service)"
if [[ -z "$NETWORK_SERVICE" ]]; then
    echo -e "${RED}No active network service found.${NC}"
    exit 1
fi
HOST_IP="$(detect_active_service_ip)"
if [[ -z "$HOST_IP" ]]; then
    echo -e "${RED}No host IP address found for ${NETWORK_SERVICE}.${NC}"
    exit 1
fi

echo -e "  Booted simulator: ${YELLOW}${SIM_NAME} (${SIM_UDID})${NC}"
echo -e "  Active network service: ${YELLOW}${NETWORK_SERVICE}${NC}"
echo -e "  Host IP address: ${YELLOW}${HOST_IP}${NC}"
echo ""

echo "Step 1: Building and installing the sample app..."
if xcodebuild \
    -project "$APP_PROJECT" \
    -scheme "$APP_SCHEME" \
    -configuration Debug \
    -sdk iphonesimulator \
    -derivedDataPath "$APP_DERIVED_DATA" \
    build >/tmp/jaala_streaming_xcodebuild_$$.log 2>&1; then
    check "Sample app builds for iOS Simulator" "true"
else
    check "Sample app builds for iOS Simulator" "false"
    echo ""
    echo "xcodebuild log:"
    sed -n '1,220p' "/tmp/jaala_streaming_xcodebuild_$$.log"
    exit 1
fi

if xcrun simctl install "$SIM_UDID" "$APP_BINARY" >/dev/null; then
    check "Sample app installs on the booted Simulator" "true"
else
    check "Sample app installs on the booted Simulator" "false"
    exit 1
fi
echo ""

start_stream_server
JAAALA_PORT="$(python3 - <<'PY'
import socket

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    sock.bind(("127.0.0.1", 0))
    print(sock.getsockname()[1])
PY
)"

echo "Step 2: Running HTTP streaming capture and mutation case..."
echo -e "  Stream endpoint: ${YELLOW}http://${HOST_IP}:${STREAM_PORT}/stream${NC}"
start_jaala

xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
if xcrun simctl launch \
    "$SIM_UDID" \
    "$APP_BUNDLE_ID" \
    --stream-url "http://${HOST_IP}:${STREAM_PORT}/stream" \
    --stream-proxy-host "$HOST_IP" \
    --stream-proxy-port "$JAAALA_PORT" \
    --autorun-stream >/dev/null; then
    check "Sample app launches" "true"
else
    check "Sample app launches" "false"
    exit 1
fi

if axe_wait_for_text "$STREAM_LABEL" 30000; then
    check "AXe can observe the HTTP stream control" "true"
else
    check "AXe can observe the HTTP stream control" "false"
    exit 1
fi
check "Sample app starts the HTTP stream scenario" "true"

if wait_for_stream_jsonl 45; then
    check "Simulator stream request produces modified chunk capture" "true"
else
    check "Simulator stream request produces modified chunk capture" "false"
fi

if [[ "$STREAM_DEMO_DURATION_SECONDS" -gt 0 ]]; then
    if wait_for_stream_chunk_count "$((STREAM_DEMO_DURATION_SECONDS + 15))" "$STREAM_DEMO_DURATION_SECONDS"; then
        check "Simulator keeps receiving stream chunks for ${STREAM_DEMO_DURATION_SECONDS}s" "true"
    else
        check "Simulator keeps receiving stream chunks for ${STREAM_DEMO_DURATION_SECONDS}s" "false"
    fi
    if [[ "$STREAM_SCROLL_LATEST" == "1" ]]; then
        if scroll_to_latest_stream_messages; then
            check "Simulator scrolls down to latest stream messages" "true"
        else
            check "Simulator scrolls down to latest stream messages" "false"
        fi
    fi
fi

stop_jaala
assert_proxy_restored
assert_stream_jsonl

echo ""
echo "Step 3: Final cleanup checks..."
if [[ -n "${STREAM_SERVER_PID:-}" ]] && kill -0 "$STREAM_SERVER_PID" >/dev/null 2>&1; then
    kill -TERM "$STREAM_SERVER_PID" >/dev/null 2>&1 || true
    for _ in {1..20}; do
        if ! kill -0 "$STREAM_SERVER_PID" >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done
    if kill -0 "$STREAM_SERVER_PID" >/dev/null 2>&1; then
        kill -KILL "$STREAM_SERVER_PID" >/dev/null 2>&1 || true
    fi
    wait "$STREAM_SERVER_PID" >/dev/null 2>&1 || true
fi

if pgrep -f "python3 -m jaala --quiet --port ${JAAALA_PORT}" >/dev/null 2>&1; then
    check "No jaala process remains" "false"
else
    check "No jaala process remains" "true"
fi

if pgrep -f "mitmdump --listen-port ${JAAALA_PORT}" >/dev/null 2>&1; then
    check "No mitmdump process remains" "false"
else
    check "No mitmdump process remains" "true"
fi

if [[ -n "${STREAM_SERVER_PID:-}" ]] && kill -0 "$STREAM_SERVER_PID" >/dev/null 2>&1; then
    check "No streaming server process remains" "false"
else
    check "No streaming server process remains" "true"
fi

echo ""
echo "========================================"
echo -e "  Results: ${GREEN}$PASS passed${NC}, ${RED}$FAIL failed${NC}"
echo "========================================"

if [[ "$FAIL" -gt 0 ]]; then
    exit 1
fi

echo -e "${GREEN}All validations passed.${NC}"
