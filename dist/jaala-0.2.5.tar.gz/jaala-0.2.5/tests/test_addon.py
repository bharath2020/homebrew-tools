from __future__ import annotations

import json
import os
from types import SimpleNamespace
from unittest.mock import patch

from jaala.addon import JaalaAddon, _decode_body, _format_body, _format_headers, _parse_body


class CaseInsensitiveDict(dict):
    def get(self, key, default=None):
        for existing_key, value in self.items():
            if existing_key.lower() == key.lower():
                return value
        return default


def make_flow(
    method="GET",
    url="https://api.example.com/data",
    status=200,
    req_headers=None,
    resp_headers=None,
    req_body=b"",
    resp_body=b'{"ok":true}',
    ts_start=1000.0,
    ts_end=1000.150,
):
    request = SimpleNamespace(
        method=method,
        pretty_url=url,
        headers=CaseInsensitiveDict(
            req_headers
            or {
                "Host": "api.example.com",
                "Content-Type": "application/json",
                "User-Agent": "JaalaSample/1.0",
            }
        ),
        content=req_body,
        timestamp_start=ts_start,
        http_version="HTTP/2.0",
    )
    response = SimpleNamespace(
        status_code=status,
        headers=CaseInsensitiveDict(resp_headers or {"Content-Type": "application/json"}),
        content=resp_body,
        timestamp_end=ts_end,
        http_version="HTTP/2.0",
    )
    return SimpleNamespace(request=request, response=response, metadata={})


def write_config(tmp_path, data):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps(data), encoding="utf-8")
    return config_path


def test_decode_body_and_parsers():
    assert _decode_body(None) is None
    assert _decode_body(b"hello") == "hello"
    assert _parse_body(json.dumps({"a": 1}).encode(), "application/json") == {"a": 1}
    assert _format_headers({"Host": "example.com"}) == ["Host: example.com"]
    assert _format_body(b"hello", "text/plain") == ["hello"]


def test_default_init_uses_jaala_env_defaults():
    with patch.dict(os.environ, {}, clear=False):
        addon = JaalaAddon()

    assert addon.json_mode is False
    assert addon.json_file == ""
    assert addon.har_file == ""
    assert addon.filter_pattern == ""
    assert addon.filter_user_agent == ""
    assert addon.websockets is True
    assert addon.no_websockets is False
    assert addon.map_local == ""
    assert addon.map_remote == ""
    assert addon.status_code == ""
    assert addon.add_header == ""
    assert addon.response_text_replace == ""
    assert addon.request_header == ""
    assert addon.request_body_replace == ""
    assert addon.websocket_message_replace == ""
    assert addon.websocket_drop_message == ""
    assert addon.websocket_fail_rate == ""
    assert addon.websocket_delay == ""
    assert addon.websocket_throttle == ""
    assert addon.delay == []
    assert addon.throttle == []
    assert addon.drop_connection == []
    assert addon.fail_rate == []
    assert addon.runtime_status_file == ""
    assert addon.show_headers is True
    assert addon.show_body is True


def test_no_headers_and_no_body_flags_disable_record_fields(tmp_path):
    env = {
        "JAALA_NO_HEADERS": "1",
        "JAALA_NO_BODY": "1",
        "JAALA_JSON_FILE": str(tmp_path / "traffic.jsonl"),
    }
    with patch.dict(os.environ, env, clear=False):
        addon = JaalaAddon()

    flow = make_flow()
    record = addon._build_json_record(flow)

    assert record["type"] == "http"
    assert record["request"] == {}
    assert record["response"] == {}


def test_json_mode_emits_json_line(capsys):
    with patch.dict(os.environ, {"JAALA_JSON": "1"}, clear=False):
        addon = JaalaAddon()
    addon.response(make_flow())

    record = json.loads(capsys.readouterr().out.strip())
    assert record["type"] == "http"
    assert record["method"] == "GET"
    assert record["status"] == 200


def test_addon_reloads_config_file_without_restart(tmp_path):
    fixture = tmp_path / "search.json"
    fixture.write_text('{"demo":true}', encoding="utf-8")
    config_path = write_config(tmp_path, {})

    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(url="https://en.wikipedia.org/w/api.php?action=query&generator=prefixsearch", resp_body=b"")
    flow.response = None
    addon.request(flow)
    assert flow.response is None

    config_path.write_text(json.dumps({"map_local": f"prefixsearch={fixture}"}), encoding="utf-8")
    flow = make_flow(url="https://en.wikipedia.org/w/api.php?action=query&generator=prefixsearch", resp_body=b"")
    flow.response = None
    addon.request(flow)

    assert flow.response is not None
    assert flow.response.content == b'{"demo":true}'


def test_addon_reloads_config_when_content_changes_but_stat_signature_is_preserved(tmp_path):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=hello>>>world AAA"})
    status_path = tmp_path / "runtime-status.json"

    with patch.dict(
        os.environ,
        {"JAALA_CONFIG": str(config_path), "JAALA_RUNTIME_STATUS_FILE": str(status_path)},
        clear=False,
    ):
        addon = JaalaAddon()

    first = make_flow(resp_body=b"hello from Jaala")
    addon.response(first)
    assert first.response.content == b"world AAA from Jaala"

    stat = config_path.stat()
    old_text = config_path.read_text(encoding="utf-8")
    new_text = old_text.replace("world AAA", "world BBB")
    assert new_text != old_text
    assert len(new_text) == len(old_text)
    config_path.write_text(new_text, encoding="utf-8")
    os.utime(config_path, ns=(stat.st_atime_ns, stat.st_mtime_ns))

    second = make_flow(resp_body=b"hello from Jaala")
    addon.response(second)

    status = json.loads(status_path.read_text(encoding="utf-8"))
    assert second.response.content == b"world BBB from Jaala"
    assert status["outcome"] == "reloaded"
    assert status["reason"] == "signature_changed"
    assert status["active_response_text_replace"] == "api.example.com=hello>>>world BBB"


def test_addon_writes_runtime_reload_status_file(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"response_text_replace": "api.example.com=hello>>>world"}), encoding="utf-8")
    status_path = tmp_path / "runtime-status.json"

    with patch.dict(
        os.environ,
        {"JAALA_CONFIG": str(config_path), "JAALA_RUNTIME_STATUS_FILE": str(status_path)},
        clear=False,
    ):
        addon = JaalaAddon()

    status = json.loads(status_path.read_text(encoding="utf-8"))
    assert addon.runtime_status_file == str(status_path)
    assert status["outcome"] == "reloaded"
    assert status["reason"] == "initial_load"
    assert status["active_response_text_replace"] == "api.example.com=hello>>>world"
    assert status["last_successful_outcome"] == "reloaded"
    assert status["last_successful_reason"] == "initial_load"
    assert status["last_successful_active_response_text_replace"] == "api.example.com=hello>>>world"


def test_addon_preserves_last_successful_reload_status_on_unchanged_flow(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"response_text_replace": "api.example.com=hello>>>world"}), encoding="utf-8")
    status_path = tmp_path / "runtime-status.json"

    with patch.dict(
        os.environ,
        {"JAALA_CONFIG": str(config_path), "JAALA_RUNTIME_STATUS_FILE": str(status_path)},
        clear=False,
    ):
        addon = JaalaAddon()

    initial_status = json.loads(status_path.read_text(encoding="utf-8"))
    assert initial_status["outcome"] == "reloaded"
    assert initial_status["reason"] == "initial_load"
    assert initial_status["active_response_text_replace"] == "api.example.com=hello>>>world"
    assert initial_status["last_successful_outcome"] == "reloaded"
    assert initial_status["last_successful_reason"] == "initial_load"
    assert initial_status["last_successful_active_response_text_replace"] == "api.example.com=hello>>>world"

    addon.response(make_flow())

    status = json.loads(status_path.read_text(encoding="utf-8"))
    assert status["outcome"] == "skipped"
    assert status["reason"] == "unchanged"
    assert status["active_response_text_replace"] == "api.example.com=hello>>>world"
    assert status["last_successful_outcome"] == "reloaded"
    assert status["last_successful_reason"] == "initial_load"
    assert status["last_successful_active_response_text_replace"] == "api.example.com=hello>>>world"


def test_verbose_mode_logs_reload_and_rule_events(tmp_path, capsys):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=hello>>>world"})
    with patch.dict(
        os.environ,
        {"JAALA_VERBOSE": "1", "JAALA_CONFIG": str(config_path)},
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_flow(resp_body=b"hello from Jaala")
    addon.response(flow)

    stderr = capsys.readouterr().err
    assert "[jaala verbose] runtime reload initial_load:" in stderr
    assert "[jaala verbose] response-rule response_text_replace_applied" in stderr


def test_verbose_mode_suppresses_unchanged_reload_skips(tmp_path, capsys):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=hello>>>world"})
    with patch.dict(
        os.environ,
        {"JAALA_VERBOSE": "1", "JAALA_CONFIG": str(config_path)},
        clear=False,
    ):
        addon = JaalaAddon()

    capsys.readouterr()
    addon.response(make_flow(resp_body=b"hello from Jaala"))

    stderr = capsys.readouterr().err
    assert "runtime reload skipped: unchanged signature" not in stderr
    assert "[jaala verbose] response-rule response_text_replace_applied" in stderr


def test_human_output_contains_key_fields(capsys):
    with patch.dict(os.environ, {}, clear=False):
        addon = JaalaAddon()
    addon.response(make_flow())

    output = capsys.readouterr().out
    assert "GET https://api.example.com/data" in output
    assert "status=200" in output
    assert "Request Headers:" in output
    assert "Response Body:" in output


def test_filter_pattern_skips_non_matching_flow(tmp_path, capsys):
    config_path = write_config(tmp_path, {"filter": "payments"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    addon.response(make_flow(url="https://api.example.com/data"))

    assert capsys.readouterr().out == ""
    assert addon.har_entries == []


def test_filter_user_agent_skips_non_matching_flow(tmp_path, capsys):
    config_path = write_config(tmp_path, {"filter_user_agent": "re:JaalaSample/2\\."})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    addon.response(make_flow(req_headers={"Host": "api.example.com", "User-Agent": "JaalaSample/1.0"}))

    assert capsys.readouterr().out == ""
    assert addon.har_entries == []


def test_filter_and_user_agent_match_allow_capture(tmp_path, capsys):
    config_path = write_config(
        tmp_path,
        {"filter": "api.example.com", "filter_user_agent": "JaalaSample"},
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    addon.response(make_flow())

    output = capsys.readouterr().out
    assert "GET https://api.example.com/data" in output
