"""Tests for --quiet / -q flag."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from jaala.cli import parse_args


class TestQuietCLI:
    def test_default_not_quiet(self):
        assert parse_args([]).quiet is False

    def test_quiet_long_flag(self):
        assert parse_args(["--quiet"]).quiet is True

    def test_quiet_short_flag(self):
        assert parse_args(["-q"]).quiet is True


class TestQuietProxyEnvPassthrough:
    @patch("jaala.proxy._wait_for_port", return_value=True)
    @patch("jaala.proxy.subprocess.Popen")
    @patch("jaala.proxy._find_upstream_trusted_ca", return_value=None)
    def test_quiet_env_var_set(self, mock_ca, mock_popen, mock_wait):
        from jaala.proxy import start_mitmdump

        mock_popen.return_value = MagicMock()
        start_mitmdump(port=8080, quiet=True)
        assert mock_popen.call_args[1]["env"]["JAALA_QUIET"] == "1"


class TestQuietMainSuppressesOutput:
    @patch("jaala.__main__.start_mitmdump")
    @patch("jaala.__main__.find_free_port", return_value=9999)
    @patch("jaala.__main__.ProxyConfig")
    @patch("jaala.__main__.install_cert_in_simulator")
    @patch("jaala.__main__.trust_ca_cert_in_macos")
    @patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
    @patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
    @patch("jaala.__main__.check_stale_session")
    @patch("jaala.__main__.preflight_checks")
    @patch("jaala.__main__.write_lock")
    @patch("jaala.__main__.remove_lock")
    @patch("jaala.__main__.signal.signal")
    @patch("jaala.__main__.atexit.register")
    def test_quiet_suppresses_startup_messages(
        self,
        mock_atexit,
        mock_signal,
        mock_rl,
        mock_wl,
        mock_pf,
        mock_cs,
        mock_rs,
        mock_ec,
        mock_tm,
        mock_ic,
        mock_pc,
        mock_ffp,
        mock_sm,
        capsys,
    ):
        proc = MagicMock()
        proc.wait.return_value = None
        proc.poll.return_value = 0
        mock_sm.return_value = proc

        from jaala.__main__ import main

        main(["--quiet"])

        output = capsys.readouterr().out
        assert "Using simulator:" not in output
        assert "Starting proxy" not in output
        assert "Installing CA certificate" not in output
        assert "Press Ctrl+C" not in output

