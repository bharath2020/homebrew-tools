"""Runtime control helpers for socket and stream event injection."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .filtering import build_matcher
from .runtime_rules import runtime_stream_events, runtime_websocket_events
from .websocket_replay import inject_text_messages


@dataclass(frozen=True, slots=True)
class RuntimeTextEvent:
    id: str
    match_url: str
    text: str
    drop_live_server_messages: bool = False


@dataclass(frozen=True, slots=True)
class RuntimeStreamEvent:
    id: str
    match_url: str
    chunk: bytes


def build_runtime_websocket_events(config: dict[str, Any]) -> list[RuntimeTextEvent]:
    events: list[RuntimeTextEvent] = []
    for raw in runtime_websocket_events(config):
        if not raw.get("enabled", True):
            continue
        event_id = raw.get("id")
        match_url = raw.get("match_url")
        text = raw.get("text")
        if not isinstance(event_id, str) or not event_id.strip():
            raise ValueError("Runtime WebSocket event id must be a non-empty string")
        if not isinstance(match_url, str) or not match_url.strip():
            raise ValueError(f"Runtime WebSocket event {event_id!r} match_url must be a non-empty string")
        if not isinstance(text, str):
            raise ValueError(f"Runtime WebSocket event {event_id!r} text must be a string")
        build_matcher(match_url)
        events.append(
            RuntimeTextEvent(
                id=event_id,
                match_url=match_url,
                text=text,
                drop_live_server_messages=bool(raw.get("drop_live_server_messages", False)),
            )
        )
    return events


def build_runtime_stream_events(config: dict[str, Any]) -> list[RuntimeStreamEvent]:
    events: list[RuntimeStreamEvent] = []
    for raw in runtime_stream_events(config):
        if not raw.get("enabled", True):
            continue
        event_id = raw.get("id")
        match_url = raw.get("match_url")
        chunk = raw.get("chunk")
        if not isinstance(event_id, str) or not event_id.strip():
            raise ValueError("Runtime stream event id must be a non-empty string")
        if not isinstance(match_url, str) or not match_url.strip():
            raise ValueError(f"Runtime stream event {event_id!r} match_url must be a non-empty string")
        if not isinstance(chunk, str):
            raise ValueError(f"Runtime stream event {event_id!r} chunk must be a string")
        build_matcher(match_url)
        events.append(RuntimeStreamEvent(id=event_id, match_url=match_url, chunk=chunk.encode("utf-8")))
    return events


def matching_websocket_events(
    flow,
    events: list[RuntimeTextEvent],
    sent_ids: set[str],
) -> list[RuntimeTextEvent]:
    url = getattr(getattr(flow, "request", None), "pretty_url", "")
    matches: list[RuntimeTextEvent] = []
    for event in events:
        if event.id in sent_ids:
            continue
        if build_matcher(event.match_url)(url):
            matches.append(event)
    return matches


def matching_stream_events(
    flow,
    events: list[RuntimeStreamEvent],
    sent_ids: set[str],
) -> list[RuntimeStreamEvent]:
    url = getattr(getattr(flow, "request", None), "pretty_url", "")
    matches: list[RuntimeStreamEvent] = []
    for event in events:
        if event.id in sent_ids:
            continue
        if build_matcher(event.match_url)(url):
            matches.append(event)
    return matches


def inject_runtime_websocket_events(flow, events: list[RuntimeTextEvent]) -> int:
    return inject_text_messages(flow, [event.text for event in events])
