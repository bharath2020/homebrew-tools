from __future__ import annotations

import gzip
import json
import os
from unittest.mock import patch

from jaala.addon import JaalaAddon

from .test_addon import make_flow


def test_refresh_time_body_mutation_strips_stale_representation_headers_but_keeps_cache_policy(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"response_text_replace": "wikipedia.org=OpenAI>>>JAALA DEMO"}),
        encoding="utf-8",
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/api/rest_v1/page/mobile-html/OpenAI",
        resp_headers={
            "Content-Type": "text/html; charset=utf-8",
            "Content-Encoding": "br",
            "Content-Length": "999",
            "ETag": "W/\"old-etag\"",
            "Digest": "sha-256=old-digest",
            "Content-Range": "bytes 0-998/999",
            "Cache-Control": "private, max-age=0, must-revalidate",
            "Last-Modified": "Mon, 13 Apr 2026 22:42:09 GMT",
        },
        resp_body=b"<html><body><p>OpenAI article body</p></body></html>",
    )

    addon.response(flow)

    assert b"JAALA DEMO article body" in flow.response.content
    assert flow.response.headers.get("content-length") == str(len(flow.response.content))
    assert flow.response.headers.get("content-type") == "text/html; charset=utf-8"
    assert flow.response.headers.get("cache-control") == "private, max-age=0, must-revalidate"
    assert flow.response.headers.get("content-encoding") is None
    assert flow.response.headers.get("etag") is None
    assert flow.response.headers.get("digest") is None
    assert flow.response.headers.get("content-range") is None


def test_refresh_time_body_mutation_preserves_supported_gzip_encoding(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"response_text_replace": "wikipedia.org=OpenAI>>>JAALA DEMO"}),
        encoding="utf-8",
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    original = gzip.compress(b"OpenAI article body")
    flow = make_flow(
        url="https://en.wikipedia.org/api/rest_v1/page/mobile-html/OpenAI",
        resp_headers={
            "Content-Type": "text/html; charset=utf-8",
            "Content-Encoding": "gzip",
            "Content-Length": str(len(original)),
            "ETag": 'W/"old-etag"',
            "Cache-Control": "private, max-age=0, must-revalidate",
        },
        resp_body=original,
    )

    addon.response(flow)

    assert gzip.decompress(flow.response.content) == b"JAALA DEMO article body"
    assert flow.response.headers.get("content-encoding") == "gzip"
    assert flow.response.headers.get("content-length") == str(len(flow.response.content))
    assert flow.response.headers.get("etag") is None


def test_refresh_time_body_mutation_no_match_keeps_original_headers(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"response_text_replace": "wikipedia.org=Missing>>>JAALA DEMO"}),
        encoding="utf-8",
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/api/rest_v1/page/mobile-html/OpenAI",
        resp_headers={
            "Content-Type": "text/html; charset=utf-8",
            "Content-Encoding": "gzip",
            "ETag": "W/\"keep-me\"",
            "Content-Length": "17",
        },
        resp_body=b"OpenAI article body",
    )

    addon.response(flow)

    assert flow.response.content == b"OpenAI article body"
    assert flow.response.headers.get("content-encoding") == "gzip"
    assert flow.response.headers.get("etag") == 'W/"keep-me"'
    assert flow.response.headers.get("content-length") == "17"


def test_refresh_time_body_mutation_skips_binary_body_without_touching_headers(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"response_text_replace": "wikipedia.org=OpenAI>>>JAALA DEMO"}),
        encoding="utf-8",
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/api/rest_v1/page/mobile-html/OpenAI",
        resp_headers={
            "Content-Type": "application/octet-stream",
            "Content-Encoding": "gzip",
            "ETag": "W/\"binary\"",
            "Content-Length": "4",
        },
        resp_body=b"\xff\xfe\x00\x01",
    )

    addon.response(flow)

    assert flow.response.content == b"\xff\xfe\x00\x01"
    assert flow.response.headers.get("content-encoding") == "gzip"
    assert flow.response.headers.get("etag") == 'W/"binary"'
    assert flow.response.headers.get("content-length") == "4"
