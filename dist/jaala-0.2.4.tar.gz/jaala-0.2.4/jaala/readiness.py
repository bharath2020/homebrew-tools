"""Readiness collection and presentation helpers."""

from __future__ import annotations

import json
from typing import Any

from .certs import CA_CERT_PEM, get_ca_cert_status
from .network import collect_proxy_status
from .session import collect_session_status
from .simulator import probe_simulator_cert_status, resolve_simulator


def collect_readiness_status(network_service: str | None = None) -> dict[str, object]:
    """Collect readiness details for proxy startup without mutating system state."""
    session_status = collect_session_status()
    expected_port = session_status["port"] if session_status["lock_present"] else None
    proxy_status = collect_proxy_status(
        service=network_service,
        expected_port=expected_port if isinstance(expected_port, int) else None,
    )
    cert_status = get_ca_cert_status(CA_CERT_PEM)

    blockers: list[str] = []
    if proxy_status["error"]:
        blockers.append(str(proxy_status["error"]))
    if session_status["process_running"]:
        blockers.append(f"Jaala session PID {session_status['pid']} is still running.")
    elif session_status["stale"]:
        blockers.append("Stale Jaala session lock exists. Run jaala --cleanup.")
    if not cert_status["exists"]:
        blockers.append(f"CA certificate missing at {CA_CERT_PEM}.")
    elif not cert_status["trusted_in_macos"]:
        blockers.append("CA certificate is not trusted in the macOS System keychain.")

    return {
        "ready": not blockers,
        "blockers": blockers,
        "proxy": proxy_status,
        "session": session_status,
        "cert": {
            **cert_status,
            "macos_system_trusted": cert_status["trusted_in_macos"],
            "simulator_install_check_supported": False,
            "simulator_install_status": "unknown",
            "simulator_install_probe_available": True,
            "simulator_install_note": (
                "simctl exposes add/reset actions but no passive query API for installed simulator root certs; "
                "use jaala --probe-cert-readiness to run an idempotent probe against a simulator."
            ),
        },
    }


def collect_cert_probe_status(simulator_udid: str | None = None) -> dict[str, object]:
    """Collect explicit certificate readiness, including a simulator probe."""
    cert_status = get_ca_cert_status(CA_CERT_PEM)
    device = resolve_simulator(simulator_udid)
    simulator_status = probe_simulator_cert_status(device["udid"], str(CA_CERT_PEM))

    blockers: list[str] = []
    if not cert_status["exists"]:
        blockers.append(f"CA certificate missing at {CA_CERT_PEM}.")
    elif not cert_status["trusted_in_macos"]:
        blockers.append("CA certificate is not trusted in the macOS System keychain.")

    if not simulator_status["booted"]:
        blockers.append(f"Simulator {simulator_status['udid']} is not booted.")
    if not simulator_status["cert_exists"]:
        blockers.append(f"CA certificate missing at {simulator_status['cert_path']}.")
    elif not simulator_status["installed"]:
        blockers.append(
            "Simulator certificate probe failed."
            if simulator_status["probe_stderr"] == ""
            else f"Simulator certificate probe failed: {simulator_status['probe_stderr']}"
        )

    return {
        "ready": cert_status["trusted_in_macos"] and simulator_status["ready"],
        "blockers": blockers,
        "cert": {
            **cert_status,
            "macos_system_trusted": cert_status["trusted_in_macos"],
        },
        "simulator": simulator_status,
    }


def _format_proxy_line(label: str, state: dict[str, object] | None) -> str:
    if state is None:
        return f"{label}: unavailable"
    status = "enabled" if state["enabled"] else "disabled"
    server = state["server"] or "-"
    port = state["port"] if state["port"] is not None else "-"
    suffix = " (Jaala)" if state["points_to_jaala"] else ""
    return f"{label}: {status} {server}:{port}{suffix}"


def print_readiness_status(status: dict[str, object], *, as_json: bool = False) -> None:
    """Print readiness details in text or JSON form."""
    if as_json:
        print(json.dumps(status, indent=2, sort_keys=True))
        return

    readiness = "ready" if status["ready"] else "not ready"
    proxy = status["proxy"]
    session = status["session"]
    cert = status["cert"]

    print(f"Ready to proxy: {readiness}")
    service = proxy["service"] or "-"
    print(f"Network service: {service}")
    if proxy["error"]:
        print(f"Proxy inspection error: {proxy['error']}")
    else:
        print(_format_proxy_line("HTTP proxy", proxy["http"]))
        print(_format_proxy_line("HTTPS proxy", proxy["https"]))

    if session["lock_present"]:
        session_state = "running" if session["process_running"] else "stale"
        print(
            f"Session lock: {session_state} "
            f"(pid={session['pid']}, service={session['network_service']}, port={session['port']})"
        )
    else:
        print("Session lock: clear")

    macos_trust = "trusted" if cert["macos_system_trusted"] else "not trusted"
    cert_state = "present" if cert["exists"] else "missing"
    print(f"CA certificate: {cert_state} ({cert['path']})")
    print(f"macOS System trust: {macos_trust}")
    print("Simulator cert status: unknown (no simctl query API)")

    for blocker in status["blockers"]:
        print(f"Blocker: {blocker}")


def print_cert_probe_status(status: dict[str, object], *, as_json: bool = False) -> None:
    """Print explicit simulator certificate probe results."""
    if as_json:
        print(json.dumps(status, indent=2, sort_keys=True))
        return

    readiness = "ready" if status["ready"] else "not ready"
    cert = status["cert"]
    simulator = status["simulator"]

    print(f"Simulator certificate readiness: {readiness}")
    cert_state = "present" if cert["exists"] else "missing"
    macos_trust = "trusted" if cert["macos_system_trusted"] else "not trusted"
    print(f"CA certificate: {cert_state} ({cert['path']})")
    print(f"macOS System trust: {macos_trust}")
    print(
        f"Simulator: {simulator['device_name']} ({simulator['udid']}) "
        f"[booted={'yes' if simulator['booted'] else 'no'}]"
    )
    print(f"Simulator trust store: {simulator['trust_store_path']}")
    print(f"Simulator probe: {simulator['probe_action']}")
    if simulator["probe_stderr"]:
        print(f"Simulator probe stderr: {simulator['probe_stderr']}")

    for blocker in status["blockers"]:
        print(f"Blocker: {blocker}")
