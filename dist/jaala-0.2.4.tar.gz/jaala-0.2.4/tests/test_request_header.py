from __future__ import annotations

import json
import os
from unittest.mock import patch

from jaala.addon import JaalaAddon
from jaala.runtime_rules import write_runtime_config

from .test_addon import make_flow


def test_request_header_sets_matching_request_header(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"request_header": "api.example.com=X-Test:yes"}), encoding="utf-8")
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(req_headers={"Host": "api.example.com", "User-Agent": "JaalaSample/1.0"})
    addon.request(flow)

    assert flow.request.headers.get("X-Test") == "yes"


def test_request_header_skips_non_matching_request(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"request_header": "payments=X-Test:yes"}), encoding="utf-8")
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(req_headers={"Host": "api.example.com", "User-Agent": "JaalaSample/1.0"})
    addon.request(flow)

    assert flow.request.headers.get("X-Test") is None


def test_runtime_request_header_matches_url_patterns_containing_equals(tmp_path):
    config_path = tmp_path / "jaala.json"
    write_runtime_config(
        config_path,
        {
            "_jaala_runtime": {
                "rules": [
                    {
                        "name": "wiki-summary-bust-etag",
                        "type": "request_header",
                        "enabled": True,
                        "match_url": "generator=search",
                        "header_name": "X-Test",
                        "header_value": "yes",
                    }
                ]
            }
        },
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=nearcoord:5021m,37.786,-122.406",
        req_headers={"Host": "en.wikipedia.org", "User-Agent": "JaalaSample/1.0"},
    )
    addon.request(flow)

    assert flow.request.headers.get("X-Test") == "yes"
