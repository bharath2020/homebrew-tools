"""Preflight checks for Jaala."""

from __future__ import annotations

import shutil
import subprocess
import sys


def check_mitmdump() -> None:
    if not shutil.which("mitmdump"):
        print(
            "Error: mitmdump not found.\n"
            "Install mitmproxy: brew install mitmproxy",
            file=sys.stderr,
        )
        sys.exit(1)


def check_xcrun() -> None:
    if not shutil.which("xcrun"):
        print(
            "Error: xcrun not found.\n"
            "Install Xcode Command Line Tools: xcode-select --install",
            file=sys.stderr,
        )
        sys.exit(1)

    result = subprocess.run(
        ["xcrun", "simctl", "help"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        print("Error: simctl is not available. Ensure Xcode is installed.", file=sys.stderr)
        sys.exit(1)


def check_networksetup() -> None:
    if not shutil.which("networksetup"):
        print("Error: networksetup not found. This tool requires macOS.", file=sys.stderr)
        sys.exit(1)


def run_all() -> None:
    check_mitmdump()
    check_xcrun()
    check_networksetup()
