#!/usr/bin/env bash
# validate-websocket-axe.sh - Validate Jaala WebSocket features end to end with AXe and the sample app.

set -uo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

PASS=0
FAIL=0

APP_BUNDLE_ID="com.jaala.sample"
APP_PROJECT="$ROOT_DIR/sample-app/JaalaSample.xcodeproj"
APP_SCHEME="JaalaSample"
APP_DERIVED_DATA="$ROOT_DIR/sample-app/build"
APP_BINARY="$APP_DERIVED_DATA/Build/Products/Debug-iphonesimulator/JaalaSample.app"
WEBSOCKET_LABEL="WebSocket echo: expect sent and received message"
DEFAULT_SENT_MESSAGE="hello from jaala sample"
WEBSOCKET_DEMO_DURATION_SECONDS="${WEBSOCKET_DEMO_DURATION_SECONDS:-0}"
WEBSOCKET_SCROLL_LATEST="${WEBSOCKET_SCROLL_LATEST:-0}"
THROTTLE_SENT_MESSAGE="$(python3 - <<'PY'
print("t" * 1024, end="")
PY
)"

JAAALA_PORT=""
JAAALA_PID=""
ECHO_SERVER_PID=""
ECHO_PORT=""
LAST_ELAPSED_MS="0"

OUTPUT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/jaala-websocket-XXXXXX")"
JAAALA_LOG="$OUTPUT_DIR/jaala.log"
ECHO_LOG="$OUTPUT_DIR/websocket-echo.log"
JSONL_FILE="$OUTPUT_DIR/traffic.jsonl"
HAR_FILE="$OUTPUT_DIR/traffic.har"
WEBSOCKET_REPLAY_FILE="$OUTPUT_DIR/websocket-replay.jsonl"
LATEST_SCREENSHOT="$OUTPUT_DIR/latest-websocket-messages.png"
ECHO_PORT_FILE="$OUTPUT_DIR/echo-port.txt"
PROXY_BEFORE_HTTP="$OUTPUT_DIR/proxy-before-http.txt"
PROXY_BEFORE_HTTPS="$OUTPUT_DIR/proxy-before-https.txt"
PROXY_AFTER_HTTP="$OUTPUT_DIR/proxy-after-http.txt"
PROXY_AFTER_HTTPS="$OUTPUT_DIR/proxy-after-https.txt"
SIM_NAME=""
SIM_UDID=""
NETWORK_SERVICE=""
HOST_IP=""

cleanup() {
    xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
    stop_jaala >/dev/null 2>&1 || true

    if [[ -n "${ECHO_SERVER_PID:-}" ]] && kill -0 "$ECHO_SERVER_PID" >/dev/null 2>&1; then
        kill -TERM "$ECHO_SERVER_PID" >/dev/null 2>&1 || true
        for _ in {1..20}; do
            if ! kill -0 "$ECHO_SERVER_PID" >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
        if kill -0 "$ECHO_SERVER_PID" >/dev/null 2>&1; then
            kill -KILL "$ECHO_SERVER_PID" >/dev/null 2>&1 || true
        fi
        wait "$ECHO_SERVER_PID" >/dev/null 2>&1 || true
    fi

    if [[ -f "$HOME/.jaala/session.lock" ]]; then
        python3 -m jaala --cleanup >/dev/null 2>&1 || true
    fi
}

trap cleanup EXIT INT TERM

check() {
    local desc="$1"
    local result="${2:-false}"
    if [[ "$result" == "true" ]]; then
        echo -e "  ${GREEN}✓${NC} $desc"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}✗${NC} $desc"
        FAIL=$((FAIL + 1))
    fi
}

require_cmd() {
    local cmd="$1"
    if command -v "$cmd" >/dev/null 2>&1; then
        check "$cmd is installed" "true"
    else
        check "$cmd is installed" "false"
        exit 1
    fi
}

detect_active_service() {
    local service
    for service in "Wi-Fi" "Ethernet" "USB 10/100/1000 LAN"; do
        if networksetup -getinfo "$service" 2>/dev/null | grep -Fq "IP address"; then
            printf '%s' "$service"
            return 0
        fi
    done

    while IFS= read -r service; do
        service="${service#\*}"
        service="${service# }"
        service="${service% }"
        [[ -z "$service" ]] && continue
        if networksetup -getinfo "$service" 2>/dev/null | grep -Fq "IP address"; then
            printf '%s' "$service"
            return 0
        fi
    done < <(networksetup -listallnetworkservices 2>/dev/null | tail -n +2)

    return 1
}

detect_active_service_ip() {
    local info ip
    info="$(networksetup -getinfo "$NETWORK_SERVICE" 2>/dev/null || true)"
    ip="$(printf '%s\n' "$info" | awk -F': ' '/^IP address: / { print $2; exit }')"
    if [[ -z "$ip" ]]; then
        return 1
    fi
    printf '%s' "$ip"
}

capture_proxy_state() {
    networksetup -getwebproxy "$NETWORK_SERVICE" >"$PROXY_BEFORE_HTTP"
    networksetup -getsecurewebproxy "$NETWORK_SERVICE" >"$PROXY_BEFORE_HTTPS"
}

capture_proxy_state_after() {
    networksetup -getwebproxy "$NETWORK_SERVICE" >"$PROXY_AFTER_HTTP"
    networksetup -getsecurewebproxy "$NETWORK_SERVICE" >"$PROXY_AFTER_HTTPS"
}

assert_proxy_restored() {
    local case_name="$1"
    capture_proxy_state_after
    if cmp -s "$PROXY_BEFORE_HTTP" "$PROXY_AFTER_HTTP" && cmp -s "$PROXY_BEFORE_HTTPS" "$PROXY_AFTER_HTTPS"; then
        check "${case_name} restores host proxy settings" "true"
    else
        check "${case_name} restores host proxy settings" "false"
    fi
}

wait_for_port() {
    local port="$1"
    local timeout_seconds="$2"
    python3 - "$port" "$timeout_seconds" <<'PY'
import socket
import sys
import time

port = int(sys.argv[1])
timeout = float(sys.argv[2])
deadline = time.monotonic() + timeout

while time.monotonic() < deadline:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.2):
            sys.exit(0)
    except OSError:
        time.sleep(0.1)

sys.exit(1)
PY
}

wait_for_file() {
    local path="$1"
    local timeout_seconds="$2"
    local deadline=$(( $(date +%s) + timeout_seconds ))

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if [[ -s "$path" ]]; then
            return 0
        fi
        sleep 1
    done

    return 1
}

now_ms() {
    python3 - <<'PY'
import time
print(int(time.time() * 1000))
PY
}

simulator_value() {
    local field="$1"
    printf '%s' "$SIM_JSON" | python3 -c '
import json
import sys

field = sys.argv[1]
data = json.load(sys.stdin)
for devices in data.get("devices", {}).values():
    for device in devices:
        if device.get("state") == "Booted":
            print(device.get(field, ""))
            raise SystemExit(0)
print("")
' "$field"
}

axe_wait_for_text() {
    local text="$1"
    local timeout_ms="$2"
    local deadline=$(( $(date +%s) + (timeout_ms + 999) / 1000 ))
    local ui=""

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        ui=$(axe describe-ui --udid "$SIM_UDID" 2>/dev/null || true)
        if printf '%s' "$ui" | grep -Fq "$text"; then
            return 0
        fi
        sleep 1
    done

    echo -e "  ${YELLOW}Last AXe UI snapshot did not contain: ${text}${NC}"
    return 1
}

reset_case_artifacts() {
    rm -f "$JSONL_FILE" "$HAR_FILE" "$JAAALA_LOG"
}

assert_har_exists() {
    local case_name="$1"
    if [[ -s "$HAR_FILE" ]]; then
        check "${case_name} writes a HAR file" "true"
    else
        check "${case_name} writes a HAR file" "false"
    fi
}

assert_elapsed_at_least() {
    local case_name="$1"
    local minimum_ms="$2"
    if [[ "$LAST_ELAPSED_MS" -ge "$minimum_ms" ]]; then
        check "${case_name} adds visible latency (${LAST_ELAPSED_MS}ms)" "true"
    else
        check "${case_name} adds visible latency (${LAST_ELAPSED_MS}ms)" "false"
    fi
}

assert_websocket_texts() {
    local case_name="$1"
    local expected_client="$2"
    local expected_server="$3"
    if python3 - "$JSONL_FILE" "$HOST_IP" "$ECHO_PORT" "$expected_client" "$expected_server" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
host_ip = sys.argv[2]
port = sys.argv[3]
expected_client = sys.argv[4]
expected_server = sys.argv[5]
expected_urls = {
    f"ws://{host_ip}:{port}/echo",
    f"http://{host_ip}:{port}/echo",
}

records = [
    json.loads(line)
    for line in jsonl_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]

websocket_records = [
    record
    for record in records
    if record.get("type") == "websocket_message" and record.get("url") in expected_urls
]

client_matches = [
    record
    for record in websocket_records
    if record.get("direction") == "client_to_server"
    and record.get("message", {}).get("text") == expected_client
]

server_matches = [
    record
    for record in websocket_records
    if record.get("direction") == "server_to_client"
    and record.get("message", {}).get("text") == expected_server
]

if not client_matches:
    raise SystemExit(f"Missing client_to_server WebSocket message {expected_client!r}")

if not server_matches:
    raise SystemExit(f"Missing server_to_client WebSocket message {expected_server!r}")
PY
    then
        check "${case_name} captures expected WebSocket messages" "true"
    else
        check "${case_name} captures expected WebSocket messages" "false"
    fi
}

assert_no_websocket_messages() {
    local case_name="$1"
    if python3 - "$JSONL_FILE" "$HOST_IP" "$ECHO_PORT" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
host_ip = sys.argv[2]
port = sys.argv[3]
expected_urls = {
    f"ws://{host_ip}:{port}/echo",
    f"http://{host_ip}:{port}/echo",
}

if not jsonl_path.exists():
    raise SystemExit("JSONL file missing")

records = [
    json.loads(line)
    for line in jsonl_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]

websocket_records = [
    record
    for record in records
    if record.get("type") == "websocket_message" and record.get("url") in expected_urls
]

if websocket_records:
    raise SystemExit(f"Expected no WebSocket message records, found {len(websocket_records)}")
PY
    then
        check "${case_name} leaves no WebSocket message records" "true"
    else
        check "${case_name} leaves no WebSocket message records" "false"
    fi
}

write_mock_replay_file() {
    local source_jsonl="$1"
    local replay_jsonl="$2"
    local mock_text="$3"
    python3 - "$source_jsonl" "$replay_jsonl" "$mock_text" <<'PY'
import json
import sys
from pathlib import Path

source = Path(sys.argv[1])
target = Path(sys.argv[2])
mock_text = sys.argv[3]

for line in source.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    record = json.loads(line)
    if (
        record.get("type") == "websocket_message"
        and record.get("direction") == "server_to_client"
        and record.get("opcode") == "text"
    ):
        record["message"]["text"] = mock_text
        record["message"]["size"] = len(mock_text.encode("utf-8"))
        target.write_text(json.dumps(record) + "\n", encoding="utf-8")
        raise SystemExit(0)

raise SystemExit("No server_to_client WebSocket text record found for replay")
PY
}

start_jaala() {
    local case_name="$1"
    shift

    reset_case_artifacts
    capture_proxy_state

    python3 -m jaala \
        --quiet \
        --port "$JAAALA_PORT" \
        --json-file "$JSONL_FILE" \
        --save-har "$HAR_FILE" \
        --filter "${HOST_IP}:${ECHO_PORT}/echo" \
        "$@" >"$JAAALA_LOG" 2>&1 &
    JAAALA_PID=$!

    if ! wait_for_port "$JAAALA_PORT" 30; then
        echo -e "${RED}Jaala did not start listening on port ${JAAALA_PORT}.${NC}"
        sed -n '1,220p' "$JAAALA_LOG"
        check "${case_name} starts Jaala" "false"
        exit 1
    fi

    if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        echo -e "${RED}Jaala exited before ${case_name} could start.${NC}"
        sed -n '1,220p' "$JAAALA_LOG"
        check "${case_name} starts Jaala" "false"
        exit 1
    fi

    check "${case_name} starts Jaala" "true"
}

stop_jaala() {
    if [[ -z "${JAAALA_PID:-}" ]]; then
        return 0
    fi

    if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        JAAALA_PID=""
        return 0
    fi

    kill -TERM "$JAAALA_PID" >/dev/null 2>&1 || true
    for _ in {1..30}; do
        if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done

    if kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        kill -KILL "$JAAALA_PID" >/dev/null 2>&1 || true
    fi

    wait "$JAAALA_PID" >/dev/null 2>&1 || true
    JAAALA_PID=""

    if [[ -f "$HOME/.jaala/session.lock" ]]; then
        python3 -m jaala --cleanup >/dev/null 2>&1 || true
    fi
}

launch_sample_app() {
    local case_name="$1"
    local sent_message="$2"
    local timeout_seconds="$3"

    xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
    if xcrun simctl launch \
        "$SIM_UDID" \
        "$APP_BUNDLE_ID" \
        --websocket-url "ws://${HOST_IP}:${ECHO_PORT}/echo" \
        --websocket-proxy-host "$HOST_IP" \
        --websocket-proxy-port "$JAAALA_PORT" \
        --websocket-sent-text "$sent_message" \
        --websocket-timeout-seconds "$timeout_seconds" \
        --websocket-stream-seconds "$WEBSOCKET_DEMO_DURATION_SECONDS" >/dev/null; then
        check "${case_name} launches the sample app" "true"
    else
        check "${case_name} launches the sample app" "false"
        exit 1
    fi

    if axe_wait_for_text "$WEBSOCKET_LABEL" 30000; then
        check "${case_name} exposes the WebSocket control to AXe" "true"
    else
        check "${case_name} exposes the WebSocket control to AXe" "false"
        exit 1
    fi
}

tap_websocket_and_wait() {
    local case_name="$1"
    local timeout_ms="$2"
    local start_ms end_ms

    start_ms="$(now_ms)"
    if axe tap --label "$WEBSOCKET_LABEL" --udid "$SIM_UDID" >/dev/null; then
        check "${case_name} taps the WebSocket control" "true"
    else
        check "${case_name} taps the WebSocket control" "false"
        exit 1
    fi

    if axe_wait_for_text "Results (1)" "$timeout_ms"; then
        check "${case_name} records one WebSocket result" "true"
    else
        check "${case_name} records one WebSocket result" "false"
        exit 1
    fi

    end_ms="$(now_ms)"
    LAST_ELAPSED_MS=$(( end_ms - start_ms ))
}

wait_for_websocket_message_count() {
    local timeout_seconds="$1"
    local min_messages="$2"
    local deadline=$(( $(date +%s) + timeout_seconds ))

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if [[ -s "$JSONL_FILE" ]] && python3 - "$JSONL_FILE" "http://${HOST_IP}:${ECHO_PORT}/echo" "ws://${HOST_IP}:${ECHO_PORT}/echo" "$min_messages" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
expected_urls = {sys.argv[2], sys.argv[3]}
min_messages = int(sys.argv[4])

records = [
    json.loads(line)
    for line in jsonl_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]
server_records = [
    record
    for record in records
    if record.get("type") == "websocket_message"
    and record.get("url") in expected_urls
    and record.get("direction") == "server_to_client"
]
if len(server_records) < min_messages:
    raise SystemExit(1)
PY
        then
            return 0
        fi
        sleep 1
    done

    return 1
}

scroll_to_latest_websocket_messages() {
    for _ in {1..4}; do
        axe swipe \
            --udid "$SIM_UDID" \
            --start-x 200 \
            --start-y 720 \
            --end-x 200 \
            --end-y 220 \
            --duration 0.25 \
            --post-delay 0.2 >/dev/null 2>&1 || return 1
    done

    axe screenshot --udid "$SIM_UDID" --output "$LATEST_SCREENSHOT" >/dev/null 2>&1 || return 1
    [[ -s "$LATEST_SCREENSHOT" ]]
}

run_capture_case() {
    local case_name="capture"
    start_jaala "$case_name"
    launch_sample_app "$case_name" "$DEFAULT_SENT_MESSAGE" "5"
    tap_websocket_and_wait "$case_name" 30000
    stop_jaala
    assert_proxy_restored "$case_name"
    assert_websocket_texts "$case_name" "$DEFAULT_SENT_MESSAGE" "$DEFAULT_SENT_MESSAGE"
    assert_har_exists "$case_name"
}

run_stream_case() {
    local case_name="stream"
    start_jaala "$case_name"
    launch_sample_app "$case_name" "$DEFAULT_SENT_MESSAGE" "$((WEBSOCKET_DEMO_DURATION_SECONDS + 10))"
    tap_websocket_and_wait "$case_name" 30000
    if wait_for_websocket_message_count "$((WEBSOCKET_DEMO_DURATION_SECONDS + 15))" "$WEBSOCKET_DEMO_DURATION_SECONDS"; then
        check "${case_name} keeps receiving WebSocket messages for ${WEBSOCKET_DEMO_DURATION_SECONDS}s" "true"
    else
        check "${case_name} keeps receiving WebSocket messages for ${WEBSOCKET_DEMO_DURATION_SECONDS}s" "false"
    fi
    if [[ "$WEBSOCKET_SCROLL_LATEST" == "1" ]]; then
        if scroll_to_latest_websocket_messages; then
            check "${case_name} scrolls down to latest WebSocket messages" "true"
        else
            check "${case_name} scrolls down to latest WebSocket messages" "false"
        fi
    fi
    stop_jaala
    assert_proxy_restored "$case_name"
    assert_har_exists "$case_name"
}

run_replay_case() {
    local case_name="replay"
    local replay_message="mocked by jaala replay"

    write_mock_replay_file "$JSONL_FILE" "$WEBSOCKET_REPLAY_FILE" "$replay_message"
    start_jaala "$case_name" \
        --websocket-replay "$WEBSOCKET_REPLAY_FILE" \
        --websocket-replay-pattern "${HOST_IP}:${ECHO_PORT}/echo"
    launch_sample_app "$case_name" "$DEFAULT_SENT_MESSAGE" "5"
    tap_websocket_and_wait "$case_name" 30000
    stop_jaala
    assert_proxy_restored "$case_name"
    assert_websocket_texts "$case_name" "$DEFAULT_SENT_MESSAGE" "$replay_message"
    assert_har_exists "$case_name"
}

run_replace_case() {
    local case_name="replace"
    local replaced_message="replaced by jaala"
    start_jaala "$case_name" --websocket-message-replace "${HOST_IP}:${ECHO_PORT}/echo=${DEFAULT_SENT_MESSAGE}>>>${replaced_message}"
    launch_sample_app "$case_name" "$DEFAULT_SENT_MESSAGE" "5"
    tap_websocket_and_wait "$case_name" 30000
    stop_jaala
    assert_proxy_restored "$case_name"
    assert_websocket_texts "$case_name" "$replaced_message" "$replaced_message"
    assert_har_exists "$case_name"
}

run_drop_case() {
    local case_name="drop-message"
    start_jaala "$case_name" --websocket-drop-message "${HOST_IP}:${ECHO_PORT}/echo"
    launch_sample_app "$case_name" "$DEFAULT_SENT_MESSAGE" "5"
    tap_websocket_and_wait "$case_name" 45000
    stop_jaala
    assert_proxy_restored "$case_name"
    assert_no_websocket_messages "$case_name"
    assert_har_exists "$case_name"
}

run_fail_rate_case() {
    local case_name="fail-rate"
    start_jaala "$case_name" --websocket-fail-rate "${HOST_IP}:${ECHO_PORT}/echo=100"
    launch_sample_app "$case_name" "$DEFAULT_SENT_MESSAGE" "5"
    tap_websocket_and_wait "$case_name" 45000
    stop_jaala
    assert_proxy_restored "$case_name"
    assert_no_websocket_messages "$case_name"
    assert_har_exists "$case_name"
}

run_delay_case() {
    local case_name="delay"
    start_jaala "$case_name" --websocket-delay "${HOST_IP}:${ECHO_PORT}/echo=1200"
    launch_sample_app "$case_name" "$DEFAULT_SENT_MESSAGE" "8"
    tap_websocket_and_wait "$case_name" 45000
    stop_jaala
    assert_proxy_restored "$case_name"
    assert_websocket_texts "$case_name" "$DEFAULT_SENT_MESSAGE" "$DEFAULT_SENT_MESSAGE"
    assert_elapsed_at_least "$case_name" 2000
    assert_har_exists "$case_name"
}

run_throttle_case() {
    local case_name="throttle"
    start_jaala "$case_name" --websocket-throttle "${HOST_IP}:${ECHO_PORT}/echo=1"
    launch_sample_app "$case_name" "$THROTTLE_SENT_MESSAGE" "8"
    tap_websocket_and_wait "$case_name" 45000
    stop_jaala
    assert_proxy_restored "$case_name"
    assert_websocket_texts "$case_name" "$THROTTLE_SENT_MESSAGE" "$THROTTLE_SENT_MESSAGE"
    assert_elapsed_at_least "$case_name" 1500
    assert_har_exists "$case_name"
}

start_websocket_echo_server() {
    python3 - "$ECHO_PORT_FILE" "$WEBSOCKET_DEMO_DURATION_SECONDS" >"$ECHO_LOG" 2>&1 <<'PY' &
import base64
import hashlib
import socket
import struct
import sys
import time

MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
port_file = sys.argv[1]
duration_seconds = int(sys.argv[2])


def write_port(port):
    with open(port_file, "w", encoding="utf-8") as handle:
        handle.write(str(port))
        handle.flush()


def read_request(conn):
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = conn.recv(4096)
        if not chunk:
            raise ConnectionError("handshake closed early")
        data += chunk
    header_block, remainder = data.split(b"\r\n\r\n", 1)
    lines = header_block.decode("latin1").split("\r\n")
    request_line = lines[0]
    headers = {}
    for line in lines[1:]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        headers[key.strip().lower()] = value.strip()
    return request_line, headers, remainder


def send_frame(conn, opcode, payload=b""):
    first_byte = 0x80 | (opcode & 0x0F)
    length = len(payload)
    if length < 126:
        header = struct.pack("!BB", first_byte, length)
    elif length < 65536:
        header = struct.pack("!BBH", first_byte, 126, length)
    else:
        header = struct.pack("!BBQ", first_byte, 127, length)
    conn.sendall(header + payload)


def handle_connection(conn):
    conn.settimeout(max(30, duration_seconds + 10))
    request_line, headers, buffered = read_request(conn)
    del request_line
    key = headers.get("sec-websocket-key")
    if not key:
        raise ConnectionError("missing websocket key")

    accept = base64.b64encode(
        hashlib.sha1((key + MAGIC).encode("ascii")).digest()
    ).decode("ascii")
    response = (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept}\r\n"
        "\r\n"
    )
    conn.sendall(response.encode("ascii"))

    pending = buffered
    while True:
        while len(pending) < 2:
            chunk = conn.recv(4096)
            if not chunk:
                return
            pending += chunk

        first_byte = pending[0]
        second_byte = pending[1]
        pending = pending[2:]
        opcode = first_byte & 0x0F
        masked = bool(second_byte & 0x80)
        payload_length = second_byte & 0x7F

        if payload_length == 126:
            while len(pending) < 2:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                pending += chunk
            payload_length = struct.unpack("!H", pending[:2])[0]
            pending = pending[2:]
        elif payload_length == 127:
            while len(pending) < 8:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                pending += chunk
            payload_length = struct.unpack("!Q", pending[:8])[0]
            pending = pending[8:]

        mask_key = b""
        if masked:
            while len(pending) < 4:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                pending += chunk
            mask_key = pending[:4]
            pending = pending[4:]

        while len(pending) < payload_length:
            chunk = conn.recv(4096)
            if not chunk:
                return
            pending += chunk
        payload = pending[:payload_length]
        pending = pending[payload_length:]

        if masked and payload_length:
            payload = bytes(
                byte ^ mask_key[index % 4]
                for index, byte in enumerate(payload)
            )

        if opcode == 0x8:
            send_frame(conn, 0x8)
            return
        if opcode == 0x9:
            send_frame(conn, 0xA, payload)
            continue
        if opcode == 0x1:
            send_frame(conn, 0x1, payload)
            if duration_seconds > 0:
                for index in range(duration_seconds):
                    send_frame(conn, 0x1, f"websocket tick {index + 1}".encode("utf-8"))
                    time.sleep(1)
            continue
        if opcode == 0x2:
            send_frame(conn, 0x2, payload)
            continue


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(("0.0.0.0", 0))
server.listen(4)
write_port(server.getsockname()[1])
print(f"Echo server listening on {server.getsockname()[1]}", flush=True)

while True:
    conn, _ = server.accept()
    try:
        handle_connection(conn)
    except Exception as exc:  # pragma: no cover - diagnostic output only
        print(f"WebSocket echo server error: {exc}", flush=True)
    finally:
        try:
            conn.close()
        except Exception:
            pass
PY
    ECHO_SERVER_PID=$!

    if ! wait_for_file "$ECHO_PORT_FILE" 10; then
        echo -e "${RED}WebSocket echo server did not write its port file.${NC}"
        if [[ -s "$ECHO_LOG" ]]; then
            sed -n '1,120p' "$ECHO_LOG"
        fi
        exit 1
    fi

    ECHO_PORT="$(cat "$ECHO_PORT_FILE")"
    if [[ -z "$ECHO_PORT" ]]; then
        echo -e "${RED}WebSocket echo server did not provide a port.${NC}"
        exit 1
    fi

    if ! wait_for_port "$ECHO_PORT" 10; then
        echo -e "${RED}WebSocket echo server did not start listening on port ${ECHO_PORT}.${NC}"
        sed -n '1,120p' "$ECHO_LOG"
        exit 1
    fi
}

echo "========================================"
echo "  Jaala WebSocket AXe validation"
echo "========================================"
echo ""

echo "Step 0: Checking prerequisites..."
require_cmd python3
require_cmd xcodebuild
require_cmd xcrun
require_cmd axe
require_cmd mitmdump

SIM_JSON=$(xcrun simctl list devices booted -j 2>/dev/null)
SIM_UDID=$(simulator_value udid)
SIM_NAME=$(simulator_value name)

if [[ -z "$SIM_UDID" ]]; then
    echo -e "${RED}No booted simulator found. Boot a simulator and retry.${NC}"
    exit 1
fi

NETWORK_SERVICE="$(detect_active_service)"
if [[ -z "$NETWORK_SERVICE" ]]; then
    echo -e "${RED}No active network service found.${NC}"
    exit 1
fi
HOST_IP="$(detect_active_service_ip)"
if [[ -z "$HOST_IP" ]]; then
    echo -e "${RED}No host IP address found for ${NETWORK_SERVICE}.${NC}"
    exit 1
fi

echo -e "  Booted simulator: ${YELLOW}${SIM_NAME} (${SIM_UDID})${NC}"
echo -e "  Active network service: ${YELLOW}${NETWORK_SERVICE}${NC}"
echo -e "  Host IP address: ${YELLOW}${HOST_IP}${NC}"
echo ""

echo "Step 1: Building and installing the sample app..."
if xcodebuild \
    -project "$APP_PROJECT" \
    -scheme "$APP_SCHEME" \
    -configuration Debug \
    -sdk iphonesimulator \
    -derivedDataPath "$APP_DERIVED_DATA" \
    build >/tmp/jaala_websocket_xcodebuild_$$.log 2>&1; then
    check "Sample app builds for iOS Simulator" "true"
else
    check "Sample app builds for iOS Simulator" "false"
    echo ""
    echo "xcodebuild log:"
    sed -n '1,220p' "/tmp/jaala_websocket_xcodebuild_$$.log"
    exit 1
fi

if xcrun simctl install "$SIM_UDID" "$APP_BINARY" >/dev/null; then
    check "Sample app installs on the booted Simulator" "true"
else
    check "Sample app installs on the booted Simulator" "false"
    exit 1
fi
echo ""

start_websocket_echo_server

JAAALA_PORT="$(python3 - <<'PY'
import socket

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    sock.bind(("127.0.0.1", 0))
    print(sock.getsockname()[1])
PY
)"

echo "Step 2: Running WebSocket option matrix..."
echo -e "  WebSocket echo server: ${YELLOW}ws://${HOST_IP}:${ECHO_PORT}/echo${NC}"
if [[ "$WEBSOCKET_DEMO_DURATION_SECONDS" -gt 0 ]]; then
    run_stream_case
else
    run_capture_case
    run_replay_case
    run_replace_case
    run_drop_case
    run_fail_rate_case
    run_delay_case
    run_throttle_case
fi
echo ""

echo "Step 3: Final cleanup checks..."
if [[ -n "${ECHO_SERVER_PID:-}" ]] && kill -0 "$ECHO_SERVER_PID" >/dev/null 2>&1; then
    kill -TERM "$ECHO_SERVER_PID" >/dev/null 2>&1 || true
    for _ in {1..20}; do
        if ! kill -0 "$ECHO_SERVER_PID" >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done
    if kill -0 "$ECHO_SERVER_PID" >/dev/null 2>&1; then
        kill -KILL "$ECHO_SERVER_PID" >/dev/null 2>&1 || true
    fi
    wait "$ECHO_SERVER_PID" >/dev/null 2>&1 || true
fi

if pgrep -f "python3 -m jaala --quiet --port ${JAAALA_PORT}" >/dev/null 2>&1; then
    check "No jaala process remains" "false"
else
    check "No jaala process remains" "true"
fi

if pgrep -f "mitmdump --listen-port ${JAAALA_PORT}" >/dev/null 2>&1; then
    check "No mitmdump process remains" "false"
else
    check "No mitmdump process remains" "true"
fi

if [[ -n "${ECHO_SERVER_PID:-}" ]] && kill -0 "$ECHO_SERVER_PID" >/dev/null 2>&1; then
    check "No WebSocket echo server process remains" "false"
else
    check "No WebSocket echo server process remains" "true"
fi

echo ""
echo "========================================"
echo -e "  Results: ${GREEN}$PASS passed${NC}, ${RED}$FAIL failed${NC}"
echo "========================================"

if [[ "$FAIL" -gt 0 ]]; then
    exit 1
fi

echo -e "${GREEN}All validations passed.${NC}"
