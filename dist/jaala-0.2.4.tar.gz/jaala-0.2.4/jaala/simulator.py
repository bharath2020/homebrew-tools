"""Simulator discovery and management via xcrun simctl."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any


def run_simctl(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["xcrun", "simctl", *args], capture_output=True, text=True, check=check)


def _devices_json() -> dict:
    result = run_simctl("list", "devices", "-j", "available")
    return json.loads(result.stdout or "{}")


def get_booted_simulator() -> dict:
    data = _devices_json()
    for runtime, devices in data.get("devices", {}).items():
        for device in devices:
            if device.get("state") == "Booted":
                device["runtime"] = runtime
                return device
    print("Error: No booted simulator found.", file=sys.stderr)
    print("Boot a simulator first: xcrun simctl boot <device>", file=sys.stderr)
    sys.exit(1)


def get_simulator_by_udid(udid: str) -> dict:
    data = _devices_json()
    for runtime, devices in data.get("devices", {}).items():
        for device in devices:
            if device.get("udid") == udid:
                device["runtime"] = runtime
                return device
    print(f"Error: Simulator with UDID {udid} not found.", file=sys.stderr)
    sys.exit(1)


def wait_for_simulator_boot(udid: str, timeout: int = 60) -> bool:
    result = run_simctl("bootstatus", udid, "-b", check=False)
    if result.returncode == 0:
        return True

    result = run_simctl("bootstatus", udid, "-b", str(timeout), check=False)
    return result.returncode == 0


def _is_transient_boot_state_error(stderr: str) -> bool:
    text = stderr.strip().lower()
    return "unable to lookup in current state" in text or "shutdown" in text or "booted" in text


def resolve_simulator(udid: str | None) -> dict:
    if udid:
        device = get_simulator_by_udid(udid)
        if device.get("state") != "Booted":
            print(f"Booting simulator {device['name']} ({device['udid']})...")
            run_simctl("boot", device["udid"])
            if not wait_for_simulator_boot(device["udid"]):
                print(f"Error: Simulator {device['udid']} did not finish booting.", file=sys.stderr)
                sys.exit(1)
        return device
    return get_booted_simulator()


def list_simulators() -> list[dict]:
    data = _devices_json()
    simulators: list[dict] = []
    for runtime, devices in data.get("devices", {}).items():
        for device in devices:
            if device.get("availabilityError"):
                continue
            if device.get("isAvailable") is False:
                continue
            simulators.append(
                {
                    "name": device.get("name", "Unknown"),
                    "udid": device.get("udid", ""),
                    "state": device.get("state", "Unknown"),
                    "runtime": runtime,
                }
            )
    return simulators


def print_simulators() -> None:
    simulators = list_simulators()
    if not simulators:
        print("No available simulators found.")
        return

    for simulator in simulators:
        print(
            f'{simulator["name"]} ({simulator["udid"]}) '
            f'[{simulator["runtime"]}] - {simulator["state"]}'
        )


def simulator_trust_store_path(udid: str) -> Path:
    return (
        Path.home()
        / "Library"
        / "Developer"
        / "CoreSimulator"
        / "Devices"
        / udid
        / "data"
        / "private"
        / "var"
        / "protected"
        / "trustd"
        / "private"
        / "TrustStore.sqlite3"
    )


def _simulator_cert_probe_result(result: subprocess.CompletedProcess[str]) -> tuple[str, bool]:
    stderr = result.stderr.strip().lower()
    if result.returncode == 0:
        return "installed", True
    if "already" in stderr or "duplicate" in stderr or not stderr:
        return "already_installed", True
    return "failed", False


def probe_simulator_cert_status(udid: str, cert_path: str) -> dict[str, Any]:
    """Probe whether a simulator is ready to trust the mitmproxy CA.

    This is an idempotent readiness probe. It uses ``simctl keychain add-root-cert``
    because simctl does not expose a read-only inspection command for simulator root
    certificates.
    """
    device = get_simulator_by_udid(udid)
    booted = device.get("state") == "Booted"
    trust_store = simulator_trust_store_path(udid)
    cert = Path(cert_path).expanduser()

    status: dict[str, Any] = {
        "udid": device.get("udid", udid),
        "device_name": device.get("name", "Unknown"),
        "runtime": device.get("runtime"),
        "booted": booted,
        "cert_path": str(cert),
        "cert_exists": cert.exists(),
        "trust_store_path": str(trust_store),
        "trust_store_exists": trust_store.exists(),
        "probe_action": "not_run",
        "probe_returncode": None,
        "probe_stderr": "",
        "installed": False,
        "ready": False,
    }

    if not booted or not cert.exists():
        return status

    if not wait_for_simulator_boot(udid):
        status["probe_action"] = "failed"
        status["probe_stderr"] = "Simulator boot did not complete."
        return status

    result = run_simctl("keychain", udid, "add-root-cert", str(cert), check=False)
    probe_action, installed = _simulator_cert_probe_result(result)
    status["probe_action"] = probe_action
    status["probe_returncode"] = result.returncode
    status["probe_stderr"] = result.stderr.strip()
    status["installed"] = installed
    status["ready"] = installed
    return status


def install_cert_in_simulator(udid: str, cert_path: str) -> None:
    if not wait_for_simulator_boot(udid):
        print(f"Warning: Simulator {udid} did not finish booting before cert install.", file=sys.stderr)
        return

    result = run_simctl("keychain", udid, "add-root-cert", cert_path, check=False)
    if result.returncode != 0 and _is_transient_boot_state_error(result.stderr):
        if wait_for_simulator_boot(udid):
            result = run_simctl("keychain", udid, "add-root-cert", cert_path, check=False)

    if result.returncode == 0:
        return

    stderr = result.stderr.strip()
    if "already" in stderr.lower() or "duplicate" in stderr.lower() or not stderr:
        return

    print(f"Warning: Certificate install returned: {stderr}", file=sys.stderr)
