"""Tests for readiness aggregation and presentation."""

from __future__ import annotations

from unittest.mock import patch

from jaala.certs import CA_CERT_PEM
from jaala.readiness import collect_cert_probe_status


@patch("jaala.readiness.probe_simulator_cert_status")
@patch("jaala.readiness.resolve_simulator")
@patch("jaala.readiness.get_ca_cert_status")
def test_collect_cert_probe_status_uses_resolved_simulator(
    mock_get_ca_cert_status,
    mock_resolve_simulator,
    mock_probe_simulator_cert_status,
):
    mock_get_ca_cert_status.return_value = {
        "path": "/tmp/mitmproxy-ca-cert.pem",
        "exists": True,
        "trusted_in_macos": True,
        "ready": True,
    }
    mock_resolve_simulator.return_value = {
        "udid": "ABC-123",
        "name": "iPhone 16",
        "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
        "state": "Booted",
    }
    mock_probe_simulator_cert_status.return_value = {
        "udid": "ABC-123",
        "device_name": "iPhone 16",
        "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
        "booted": True,
        "cert_path": "/tmp/mitmproxy-ca-cert.pem",
        "cert_exists": True,
        "trust_store_path": "/tmp/TrustStore.sqlite3",
        "trust_store_exists": True,
        "probe_action": "already_installed",
        "probe_returncode": 1,
        "probe_stderr": "Certificate already exists",
        "installed": True,
        "ready": True,
    }

    status = collect_cert_probe_status(simulator_udid="ABC-123")

    assert status["ready"] is True
    assert status["blockers"] == []
    mock_resolve_simulator.assert_called_once_with("ABC-123")
    mock_probe_simulator_cert_status.assert_called_once_with("ABC-123", str(CA_CERT_PEM))


@patch("jaala.readiness.probe_simulator_cert_status")
@patch("jaala.readiness.resolve_simulator")
@patch("jaala.readiness.get_ca_cert_status")
def test_collect_cert_probe_status_reports_probe_failure(
    mock_get_ca_cert_status,
    mock_resolve_simulator,
    mock_probe_simulator_cert_status,
):
    mock_get_ca_cert_status.return_value = {
        "path": "/tmp/mitmproxy-ca-cert.pem",
        "exists": True,
        "trusted_in_macos": False,
        "ready": False,
    }
    mock_resolve_simulator.return_value = {
        "udid": "ABC-123",
        "name": "iPhone 16",
        "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
        "state": "Booted",
    }
    mock_probe_simulator_cert_status.return_value = {
        "udid": "ABC-123",
        "device_name": "iPhone 16",
        "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
        "booted": True,
        "cert_path": "/tmp/mitmproxy-ca-cert.pem",
        "cert_exists": True,
        "trust_store_path": "/tmp/TrustStore.sqlite3",
        "trust_store_exists": True,
        "probe_action": "failed",
        "probe_returncode": 1,
        "probe_stderr": "permission denied",
        "installed": False,
        "ready": False,
    }

    status = collect_cert_probe_status()

    assert status["ready"] is False
    assert "CA certificate is not trusted in the macOS System keychain." in status["blockers"]
    assert "Simulator certificate probe failed: permission denied" in status["blockers"]
    mock_resolve_simulator.assert_called_once_with(None)
