"""Tests for network proxy configuration."""

from __future__ import annotations

from unittest.mock import MagicMock, call, patch

import pytest

from jaala import network
from jaala.network import ProxyConfig, _find_active_service


def _mock_networksetup(stdout: str = "", returncode: int = 0, stderr: str = ""):
    result = MagicMock()
    result.stdout = stdout
    result.stderr = stderr
    result.returncode = returncode
    return result


class TestFindActiveService:
    @patch.object(network, "_run_networksetup")
    def test_wifi_found(self, mock_run):
        def side_effect(*args):
            if args == ("-getinfo", "Wi-Fi"):
                return _mock_networksetup(stdout="IP address: 192.168.1.10")
            return _mock_networksetup(returncode=1)

        mock_run.side_effect = side_effect
        assert _find_active_service() == "Wi-Fi"

    @patch.object(network, "_run_networksetup")
    def test_no_service_exits(self, mock_run):
        mock_run.return_value = _mock_networksetup(returncode=1)
        with pytest.raises(SystemExit):
            _find_active_service()


class TestCollectProxyStatus:
    @patch.object(network, "_run_networksetup")
    def test_collect_proxy_status_detects_active_service_and_expected_port(self, mock_run):
        mock_run.side_effect = [
            _mock_networksetup(stdout="IP address: 192.168.1.10\n"),
            _mock_networksetup(stdout="Enabled: Yes\nServer: 127.0.0.1\nPort: 8080\n"),
            _mock_networksetup(stdout="Enabled: No\nServer: \nPort: 0\n"),
        ]

        status = network.collect_proxy_status(expected_port=8080)

        assert status["service"] == "Wi-Fi"
        assert status["error"] is None
        assert status["http"]["points_to_jaala"] is True
        assert status["http"]["matches_expected_port"] is True
        assert status["https"]["enabled"] is False

    @patch.object(network, "_run_networksetup")
    def test_collect_proxy_status_reports_explicit_service_errors(self, mock_run):
        mock_run.return_value = _mock_networksetup(returncode=1, stdout="", stderr="not found")

        status = network.collect_proxy_status(service="Bogus Service")

        assert status == {
            "service": "Bogus Service",
            "service_source": "explicit",
            "error": "not found",
            "http": None,
            "https": None,
        }


class TestProxyConfig:
    def test_parse_proxy_output(self):
        config = ProxyConfig(port=8080, service="Wi-Fi", quiet=True)
        state = config._parse_proxy_state("Enabled: Yes\nServer: 127.0.0.1\nPort: 8080\n")
        assert state["Enabled"] == "Yes"
        assert state["Server"] == "127.0.0.1"
        assert state["Port"] == "8080"

    @patch.object(network, "_run_networksetup")
    def test_enable_records_original_state_and_sets_proxy(self, mock_run):
        mock_run.side_effect = [
            _mock_networksetup(stdout="Enabled: No\nServer: \nPort: 0\n"),
            _mock_networksetup(stdout="Enabled: No\nServer: \nPort: 0\n"),
            _mock_networksetup(),
            _mock_networksetup(),
            _mock_networksetup(),
            _mock_networksetup(),
        ]
        config = ProxyConfig(port=9090, service="Wi-Fi", quiet=True)
        config.enable()
        assert config._original_http == {"Enabled": "No", "Server": "", "Port": "0"}
        assert config._original_https == {"Enabled": "No", "Server": "", "Port": "0"}
        assert ("-setwebproxy", "Wi-Fi", "127.0.0.1", "9090") in [c.args for c in mock_run.call_args_list]

    @patch.object(network, "_run_networksetup")
    def test_disable_restores_original_state(self, mock_run):
        mock_run.return_value = _mock_networksetup()
        config = ProxyConfig(port=9090, service="Wi-Fi", quiet=True)
        config._original_http = {"Enabled": "Yes", "Server": "10.0.0.1", "Port": "8080"}
        config._original_https = {"Enabled": "No", "Server": "", "Port": "0"}
        config.disable()
        calls = [c.args for c in mock_run.call_args_list]
        assert ("-setwebproxy", "Wi-Fi", "10.0.0.1", "8080") in calls
        assert ("-setwebproxystate", "Wi-Fi", "on") in calls
        assert ("-setsecurewebproxy", "Wi-Fi", "", "0") in calls
        assert ("-setsecurewebproxystate", "Wi-Fi", "off") in calls
