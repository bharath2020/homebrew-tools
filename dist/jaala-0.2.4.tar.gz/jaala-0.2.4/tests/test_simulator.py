"""Tests for simulator discovery and management."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from jaala import simulator


SIMCTL_DEVICES_JSON = json.dumps(
    {
        "devices": {
            "com.apple.CoreSimulator.SimRuntime.iOS-18-0": [
                {
                    "udid": "AAA-111",
                    "name": "iPhone 16",
                    "state": "Booted",
                    "isAvailable": True,
                },
                {
                    "udid": "BBB-222",
                    "name": "iPhone 15",
                    "state": "Shutdown",
                    "isAvailable": True,
                },
            ]
        }
    }
)


def _mock_simctl_result(stdout: str = "", stderr: str = "", returncode: int = 0):
    result = MagicMock()
    result.stdout = stdout
    result.stderr = stderr
    result.returncode = returncode
    return result


class TestResolveSimulator:
    @patch.object(simulator, "run_simctl")
    def test_booted(self, mock_run):
        mock_run.return_value = _mock_simctl_result(stdout=SIMCTL_DEVICES_JSON)
        assert simulator.get_booted_simulator()["udid"] == "AAA-111"

    @patch.object(simulator, "run_simctl")
    @patch.object(simulator, "wait_for_simulator_boot", return_value=True)
    def test_resolve_by_udid_boots_shutdown(self, mock_wait, mock_run):
        mock_run.return_value = _mock_simctl_result(stdout=SIMCTL_DEVICES_JSON)
        device = simulator.resolve_simulator("BBB-222")
        assert device["udid"] == "BBB-222"
        mock_wait.assert_called_once_with("BBB-222")


class TestListAndPrint:
    @patch.object(simulator, "run_simctl")
    def test_list_simulators(self, mock_run):
        mock_run.return_value = _mock_simctl_result(stdout=SIMCTL_DEVICES_JSON)
        sims = simulator.list_simulators()
        assert len(sims) == 2
        assert sims[0]["runtime"] == "com.apple.CoreSimulator.SimRuntime.iOS-18-0"

    @patch.object(simulator, "run_simctl")
    def test_print_simulators(self, mock_run, capsys):
        mock_run.return_value = _mock_simctl_result(stdout=SIMCTL_DEVICES_JSON)
        simulator.print_simulators()
        output = capsys.readouterr().out
        assert "iPhone 16" in output
        assert "AAA-111" in output


class TestInstallCertInSimulator:
    @patch.object(simulator, "wait_for_simulator_boot", return_value=True)
    @patch.object(simulator, "run_simctl")
    def test_duplicate_cert_is_ignored(self, mock_run, mock_wait):
        mock_run.return_value = _mock_simctl_result(returncode=1, stderr="Certificate already exists")
        simulator.install_cert_in_simulator("AAA-111", "/path/to/cert.pem")

    @patch.object(simulator, "wait_for_simulator_boot", return_value=True)
    @patch.object(simulator, "run_simctl")
    def test_success(self, mock_run, mock_wait):
        mock_run.return_value = _mock_simctl_result(returncode=0)
        simulator.install_cert_in_simulator("AAA-111", "/path/to/cert.pem")
        mock_run.assert_called_once()

    @patch.object(simulator, "wait_for_simulator_boot", return_value=True)
    @patch.object(simulator, "run_simctl")
    def test_transient_boot_failure_retries(self, mock_run, mock_wait):
        mock_run.side_effect = [
            _mock_simctl_result(returncode=1, stderr="Unable to lookup in current state: Shutdown"),
            _mock_simctl_result(returncode=0),
        ]

        simulator.install_cert_in_simulator("AAA-111", "/path/to/cert.pem")

        assert mock_run.call_count == 2


class TestProbeSimulatorCertStatus:
    @patch.object(simulator, "wait_for_simulator_boot", return_value=True)
    @patch.object(simulator, "run_simctl")
    @patch.object(simulator, "get_simulator_by_udid")
    def test_successful_probe_marks_ready(self, mock_get_device, mock_run, mock_wait, tmp_path):
        cert = tmp_path / "mitmproxy-ca-cert.pem"
        cert.write_text("fake cert")
        mock_get_device.return_value = {
            "udid": "AAA-111",
            "name": "iPhone 16",
            "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
            "state": "Booted",
        }
        mock_run.return_value = _mock_simctl_result(returncode=0)

        status = simulator.probe_simulator_cert_status("AAA-111", str(cert))

        assert status["probe_action"] == "installed"
        assert status["installed"] is True
        assert status["ready"] is True
        mock_run.assert_called_once_with("keychain", "AAA-111", "add-root-cert", str(cert), check=False)

    @patch.object(simulator, "wait_for_simulator_boot", return_value=True)
    @patch.object(simulator, "run_simctl")
    @patch.object(simulator, "get_simulator_by_udid")
    def test_duplicate_probe_is_treated_as_ready(self, mock_get_device, mock_run, mock_wait, tmp_path):
        cert = tmp_path / "mitmproxy-ca-cert.pem"
        cert.write_text("fake cert")
        mock_get_device.return_value = {
            "udid": "AAA-111",
            "name": "iPhone 16",
            "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
            "state": "Booted",
        }
        mock_run.return_value = _mock_simctl_result(returncode=1, stderr="Certificate already exists")

        status = simulator.probe_simulator_cert_status("AAA-111", str(cert))

        assert status["probe_action"] == "already_installed"
        assert status["installed"] is True
        assert status["ready"] is True

    @patch.object(simulator, "run_simctl")
    @patch.object(simulator, "get_simulator_by_udid")
    def test_not_booted_does_not_run_probe(self, mock_get_device, mock_run, tmp_path):
        cert = tmp_path / "mitmproxy-ca-cert.pem"
        cert.write_text("fake cert")
        mock_get_device.return_value = {
            "udid": "BBB-222",
            "name": "iPhone 15",
            "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
            "state": "Shutdown",
        }

        status = simulator.probe_simulator_cert_status("BBB-222", str(cert))

        assert status["probe_action"] == "not_run"
        assert status["installed"] is False
        assert status["ready"] is False
        mock_run.assert_not_called()

    @patch.object(simulator, "run_simctl")
    @patch.object(simulator, "get_simulator_by_udid")
    def test_missing_cert_does_not_run_probe(self, mock_get_device, mock_run, tmp_path):
        cert = tmp_path / "missing.pem"
        mock_get_device.return_value = {
            "udid": "AAA-111",
            "name": "iPhone 16",
            "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
            "state": "Booted",
        }

        status = simulator.probe_simulator_cert_status("AAA-111", str(cert))

        assert status["cert_exists"] is False
        assert status["probe_action"] == "not_run"
        assert status["ready"] is False
        mock_run.assert_not_called()

    @patch.object(simulator, "wait_for_simulator_boot", return_value=True)
    @patch.object(simulator, "run_simctl")
    @patch.object(simulator, "get_simulator_by_udid")
    def test_failed_probe_is_not_ready(self, mock_get_device, mock_run, mock_wait, tmp_path):
        cert = tmp_path / "mitmproxy-ca-cert.pem"
        cert.write_text("fake cert")
        mock_get_device.return_value = {
            "udid": "AAA-111",
            "name": "iPhone 16",
            "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
            "state": "Booted",
        }
        mock_run.return_value = _mock_simctl_result(returncode=1, stderr="permission denied")

        status = simulator.probe_simulator_cert_status("AAA-111", str(cert))

        assert status["probe_action"] == "failed"
        assert status["installed"] is False
        assert status["ready"] is False

    @patch.object(simulator, "wait_for_simulator_boot", return_value=False)
    @patch.object(simulator, "run_simctl")
    @patch.object(simulator, "get_simulator_by_udid")
    def test_failed_boot_wait_marks_probe_failed(self, mock_get_device, mock_run, mock_wait, tmp_path):
        cert = tmp_path / "mitmproxy-ca-cert.pem"
        cert.write_text("fake cert")
        mock_get_device.return_value = {
            "udid": "AAA-111",
            "name": "iPhone 16",
            "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-0",
            "state": "Booted",
        }

        status = simulator.probe_simulator_cert_status("AAA-111", str(cert))

        assert status["probe_action"] == "failed"
        assert status["probe_stderr"] == "Simulator boot did not complete."
        assert status["ready"] is False
        mock_run.assert_not_called()
