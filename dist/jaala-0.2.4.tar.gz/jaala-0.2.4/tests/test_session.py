"""Tests for session lock file management."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from jaala import session


@pytest.fixture
def tmp_lock(tmp_path):
    lock_dir = tmp_path / ".jaala"
    lock_file = lock_dir / "session.lock"
    with patch.object(session, "LOCK_DIR", lock_dir), patch.object(session, "LOCK_FILE", lock_file):
        yield lock_file


class TestWriteAndReadLock:
    def test_write_then_read(self, tmp_lock):
        session.write_lock(
            pid=1234,
            network_service="Wi-Fi",
            port=8080,
            original_http={"Enabled": "No", "Server": "", "Port": "0"},
            original_https={"Enabled": "No", "Server": "", "Port": "0"},
        )
        assert session.read_lock() == {
            "pid": 1234,
            "network_service": "Wi-Fi",
            "port": 8080,
            "original_http": {"Enabled": "No", "Server": "", "Port": "0"},
            "original_https": {"Enabled": "No", "Server": "", "Port": "0"},
            "runtime_config_path": None,
            "runtime_status_path": None,
        }


class TestRemoveLock:
    def test_remove_existing(self, tmp_lock):
        session.write_lock(1, "Wi-Fi", 8080, None, None)
        session.remove_lock()
        assert not tmp_lock.exists()


class TestIsProcessRunning:
    def test_current_process(self):
        assert session.is_process_running(os.getpid()) is True

    def test_nonexistent_pid(self):
        assert session.is_process_running(99999999) is False


class TestCheckStaleSession:
    def test_no_lock_does_nothing(self, tmp_lock):
        session.check_stale_session()

    def test_running_process_exits(self, tmp_lock):
        session.write_lock(1, "Wi-Fi", 8080, None, None)
        with patch.object(session, "is_process_running", return_value=True):
            with pytest.raises(SystemExit):
                session.check_stale_session()


class TestCollectSessionStatus:
    def test_no_lock_reports_clear(self, tmp_lock):
        status = session.collect_session_status()
        assert status == {
            "lock_present": False,
            "pid": None,
            "network_service": None,
            "port": None,
            "process_running": False,
            "stale": False,
            "blocking": False,
        }

    def test_running_lock_reports_blocking(self, tmp_lock):
        session.write_lock(1234, "Wi-Fi", 8080, None, None)
        with patch.object(session, "is_process_running", return_value=True):
            status = session.collect_session_status()

        assert status["lock_present"] is True
        assert status["process_running"] is True
        assert status["stale"] is False
        assert status["blocking"] is True

    def test_stale_lock_reports_blocking(self, tmp_lock):
        session.write_lock(1234, "Wi-Fi", 8080, None, None)
        with patch.object(session, "is_process_running", return_value=False):
            status = session.collect_session_status()

        assert status["lock_present"] is True
        assert status["process_running"] is False
        assert status["stale"] is True
        assert status["blocking"] is True


class TestDoCleanup:
    def test_no_lock_returns_false(self, tmp_lock):
        assert session.do_cleanup() is False

    def test_stale_lock_cleans_up(self, tmp_lock):
        session.write_lock(
            pid=99999999,
            network_service="Wi-Fi",
            port=8080,
            original_http={"Enabled": "No", "Server": "", "Port": "0"},
            original_https={"Enabled": "No", "Server": "", "Port": "0"},
        )
        mock_proxy = MagicMock()
        with patch("jaala.session.is_process_running", return_value=False), \
                patch("jaala.network.ProxyConfig", return_value=mock_proxy):
            assert session.do_cleanup() is True
        mock_proxy.disable.assert_called_once()
        assert not tmp_lock.exists()
