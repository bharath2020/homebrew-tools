"""macOS proxy configuration for Jaala."""

from __future__ import annotations

import subprocess
import sys
from typing import Any


def _run_networksetup(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["networksetup", *args], capture_output=True, text=True, check=False)


def _detect_active_service() -> tuple[str | None, str | None]:
    """Find the active network service without exiting."""
    for service in ["Wi-Fi", "Ethernet", "USB 10/100/1000 LAN"]:
        result = _run_networksetup("-getinfo", service)
        if result.returncode == 0 and "IP address" in result.stdout:
            return service, None

    result = _run_networksetup("-listallnetworkservices")
    if result.returncode != 0:
        return None, "Cannot list network services."

    for line in result.stdout.strip().splitlines()[1:]:
        service = line.strip().lstrip("*").strip()
        info = _run_networksetup("-getinfo", service)
        if info.returncode == 0 and "IP address" in info.stdout:
            return service, None

    return None, "No active network service found."


def _find_active_service() -> str:
    """Find the active network service."""
    service, error = _detect_active_service()
    if service is not None:
        return service

    print(f"Error: {error}", file=sys.stderr)
    sys.exit(1)


def _parse_proxy_state(output: str) -> dict[str, str]:
    state: dict[str, str] = {}
    for line in output.strip().splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        state[key.strip()] = value.strip()
    return state


def _proxy_enabled(state: dict[str, str]) -> bool:
    return state.get("Enabled", "").lower() in {"yes", "on", "true", "1"}


def _normalize_proxy_state(
    state: dict[str, str],
    *,
    expected_port: int | None = None,
) -> dict[str, Any]:
    port_text = state.get("Port", "")
    try:
        port = int(port_text)
    except (TypeError, ValueError):
        port = None

    enabled = _proxy_enabled(state)
    server = state.get("Server", "")
    matches_jaala = enabled and server in {"127.0.0.1", "localhost"} and port is not None and port > 0
    matches_expected = matches_jaala and expected_port is not None and port == expected_port
    return {
        "enabled": enabled,
        "server": server,
        "port": port,
        "raw": state,
        "points_to_jaala": matches_jaala,
        "matches_expected_port": matches_expected,
    }


def collect_proxy_status(
    service: str | None = None,
    *,
    expected_port: int | None = None,
) -> dict[str, Any]:
    """Inspect the current HTTP and HTTPS proxy state for the selected service."""
    if service is None:
        service, error = _detect_active_service()
        if service is None:
            return {
                "service": None,
                "service_source": "auto",
                "error": error,
                "http": None,
                "https": None,
            }
        service_source = "auto"
    else:
        info = _run_networksetup("-getinfo", service)
        if info.returncode != 0:
            message = info.stderr.strip() or info.stdout.strip() or f"Network service '{service}' not found."
            return {
                "service": service,
                "service_source": "explicit",
                "error": message,
                "http": None,
                "https": None,
            }
        service_source = "explicit"

    http_result = _run_networksetup("-getwebproxy", service)
    https_result = _run_networksetup("-getsecurewebproxy", service)
    if http_result.returncode != 0 or https_result.returncode != 0:
        message = http_result.stderr.strip() or https_result.stderr.strip() or "Failed to inspect proxy state."
        return {
            "service": service,
            "service_source": service_source,
            "error": message,
            "http": None,
            "https": None,
        }

    return {
        "service": service,
        "service_source": service_source,
        "error": None,
        "http": _normalize_proxy_state(_parse_proxy_state(http_result.stdout), expected_port=expected_port),
        "https": _normalize_proxy_state(_parse_proxy_state(https_result.stdout), expected_port=expected_port),
    }


class ProxyConfig:
    """Manage macOS HTTP and HTTPS proxy settings."""

    def __init__(self, port: int, service: str | None = None, quiet: bool = False):
        self.port = port
        self.service = service or _find_active_service()
        self.quiet = quiet
        self._original_http: dict[str, str] | None = None
        self._original_https: dict[str, str] | None = None

    def _parse_proxy_state(self, output: str) -> dict[str, str]:
        return _parse_proxy_state(output)

    def _get_current_proxy(self, proto: str) -> dict[str, str]:
        flag = "-getwebproxy" if proto == "http" else "-getsecurewebproxy"
        result = _run_networksetup(flag, self.service)
        return self._parse_proxy_state(result.stdout)

    def _set_proxy(self, proto: str, state: dict[str, str]) -> None:
        set_flag = "-setwebproxy" if proto == "http" else "-setsecurewebproxy"
        state_flag = "-setwebproxystate" if proto == "http" else "-setsecurewebproxystate"
        enabled = _proxy_enabled(state)
        server = state.get("Server", "127.0.0.1")
        port = state.get("Port", "0")
        _run_networksetup(set_flag, self.service, server, port)
        _run_networksetup(state_flag, self.service, "on" if enabled else "off")

    def enable(self) -> None:
        """Point host HTTP and HTTPS traffic at the Jaala proxy."""
        self._original_http = self._get_current_proxy("http")
        self._original_https = self._get_current_proxy("https")

        if not self.quiet:
            print(f"Setting system proxy on '{self.service}' -> 127.0.0.1:{self.port}")

        _run_networksetup("-setwebproxy", self.service, "127.0.0.1", str(self.port))
        _run_networksetup("-setsecurewebproxy", self.service, "127.0.0.1", str(self.port))
        _run_networksetup("-setwebproxystate", self.service, "on")
        _run_networksetup("-setsecurewebproxystate", self.service, "on")

    def disable(self) -> None:
        """Restore the saved proxy settings."""
        if not self.quiet:
            print(f"Restoring proxy settings on '{self.service}'...")

        if self._original_http is not None:
            self._set_proxy("http", self._original_http)
        else:
            _run_networksetup("-setwebproxystate", self.service, "off")

        if self._original_https is not None:
            self._set_proxy("https", self._original_https)
        else:
            _run_networksetup("-setsecurewebproxystate", self.service, "off")
