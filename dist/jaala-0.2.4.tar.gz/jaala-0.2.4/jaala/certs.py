"""mitmproxy certificate generation and macOS trust helpers."""

from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path
from typing import Any


MITMPROXY_DIR = Path.home() / ".mitmproxy"
CA_CERT_PEM = MITMPROXY_DIR / "mitmproxy-ca-cert.pem"


def _normalize_cert_path(cert_path: str | Path | None) -> Path:
    if cert_path is None:
        return CA_CERT_PEM
    return Path(cert_path).expanduser()


def ensure_ca_cert() -> Path:
    """Ensure the mitmproxy CA certificate exists."""
    if CA_CERT_PEM.exists():
        return CA_CERT_PEM

    print("Generating mitmproxy CA certificate...")
    proc = subprocess.Popen(
        ["mitmdump", "--listen-port", "0"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    for _ in range(100):
        if CA_CERT_PEM.exists():
            break
        time.sleep(0.1)

    proc.terminate()
    proc.wait(timeout=5)

    if not CA_CERT_PEM.exists():
        print("Error: Failed to generate mitmproxy CA certificate.", file=sys.stderr)
        sys.exit(1)

    print(f"CA certificate generated at {CA_CERT_PEM}")
    return CA_CERT_PEM


def is_ca_cert_trusted_in_macos(cert_path: str) -> bool:
    """Return True if the CA appears trusted in the macOS System keychain."""
    result = subprocess.run(
        [
            "security",
            "verify-cert",
            "-c",
            cert_path,
            "-k",
            "/Library/Keychains/System.keychain",
        ],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def get_ca_cert_status(cert_path: str | Path | None = None) -> dict[str, Any]:
    """Return whether the mitmproxy CA exists and is trusted on macOS."""
    path = _normalize_cert_path(cert_path)
    exists = path.exists()
    trusted_in_macos = is_ca_cert_trusted_in_macos(str(path)) if exists else False
    return {
        "path": str(path),
        "exists": exists,
        "trusted_in_macos": trusted_in_macos,
        "ready": exists and trusted_in_macos,
    }


def trust_ca_cert_in_macos(cert_path: str, quiet: bool = False) -> None:
    """Install the mitmproxy CA into the macOS System keychain."""
    if is_ca_cert_trusted_in_macos(cert_path):
        if not quiet:
            print("macOS System trust already present for mitmproxy CA.")
        return

    if not quiet:
        print("Installing mitmproxy CA into macOS System keychain (sudo may prompt)...")

    try:
        subprocess.run(
            [
                "sudo",
                "security",
                "add-trusted-cert",
                "-d",
                "-r",
                "trustRoot",
                "-k",
                "/Library/Keychains/System.keychain",
                cert_path,
            ],
            check=True,
        )
    except subprocess.CalledProcessError:
        print(
            "Error: Failed to trust the mitmproxy CA in macOS System keychain.",
            file=sys.stderr,
        )
        sys.exit(1)

    if not quiet:
        print("macOS System trust installed for mitmproxy CA.")
