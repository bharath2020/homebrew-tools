"""Filter parsing and config loading for Jaala."""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from collections.abc import Callable, Mapping

ENV_CONFIG = "JAALA_CONFIG"
PROFILE_KEY = "profiles"

FILTER_KEYS = ("filter", "filter_user_agent")


def _normalize(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def build_matcher(pattern: str | None) -> Callable[[str], bool] | None:
    normalized = _normalize(pattern)
    if normalized is None:
        return None

    if normalized.startswith("re:"):
        expression = normalized[3:]
        if not expression:
            raise ValueError("Invalid regex pattern: empty expression")
        try:
            regex = re.compile(expression, re.IGNORECASE)
        except re.error as exc:
            raise ValueError(f"Invalid regex pattern {pattern!r}: {exc}") from exc
        return lambda value: bool(regex.search(value))

    needle = normalized.casefold()
    return lambda value: needle in value.casefold()


def _load_config_payload(path: str | None) -> dict[str, object]:
    if not path:
        return {}

    config_path = Path(path)
    if not config_path.is_file():
        return {}

    with config_path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)

    if not isinstance(data, dict):
        raise ValueError(f"Jaala config {path!r} must contain a JSON object")
    return data


def load_merged_config(path: str | None, profile: str | None = None) -> dict[str, object]:
    data = _load_config_payload(path)
    if not data:
        return {}

    normalized_profile = _normalize(profile)
    if normalized_profile is None:
        return data

    profiles = data.get(PROFILE_KEY)
    if not isinstance(profiles, dict):
        raise ValueError(f"Jaala config {path!r} does not define any named profiles")

    profile_settings = profiles.get(normalized_profile)
    if profile_settings is None:
        raise ValueError(f"Jaala config {path!r} does not define profile {normalized_profile!r}")
    if not isinstance(profile_settings, dict):
        raise ValueError(f"Jaala config {path!r} profile {normalized_profile!r} must be a JSON object")

    merged = {key: value for key, value in data.items() if key != PROFILE_KEY}
    merged.update(profile_settings)
    return merged


def load_filter_config(path: str | None, profile: str | None = None) -> dict[str, str]:
    data = load_merged_config(path, profile=profile)

    result: dict[str, str] = {}
    for key in FILTER_KEYS:
        value = data.get(key)
        if value is None:
            continue
        if not isinstance(value, str):
            raise ValueError(f"Filter config {path!r} field {key!r} must be a string")
        normalized = _normalize(value)
        if normalized is not None:
            result[key] = normalized
    return result


def resolve_filter_settings(
    *,
    config_path: str | None = None,
    config_profile: str | None = None,
    env: Mapping[str, str] | None = None,
    filter_pattern: str | None = None,
    filter_user_agent: str | None = None,
) -> dict[str, str]:
    env = env or os.environ
    resolved = load_filter_config(config_path or env.get(ENV_CONFIG), profile=config_profile)

    cli_filter = _normalize(filter_pattern)
    if cli_filter is not None:
        resolved["filter"] = cli_filter

    cli_filter_user_agent = _normalize(filter_user_agent)
    if cli_filter_user_agent is not None:
        resolved["filter_user_agent"] = cli_filter_user_agent

    return resolved
