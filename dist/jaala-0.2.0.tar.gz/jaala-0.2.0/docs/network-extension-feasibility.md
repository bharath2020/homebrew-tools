# Network Extension Feasibility: Capture and Replay Without mitmproxy

This note evaluates whether Jaala can replace `mitmproxy` with an Apple Network
Extension for capture, replay, and event injection.

## Short Answer

Network Extension can replace the way Jaala routes traffic through a local
proxy, especially on macOS, but it does not remove the core TLS problem. For
HTTPS, WSS, HTTP/2, HTTP/3, SSE over HTTPS, and most production app traffic, a
Network Extension sees transport bytes unless it also implements TLS
interception or the app cooperates.

So the realistic answer is:

- Yes, we can build a Network Extension transport layer that captures TCP flows
  and can replay raw or synthetic data.
- No, Network Extension alone does not give us decoded HTTP responses,
  WebSocket messages, or SSE events for TLS traffic.
- To preserve Jaala's current JSONL/HAR-level semantics, we still need either a
  MITM-style HTTP/TLS proxy engine, app-level instrumentation, or a custom
  trusted test transport.

## Relevant Apple Extension Types

Apple's Network Extension framework is a family of app extensions and system
extensions, not one generic packet-capture API. The framework covers VPN
tunnels, app/transparent proxying, content filters, DNS settings/proxies,
relays, URL filters, Wi-Fi configuration, and local push connectivity. The
provider type matters because each one sits at a different layer of the network
stack and has different deployment restrictions.

### NETransparentProxyProvider

Best fit for a macOS Jaala replacement. A transparent proxy provider receives
flows selected by `NETransparentProxyNetworkSettings`; it can choose to handle a
flow or let the OS connect directly. This lets Jaala avoid changing system HTTP
proxy settings and avoid launching `mitmdump`.

Transparent proxy settings are rule-based. `includedNetworkRules` selects
traffic to route through the provider, while `excludedNetworkRules` takes
priority for traffic that must bypass it. Apple's documented restrictions mean
Jaala should model rules as outbound TCP/UDP destination matches, not as an
arbitrary packet filter. DNS on port 53 is also special-cased and should be
handled with domain-based rules or a separate DNS strategy.

Practical use:

- Capture socket-level flows.
- Selectively proxy only simulator or app traffic.
- Connect to the real destination with `NWConnection`.
- Copy bytes between app flow and upstream connection.
- Inject or replay raw bytes on an open TCP flow.

Limits:

- macOS only.
- Deployment is either a macOS App Store app extension or a macOS system
  extension; Developer ID distribution requires the system extension entitlement
  variant.
- Still receives encrypted TLS bytes for HTTPS/WSS.
- Reconstructing HTTP/2, HTTP/3, WebSocket, and SSE requires protocol parsing.
- Decrypting TLS requires becoming a MITM proxy with a trusted root certificate.

### NEAppProxyProvider

Can proxy app-selected traffic, but iOS deployment is managed-device oriented.
It is useful for per-app enterprise-style routing. For Jaala's general simulator
developer workflow, it is less attractive than transparent proxy on macOS.

Practical use:

- Similar flow-copying model to transparent proxy.
- Can proxy TCP/UDP flows for matching app rules.

Limits:

- iOS app proxy deployment is for managed devices.
- Returning `false` from `handleNewFlow` discards the flow for app proxy
  providers, so it is less ergonomic for selective pass-through than transparent
  proxy.
- This is a VPN-style feature. A production design needs tunnel lifecycle,
  provider sessions, app rules, and MDM/per-app VPN configuration where
  applicable.

### NEFilterDataProvider

Useful for allow/block and classification, not for Jaala-style capture/replay.
Apple documents a restrictive sandbox for the data provider: no network access,
IPC, or disk writes from the data provider. It can inspect data enough to return
filter verdicts, but it is not a good place to implement HAR capture, replay,
or agent-driven event injection.

Practical use:

- Policy and filtering.
- Some inspection for pass/block decisions.

Limits:

- Not designed to mutate and replay application responses.
- Restrictive sandbox prevents normal logging/control-plane architecture.
- TLS payload is still encrypted.

### NEPacketTunnelProvider

Not the right abstraction for Jaala. Apple describes packet tunnel providers as
VPN-style tunnel clients. A packet tunnel can see IP packets, but Jaala needs
application-layer HTTP/WebSocket/SSE records and mutations. Building this from
packets means reimplementing routing, TCP stream reconstruction, TLS
interception, and HTTP parsing.

### NEDNSProxyProvider

Not sufficient. It can intercept DNS, which helps map hostnames, but it cannot
capture or replay HTTP responses.

### Relays and DNS Settings

Apple also exposes relay and DNS-settings APIs. They are useful for system-level
routing or encrypted DNS configuration, but they do not give Jaala decoded
application payloads or an agent-controlled replay path. They may be useful as
supporting pieces later, but they are not a replacement for the capture/replay
engine.

## Deployment and Entitlement Notes

Network Extension development is gated by entitlements. The entitlement value is
specific to the provider family, for example `app-proxy-provider`,
`packet-tunnel-provider`, `content-filter-provider`, `dns-proxy`, or the
corresponding `*-systemextension` values for Developer ID-signed macOS system
extensions.

For Jaala, the practical deployment shape is:

- Prototype as a macOS system extension using transparent proxy APIs.
- Sign the host app and system extension with the same Team ID.
- Expect installation/activation through the SystemExtensions framework.
- Keep the provider small: classify and copy flows, then hand control-plane
  state to the Jaala engine outside the provider where the architecture allows.
- Treat iOS device-wide interception as out of scope for unmanaged devices.

TN3134 is important because it makes the platform constraints explicit:
transparent proxy providers are macOS-only, DNS proxy on iOS is supervised or
managed-device scoped, and many provider families have different app-extension
versus system-extension packaging rules.

## Feasible Architecture

The most realistic mitmproxy-free architecture is:

1. A macOS `NETransparentProxyProvider` system extension captures selected flows.
2. The provider passes flow metadata and byte streams to a local Jaala engine.
3. The Jaala engine maintains flow state and performs raw TCP flow copying.
4. For plaintext HTTP and WS, Jaala parses requests, responses, WebSocket
   frames, and stream chunks directly.
5. For TLS, Jaala either:
   - does not decode payloads, capturing metadata only;
   - terminates TLS using a Jaala root CA and a custom TLS proxy engine;
   - relies on app-side instrumentation for decoded request/response events;
   - or uses a test-only URLProtocol/custom transport inside the app.

The provider should not become the whole product. The cleaner split is:

- Network Extension provider: traffic selection, flow lifecycle, byte copying,
  and minimal health/status reporting.
- Jaala engine: recording format, replay policy, scenario state, WebSocket/SSE
  message modeling, CLI/runtime commands, and test fixture storage.
- Optional TLS layer: certificate installation, CONNECT/TLS termination,
  ALPN/protocol handling, and decoded HTTP event emission.

This removes the `mitmdump` dependency, but it does not remove proxy-like
behavior. If decoded HTTPS capture/replay is required, the replacement still
needs to be a local TLS-intercepting proxy, just implemented by Jaala instead of
mitmproxy.

## What This Would Unlock

- No Python `mitmdump` process.
- No macOS HTTP proxy setting changes for the main flow path.
- More direct flow lifecycle tracking for open sockets and streams.
- A native control plane for `sockets send`, `streams send`, stream close, and
  flow status.
- Better scoping to Simulator traffic on macOS.

## What It Would Not Unlock By Itself

- Decoded HTTPS response bodies without TLS interception.
- Decoded WSS WebSocket frames without TLS interception.
- HTTP/2 and HTTP/3 replay without implementing protocol handling.
- App Store-friendly iOS-wide interception for unmanaged devices.
- Fully backend-free behavior unless Jaala can synthesize entire connections or
  the app is configured to connect to a Jaala test endpoint.

## Recommendation

Do not replace mitmproxy with Network Extension as a first step. Build a small
prototype first:

1. macOS-only `NETransparentProxyProvider`.
2. Scope to the iOS Simulator sample app traffic.
3. Capture plaintext HTTP and `ws://` traffic only.
4. Prove JSONL parity for:
   - HTTP request/response records,
   - WebSocket messages,
   - SSE chunks,
   - stream end lifecycle.
5. Add raw `sockets send` and `streams send` controls through the native flow
   state.
6. Decide whether to implement a Jaala-owned TLS MITM engine only after the
   plaintext prototype is stable.

For Jaala's current goal, Network Extension is best viewed as a future native
transport backend, not a way to avoid TLS interception entirely.

## Sources

- Apple Network Extension framework:
  https://developer.apple.com/documentation/networkextension
- Apple `NETransparentProxyProvider`:
  https://developer.apple.com/documentation/networkextension/netransparentproxyprovider
- Apple `NETransparentProxyNetworkSettings`:
  https://developer.apple.com/documentation/networkextension/netransparentproxynetworksettings
- Apple `NENetworkRule`:
  https://developer.apple.com/documentation/networkextension/nenetworkrule
- Apple flow copying guide:
  https://developer.apple.com/documentation/networkextension/handling-flow-copying
- Apple `NEAppProxyProvider`:
  https://developer.apple.com/documentation/networkextension/neappproxyprovider
- Apple `NEFilterDataProvider`:
  https://developer.apple.com/documentation/networkextension/nefilterdataprovider
- Apple content filter providers:
  https://developer.apple.com/documentation/networkextension/content-filter-providers
- Apple `NEPacketTunnelProvider`:
  https://developer.apple.com/documentation/networkextension/nepackettunnelprovider
- Apple `NEDNSProxyProvider`:
  https://developer.apple.com/documentation/networkextension/nednsproxyprovider
- Apple Network Extensions entitlement:
  https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.networking.networkextension
- Apple TN3134 Network Extension provider deployment:
  https://developer.apple.com/documentation/technotes/tn3134-network-extension-provider-deployment
- Apple System Extensions:
  https://developer.apple.com/documentation/systemextensions
