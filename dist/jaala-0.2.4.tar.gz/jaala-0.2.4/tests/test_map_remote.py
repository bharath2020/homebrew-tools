from __future__ import annotations

import json
import os
from unittest.mock import patch

from jaala.addon import JaalaAddon

from .test_addon import make_flow


class FakeRemoteResponse:
    def __init__(self) -> None:
        self.status = 201
        self.headers = {
            "Content-Type": "application/json",
            "X-Upstream": "remote",
        }

    def read(self) -> bytes:
        return b'{"source":"remote"}'

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):  # noqa: ANN001, D401
        return False


def test_map_remote_replaces_response_with_upstream_fixture(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"map_remote": "api.example.com=https://example.com/fixture.json"}),
        encoding="utf-8",
    )

    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow()

    with patch("jaala.response_rules.urlopen", return_value=FakeRemoteResponse()):
        addon.response(flow)

    assert flow.response.status_code == 201
    assert flow.response.content == b'{"source":"remote"}'
    assert flow.response.headers.get("Content-Type") == "application/json"
    assert flow.response.headers.get("X-Upstream") == "remote"
