# Changelog

## Unreleased

## 0.2.0 - 2026-05-11

- Add streamed HTTP response capture and replay validation.
- Add runtime commands for sending and closing HTTP stream chunks.
- Add WebSocket replay support and runtime socket message injection.
- Add an agent-oriented CLI API assessment for record, replay, stream, and socket workflows.
- Expand the sample app and AXe demos to validate continuous HTTP and WebSocket streams.
- Document Network Extension feasibility for replacing the mitmproxy transport layer.

## 0.1.0 - 2026-05-11

- Initialize Jaala with an AXe-driven iOS Simulator sample-app validation path.
- Add the `jaala` CLI package and Simulator listing.
- Add the supported host-proxy capture path with CA install, session lock, and cleanup.
- Add JSON Lines and HAR capture artifacts.
- Add URL and User-Agent filtering with substring and `re:` regex patterns.
- Add response simulation rules for local/remote mapping, status overrides, headers, and body replacement.
- Add request simulation rules for headers and body replacement.
- Add network-condition simulation for delay, throttling, dropped connections, and fail rate.
- Add end-to-end AXe validation that verifies captured sample-app traffic and cleanup behavior.
- Document why Simulator-local proxy routing is not exposed as a supported mode.
