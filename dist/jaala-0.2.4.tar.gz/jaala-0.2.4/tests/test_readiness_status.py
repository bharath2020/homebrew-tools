from __future__ import annotations

import json
from unittest.mock import patch


@patch("jaala.readiness.get_ca_cert_status")
@patch("jaala.readiness.collect_proxy_status")
@patch("jaala.readiness.collect_session_status")
def test_collect_readiness_status_reports_running_session_and_proxy_error(
    mock_collect_session_status,
    mock_collect_proxy_status,
    mock_get_ca_cert_status,
):
    mock_collect_session_status.return_value = {
        "lock_present": True,
        "pid": 4321,
        "network_service": "Wi-Fi",
        "port": 8899,
        "process_running": True,
        "stale": False,
        "blocking": True,
    }
    mock_collect_proxy_status.return_value = {
        "service": "Wi-Fi",
        "service_source": "explicit",
        "error": "networksetup failed",
        "http": None,
        "https": None,
    }
    mock_get_ca_cert_status.return_value = {
        "path": "/tmp/mitmproxy-ca-cert.pem",
        "exists": True,
        "trusted_in_macos": True,
        "ready": True,
    }

    from jaala.readiness import collect_readiness_status

    status = collect_readiness_status(network_service="Wi-Fi")

    assert status["ready"] is False
    assert "networksetup failed" in status["blockers"]
    assert "Jaala session PID 4321 is still running." in status["blockers"]
    assert status["cert"]["macos_system_trusted"] is True
    mock_collect_proxy_status.assert_called_once_with(service="Wi-Fi", expected_port=8899)


@patch("jaala.readiness.get_ca_cert_status")
@patch("jaala.readiness.collect_proxy_status")
@patch("jaala.readiness.collect_session_status")
def test_collect_readiness_status_does_not_forward_non_integer_expected_port(
    mock_collect_session_status,
    mock_collect_proxy_status,
    mock_get_ca_cert_status,
):
    mock_collect_session_status.return_value = {
        "lock_present": True,
        "pid": 4321,
        "network_service": "Wi-Fi",
        "port": "8899",
        "process_running": False,
        "stale": True,
        "blocking": True,
    }
    mock_collect_proxy_status.return_value = {
        "service": "Wi-Fi",
        "service_source": "explicit",
        "error": None,
        "http": {"enabled": False, "server": "", "port": 0, "points_to_jaala": False, "matches_expected_port": False},
        "https": {"enabled": False, "server": "", "port": 0, "points_to_jaala": False, "matches_expected_port": False},
    }
    mock_get_ca_cert_status.return_value = {
        "path": "/tmp/mitmproxy-ca-cert.pem",
        "exists": True,
        "trusted_in_macos": True,
        "ready": True,
    }

    from jaala.readiness import collect_readiness_status

    status = collect_readiness_status(network_service="Wi-Fi")

    assert status["ready"] is False
    assert "Stale Jaala session lock exists. Run jaala --cleanup." in status["blockers"]
    mock_collect_proxy_status.assert_called_once_with(service="Wi-Fi", expected_port=None)


def test_print_readiness_status_text_output_reports_blockers_and_unknown_simulator_probe(capsys):
    from jaala.readiness import print_readiness_status

    status = {
        "ready": False,
        "blockers": ["proxy mismatch", "missing trust"],
        "proxy": {
            "service": "Wi-Fi",
            "error": None,
            "http": {
                "enabled": True,
                "server": "127.0.0.1",
                "port": 8899,
                "points_to_jaala": True,
            },
            "https": {
                "enabled": False,
                "server": "",
                "port": 0,
                "points_to_jaala": False,
            },
        },
        "session": {
            "lock_present": True,
            "process_running": False,
            "pid": 4321,
            "network_service": "Wi-Fi",
            "port": 8899,
        },
        "cert": {
            "path": "/tmp/mitmproxy-ca-cert.pem",
            "exists": True,
            "macos_system_trusted": False,
        },
    }

    print_readiness_status(status, as_json=False)

    output = capsys.readouterr().out
    assert "Ready to proxy: not ready" in output
    assert "HTTP proxy: enabled 127.0.0.1:8899 (Jaala)" in output
    assert "HTTPS proxy: disabled -:0" in output
    assert "Session lock: stale (pid=4321, service=Wi-Fi, port=8899)" in output
    assert "Simulator cert status: unknown (no simctl query API)" in output
    assert "Blocker: proxy mismatch" in output
    assert "Blocker: missing trust" in output


def test_print_readiness_status_json_output_round_trips(capsys):
    from jaala.readiness import print_readiness_status

    status = {
        "ready": True,
        "blockers": [],
        "proxy": {"service": "Wi-Fi"},
        "session": {"lock_present": False},
        "cert": {"exists": True},
    }

    print_readiness_status(status, as_json=True)

    assert json.loads(capsys.readouterr().out) == status


@patch("jaala.readiness.probe_simulator_cert_status")
@patch("jaala.readiness.resolve_simulator")
@patch("jaala.readiness.get_ca_cert_status")
def test_collect_cert_probe_status_reports_simulator_probe_failure(
    mock_get_ca_cert_status,
    mock_resolve_simulator,
    mock_probe_simulator_cert_status,
):
    mock_get_ca_cert_status.return_value = {
        "path": "/tmp/mitmproxy-ca-cert.pem",
        "exists": True,
        "trusted_in_macos": True,
        "ready": True,
    }
    mock_resolve_simulator.return_value = {"udid": "ABC-123", "name": "iPhone 16e"}
    mock_probe_simulator_cert_status.return_value = {
        "device_name": "iPhone 16e",
        "udid": "ABC-123",
        "booted": True,
        "cert_path": "/tmp/mitmproxy-ca-cert.pem",
        "cert_exists": True,
        "trust_store_path": "/tmp/truststore.sqlite3",
        "trust_store_exists": True,
        "probe_action": "failed",
        "probe_returncode": 1,
        "probe_stderr": "duplicate keychain failure",
        "installed": False,
        "ready": False,
    }

    from jaala.readiness import collect_cert_probe_status

    status = collect_cert_probe_status("ABC-123")

    assert status["ready"] is False
    assert status["blockers"] == ["Simulator certificate probe failed: duplicate keychain failure"]
    mock_resolve_simulator.assert_called_once_with("ABC-123")
    assert mock_probe_simulator_cert_status.call_args.args[0] == "ABC-123"
    assert mock_probe_simulator_cert_status.call_args.args[1].endswith("/.mitmproxy/mitmproxy-ca-cert.pem")


def test_print_cert_probe_status_text_output_includes_probe_stderr(capsys):
    from jaala.readiness import print_cert_probe_status

    status = {
        "ready": False,
        "blockers": ["Simulator certificate probe failed: duplicate keychain failure"],
        "cert": {
            "path": "/tmp/mitmproxy-ca-cert.pem",
            "exists": True,
            "macos_system_trusted": True,
        },
        "simulator": {
            "device_name": "iPhone 16e",
            "udid": "ABC-123",
            "booted": True,
            "trust_store_path": "/tmp/truststore.sqlite3",
            "probe_action": "failed",
            "probe_stderr": "duplicate keychain failure",
        },
    }

    print_cert_probe_status(status, as_json=False)

    output = capsys.readouterr().out
    assert "Simulator certificate readiness: not ready" in output
    assert "Simulator: iPhone 16e (ABC-123) [booted=yes]" in output
    assert "Simulator probe: failed" in output
    assert "Simulator probe stderr: duplicate keychain failure" in output
    assert "Blocker: Simulator certificate probe failed: duplicate keychain failure" in output
