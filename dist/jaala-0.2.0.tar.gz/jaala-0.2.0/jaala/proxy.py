"""Proxy orchestration for Jaala."""

from __future__ import annotations

import json
import os
import signal
import socket
import ssl
import subprocess
import sys
import time
from pathlib import Path


ADDON_PATH = Path(__file__).parent / "addon.py"


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def _wait_for_port(port: int, timeout: float = 5.0, interval: float = 0.1) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(interval)
                sock.connect(("127.0.0.1", port))
                return True
        except (ConnectionRefusedError, OSError):
            time.sleep(interval)
    return False


def _find_upstream_trusted_ca() -> str | None:
    try:
        import certifi

        certifi_path = certifi.where()
    except ImportError:
        certifi_path = None

    if certifi_path and Path(certifi_path).is_file():
        return certifi_path

    default_paths = ssl.get_default_verify_paths()
    if default_paths.cafile and Path(default_paths.cafile).is_file():
        return default_paths.cafile

    return None


def start_mitmdump(
    port: int,
    *,
    config_path: str | None = None,
    runtime_status_file: str | None = None,
    json_mode: bool = False,
    json_file: str | None = None,
    save_har: str | None = None,
    no_headers: bool = False,
    no_body: bool = False,
    no_websockets: bool = False,
    output_file: str | None = None,
    filter_pattern: str | None = None,
    filter_user_agent: str | None = None,
    map_local: str | None = None,
    map_remote: str | None = None,
    status_code: str | None = None,
    add_header: str | None = None,
    body_replace: str | None = None,
    request_header: str | None = None,
    request_body_replace: str | None = None,
    websocket_message_replace: str | None = None,
    websocket_drop_message: list[str] | None = None,
    websocket_fail_rate: list[str] | None = None,
    websocket_delay: list[str] | None = None,
    websocket_throttle: list[str] | None = None,
    websocket_replay_file: str | None = None,
    websocket_replay_pattern: str | None = None,
    delay: list[str] | None = None,
    throttle: list[str] | None = None,
    drop_connection: list[str] | None = None,
    fail_rate: list[str] | None = None,
    quiet: bool = False,
    verbose: bool = False,
) -> subprocess.Popen:
    env = os.environ.copy()
    env["JAALA_JSON"] = "1" if json_mode else "0"
    env["JAALA_NO_HEADERS"] = "1" if no_headers else "0"
    env["JAALA_NO_BODY"] = "1" if no_body else "0"
    env["JAALA_WEBSOCKETS"] = "0" if no_websockets else "1"
    env["JAALA_NO_WEBSOCKETS"] = "1" if no_websockets else "0"
    if config_path:
        env["JAALA_CONFIG"] = config_path
    if runtime_status_file:
        env["JAALA_RUNTIME_STATUS_FILE"] = runtime_status_file
    if websocket_message_replace:
        env["JAALA_WEBSOCKET_MESSAGE_REPLACE"] = websocket_message_replace
    if websocket_drop_message:
        env["JAALA_WEBSOCKET_DROP_MESSAGE"] = json.dumps(websocket_drop_message)
    if websocket_fail_rate:
        env["JAALA_WEBSOCKET_FAIL_RATE"] = json.dumps(websocket_fail_rate)
    if websocket_delay:
        env["JAALA_WEBSOCKET_DELAY"] = json.dumps(websocket_delay)
    if websocket_throttle:
        env["JAALA_WEBSOCKET_THROTTLE"] = json.dumps(websocket_throttle)
    if websocket_replay_file:
        env["JAALA_WEBSOCKET_REPLAY_FILE"] = websocket_replay_file
    if websocket_replay_pattern:
        env["JAALA_WEBSOCKET_REPLAY_PATTERN"] = websocket_replay_pattern
    if delay:
        env["JAALA_DELAY"] = json.dumps(delay)
    if throttle:
        env["JAALA_THROTTLE"] = json.dumps(throttle)
    if drop_connection:
        env["JAALA_DROP_CONNECTION"] = json.dumps(drop_connection)
    if fail_rate:
        env["JAALA_FAIL_RATE"] = json.dumps(fail_rate)
    if json_file:
        env["JAALA_JSON_FILE"] = json_file
    if save_har:
        env["JAALA_HAR_FILE"] = save_har
    if quiet:
        env["JAALA_QUIET"] = "1"
    if verbose:
        env["JAALA_VERBOSE"] = "1"

    cmd = [
        "mitmdump",
        "--listen-port",
        str(port),
        "--set",
        "flow_detail=0",
        "--set",
        f"console_eventlog_verbosity={'info' if verbose else 'error'}",
        "-s",
        str(ADDON_PATH),
    ]

    trusted_ca = _find_upstream_trusted_ca()
    if trusted_ca:
        cmd.extend(["--set", f"ssl_verify_upstream_trusted_ca={trusted_ca}"])

    if output_file:
        cmd.extend(["-w", output_file])

    proc = subprocess.Popen(cmd, env=env, stdout=sys.stdout, stderr=sys.stderr)

    if not _wait_for_port(port, timeout=5.0, interval=0.1):
        if proc.poll() is not None:
            print("Error: mitmdump failed to start.", file=sys.stderr)
        else:
            print("Error: mitmdump started but is not accepting connections.", file=sys.stderr)
            proc.send_signal(signal.SIGTERM)
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        sys.exit(1)

    return proc
