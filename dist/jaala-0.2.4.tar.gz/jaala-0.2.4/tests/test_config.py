from __future__ import annotations

import json
import os
from unittest.mock import patch

from jaala.filtering import load_filter_config, resolve_filter_settings
from jaala.network_conditions import load_network_conditions_config, resolve_network_condition_settings
from jaala.request_rules import load_request_config, resolve_request_settings
from jaala.response_rules import load_response_config, resolve_response_settings
from jaala.websocket_message_rules import (
    load_websocket_message_config,
    resolve_websocket_message_settings,
)
from jaala.websocket_replay import resolve_websocket_replay_settings


def test_load_filter_config_reads_filter_settings(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "filter": "api.example.com",
                "filter_user_agent": "re:JaalaSample/\\d+",
            }
        ),
        encoding="utf-8",
    )

    config = load_filter_config(str(config_path))

    assert config == {
        "filter": "api.example.com",
        "filter_user_agent": "re:JaalaSample/\\d+",
    }


def test_load_filter_config_ignores_missing_file():
    assert load_filter_config("/tmp/does-not-exist.json") == {}


def test_load_config_profile_overrides_base_settings_across_families(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "filter": "base.example.com",
                "filter_user_agent": "BaseUA",
                "map_local": "base.example.com=/tmp/base.json",
                "map_remote": "base.example.com=https://example.com/base.json",
                "status_code": "base.example.com=418",
                "add_header": "base.example.com=X-Base:yes",
                "response_text_replace": "base.example.com=hello>>>base",
                "request_header": "base.example.com=X-Base-Request:yes",
                "request_body_replace": "base.example.com=request>>>base",
                "websocket_message_replace": "base.example.com=hello>>>base",
                "websocket_drop_message": ["base.example.com/drop"],
                "websocket_fail_rate": ["base.example.com/flaky=25"],
                "websocket_delay": ["base.example.com/slow=250"],
                "websocket_throttle": ["base.example.com/large=1"],
                "delay": ["base.example.com=100"],
                "throttle": ["base.example.com=10"],
                "drop_connection": ["base.example.com/offline"],
                "fail_rate": ["base.example.com=5"],
                "profiles": {
                    "slow-api": {
                        "filter": "profile.example.com",
                        "map_local": "profile.example.com=/tmp/profile.json",
                        "request_header": "profile.example.com=X-Profile:yes",
                        "websocket_drop_message": ["profile.example.com/drop"],
                        "delay": ["profile.example.com=900"],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    assert load_filter_config(str(config_path), profile="slow-api") == {
        "filter": "profile.example.com",
        "filter_user_agent": "BaseUA",
    }
    assert load_response_config(str(config_path), profile="slow-api") == {
        "map_local": "profile.example.com=/tmp/profile.json",
        "map_remote": "base.example.com=https://example.com/base.json",
        "status_code": "base.example.com=418",
        "add_header": "base.example.com=X-Base:yes",
        "response_text_replace": "base.example.com=hello>>>base",
    }
    assert load_request_config(str(config_path), profile="slow-api") == {
        "request_header": "profile.example.com=X-Profile:yes",
        "request_body_replace": "base.example.com=request>>>base",
    }
    assert load_websocket_message_config(str(config_path), profile="slow-api") == {
        "websocket_message_replace": "base.example.com=hello>>>base",
        "websocket_drop_message": ["profile.example.com/drop"],
        "websocket_fail_rate": ["base.example.com/flaky=25"],
        "websocket_delay": ["base.example.com/slow=250"],
        "websocket_throttle": ["base.example.com/large=1"],
    }
    assert load_network_conditions_config(str(config_path), profile="slow-api") == {
        "delay": ["profile.example.com=900"],
        "throttle": ["base.example.com=10"],
        "drop_connection": ["base.example.com/offline"],
        "fail_rate": ["base.example.com=5"],
    }


def test_load_config_profile_requires_existing_named_profile(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"filter": "base.example.com", "profiles": {"known": {"filter": "known.example.com"}}}),
        encoding="utf-8",
    )

    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        try:
            resolve_filter_settings(config_profile="missing-profile")
        except ValueError as exc:
            assert "missing-profile" in str(exc)
        else:
            raise AssertionError("Expected missing named profile to raise ValueError")


def test_resolve_filter_settings_prefers_config_and_cli_over_http_env(tmp_path):
    config_path = tmp_path / "filters.json"
    config_path.write_text(
        json.dumps(
            {
                "filter": "config.example.com",
                "filter_user_agent": "ConfigUA",
            }
        ),
        encoding="utf-8",
    )

    env = {
        "JAALA_CONFIG": str(config_path),
        "JAALA_FILTER": "env.example.com",
        "JAALA_FILTER_USER_AGENT": "EnvUA",
    }
    with patch.dict(os.environ, env, clear=False):
        settings = resolve_filter_settings(
            filter_pattern="cli.example.com",
            filter_user_agent="CliUA",
        )

    assert settings == {
        "filter": "cli.example.com",
        "filter_user_agent": "CliUA",
    }


def test_load_response_config_reads_response_settings(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "map_local": "api.example.com=/tmp/fixture.json",
                "map_remote": "api.example.com=https://example.com/fixture.json",
                "status_code": "api.example.com=503",
                "add_header": "api.example.com=X-Test:yes",
                "response_text_replace": "api.example.com=hello>>>world",
            }
        ),
        encoding="utf-8",
    )

    config = load_response_config(str(config_path))

    assert config == {
        "map_local": "api.example.com=/tmp/fixture.json",
        "map_remote": "api.example.com=https://example.com/fixture.json",
        "status_code": "api.example.com=503",
        "add_header": "api.example.com=X-Test:yes",
        "response_text_replace": "api.example.com=hello>>>world",
    }


def test_load_response_config_accepts_response_text_replace_array(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "response_text_replace": [
                    "api.example.com=hello>>>world",
                    "cdn.example.com=foo>>>bar",
                ],
            }
        ),
        encoding="utf-8",
    )

    config = load_response_config(str(config_path))

    assert config == {
        "response_text_replace": [
            "api.example.com=hello>>>world",
            "cdn.example.com=foo>>>bar",
        ],
    }


def test_load_response_config_rejects_old_body_replace_key(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"body_replace": "api.example.com=hello>>>world"}),
        encoding="utf-8",
    )

    try:
        load_response_config(str(config_path))
    except ValueError as exc:
        assert "body_replace" in str(exc)
        assert "response_text_replace" in str(exc)
    else:
        raise AssertionError("Expected old body_replace key to be rejected")


def test_resolve_response_settings_prefers_config_and_cli_over_http_env(tmp_path):
    config_path = tmp_path / "responses.json"
    config_path.write_text(
        json.dumps(
            {
                "map_local": "config.example.com=/tmp/config.json",
                "map_remote": "config.example.com=https://example.com/config.json",
                "status_code": "config.example.com=418",
                "add_header": "config.example.com=X-Config:yes",
                "response_text_replace": "config.example.com=foo>>>bar",
            }
        ),
        encoding="utf-8",
    )

    env = {
        "JAALA_CONFIG": str(config_path),
        "JAALA_MAP_LOCAL": "env.example.com=/tmp/env.json",
        "JAALA_MAP_REMOTE": "env.example.com=https://example.com/env.json",
        "JAALA_STATUS_CODE": "env.example.com=429",
        "JAALA_ADD_HEADER": "env.example.com=X-Env:yes",
        "JAALA_BODY_REPLACE": "env.example.com=one>>>two",
    }
    with patch.dict(os.environ, env, clear=False):
        settings = resolve_response_settings(
            map_local="cli.example.com=/tmp/cli.json",
            map_remote="cli.example.com=https://example.com/cli.json",
            status_code="cli.example.com=503",
            add_header="cli.example.com=X-Cli:yes",
            response_text_replace="cli.example.com=alpha>>>beta",
        )

    assert settings == {
        "map_local": "cli.example.com=/tmp/cli.json",
        "map_remote": "cli.example.com=https://example.com/cli.json",
        "status_code": "cli.example.com=503",
        "add_header": "cli.example.com=X-Cli:yes",
        "response_text_replace": "cli.example.com=alpha>>>beta",
    }


def test_load_request_config_reads_request_settings(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "request_header": "api.example.com=X-Test:yes",
                "request_body_replace": "api.example.com=hello>>>world",
            }
        ),
        encoding="utf-8",
    )

    config = load_request_config(str(config_path))

    assert config == {
        "request_header": "api.example.com=X-Test:yes",
        "request_body_replace": "api.example.com=hello>>>world",
    }


def test_resolve_request_settings_prefers_config_and_cli_over_http_env(tmp_path):
    config_path = tmp_path / "requests.json"
    config_path.write_text(
        json.dumps(
            {
                "request_header": "config.example.com=X-Config:yes",
                "request_body_replace": "config.example.com=foo>>>bar",
            }
        ),
        encoding="utf-8",
    )

    env = {
        "JAALA_CONFIG": str(config_path),
        "JAALA_REQUEST_HEADER": "env.example.com=X-Env:yes",
        "JAALA_REQUEST_BODY_REPLACE": "env.example.com=one>>>two",
    }
    with patch.dict(os.environ, env, clear=False):
        settings = resolve_request_settings(
            request_header="cli.example.com=X-Cli:yes",
            request_body_replace="cli.example.com=alpha>>>beta",
        )

    assert settings == {
        "request_header": "cli.example.com=X-Cli:yes",
        "request_body_replace": "cli.example.com=alpha>>>beta",
    }


def test_load_websocket_message_config_reads_rules(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "websocket_message_replace": "ws.example.com/socket=hello>>>world",
                "websocket_drop_message": ["ws.example.com/drop"],
                "websocket_fail_rate": ["ws.example.com/flaky=100"],
                "websocket_delay": ["ws.example.com/slow=250"],
                "websocket_throttle": ["ws.example.com/large=1"],
            }
        ),
        encoding="utf-8",
    )

    config = load_websocket_message_config(str(config_path))

    assert config == {
        "websocket_message_replace": "ws.example.com/socket=hello>>>world",
        "websocket_drop_message": ["ws.example.com/drop"],
        "websocket_fail_rate": ["ws.example.com/flaky=100"],
        "websocket_delay": ["ws.example.com/slow=250"],
        "websocket_throttle": ["ws.example.com/large=1"],
    }


def test_resolve_websocket_message_settings_merges_config_env_and_cli(tmp_path):
    config_path = tmp_path / "websocket.json"
    config_path.write_text(
        json.dumps(
            {
                "websocket_message_replace": "config.example.com=foo>>>bar",
                "websocket_drop_message": ["config.example.com/drop"],
                "websocket_fail_rate": ["config.example.com/flaky=25"],
                "websocket_delay": ["config.example.com/slow=250"],
                "websocket_throttle": ["config.example.com/large=1"],
            }
        ),
        encoding="utf-8",
    )

    env = {
        "JAALA_CONFIG": str(config_path),
        "JAALA_WEBSOCKET_MESSAGE_REPLACE": "env.example.com=one>>>two",
        "JAALA_WEBSOCKET_DROP_MESSAGE": json.dumps(["env.example.com/drop"]),
        "JAALA_WEBSOCKET_FAIL_RATE": json.dumps(["env.example.com/flaky=50"]),
        "JAALA_WEBSOCKET_DELAY": json.dumps(["env.example.com/slow=500"]),
        "JAALA_WEBSOCKET_THROTTLE": json.dumps(["env.example.com/large=2"]),
    }
    with patch.dict(os.environ, env, clear=False):
        settings = resolve_websocket_message_settings(
            websocket_message_replace="cli.example.com=alpha>>>beta",
            websocket_drop_message=["cli.example.com/drop"],
            websocket_fail_rate=["cli.example.com/flaky=100"],
            websocket_delay=["cli.example.com/slow=750"],
            websocket_throttle=["cli.example.com/large=3"],
        )

    assert settings == {
        "websocket_message_replace": "cli.example.com=alpha>>>beta",
        "websocket_drop_message": [
            "config.example.com/drop",
            "env.example.com/drop",
            "cli.example.com/drop",
        ],
        "websocket_fail_rate": [
            "config.example.com/flaky=25",
            "env.example.com/flaky=50",
            "cli.example.com/flaky=100",
        ],
        "websocket_delay": [
            "config.example.com/slow=250",
            "env.example.com/slow=500",
            "cli.example.com/slow=750",
        ],
        "websocket_throttle": [
            "config.example.com/large=1",
            "env.example.com/large=2",
            "cli.example.com/large=3",
        ],
    }


def test_resolve_websocket_replay_settings_merges_config_env_and_cli(tmp_path):
    config_path = tmp_path / "websocket.json"
    config_path.write_text(
        json.dumps(
            {
                "websocket_replay": "/tmp/config.jsonl",
                "websocket_replay_pattern": "config.example.com/socket",
            }
        ),
        encoding="utf-8",
    )

    env = {
        "JAALA_CONFIG": str(config_path),
        "JAALA_WEBSOCKET_REPLAY_FILE": "/tmp/env.jsonl",
        "JAALA_WEBSOCKET_REPLAY_PATTERN": "env.example.com/socket",
    }
    with patch.dict(os.environ, env, clear=False):
        settings = resolve_websocket_replay_settings(
            replay_file="/tmp/cli.jsonl",
            replay_pattern="cli.example.com/socket",
        )

    assert settings == {
        "websocket_replay": "/tmp/cli.jsonl",
        "websocket_replay_pattern": "cli.example.com/socket",
    }


def test_load_network_conditions_config_reads_rules(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "delay": ["api.example.com=2000"],
                "throttle": ["api.example.com=50"],
                "drop_connection": ["api.example.com/flaky"],
                "fail_rate": ["api.example.com=30"],
            }
        ),
        encoding="utf-8",
    )

    config = load_network_conditions_config(str(config_path))

    assert config == {
        "delay": ["api.example.com=2000"],
        "throttle": ["api.example.com=50"],
        "drop_connection": ["api.example.com/flaky"],
        "fail_rate": ["api.example.com=30"],
    }


def test_resolve_network_condition_settings_prefers_config_and_cli_over_http_env(tmp_path):
    config_path = tmp_path / "network.json"
    config_path.write_text(
        json.dumps(
            {
                "delay": ["config.example.com=1000"],
                "throttle": ["config.example.com=25"],
                "drop_connection": ["config.example.com/flaky"],
                "fail_rate": ["config.example.com=10"],
            }
        ),
        encoding="utf-8",
    )

    env = {
        "JAALA_CONFIG": str(config_path),
        "JAALA_DELAY": json.dumps(["env.example.com=2000"]),
        "JAALA_THROTTLE": json.dumps(["env.example.com=50"]),
        "JAALA_DROP_CONNECTION": json.dumps(["env.example.com/flaky"]),
        "JAALA_FAIL_RATE": json.dumps(["env.example.com=30"]),
    }
    with patch.dict(os.environ, env, clear=False):
        settings = resolve_network_condition_settings(
            delay=["cli.example.com=3000"],
            throttle=["cli.example.com=75"],
            drop_connection=["cli.example.com/flaky"],
            fail_rate=["cli.example.com=40"],
        )

    assert settings == {
        "delay": ["config.example.com=1000", "cli.example.com=3000"],
        "throttle": ["config.example.com=25", "cli.example.com=75"],
        "drop_connection": ["config.example.com/flaky", "cli.example.com/flaky"],
        "fail_rate": ["config.example.com=10", "cli.example.com=40"],
    }
