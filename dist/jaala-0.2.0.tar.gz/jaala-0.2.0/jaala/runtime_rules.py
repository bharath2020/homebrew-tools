"""Runtime rule storage helpers for active Jaala sessions."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

RUNTIME_METADATA_KEY = "_jaala_runtime"
RULES_KEY = "rules"
WEBSOCKET_EVENTS_KEY = "websocket_events"
STREAM_EVENTS_KEY = "stream_events"

HTTP_CONFIG_KEYS = (
    "filter",
    "filter_user_agent",
    "map_local",
    "map_remote",
    "status_code",
    "add_header",
    "body_replace",
    "json_replace",
    "request_header",
    "request_body_replace",
    "delay",
    "throttle",
    "drop_connection",
    "fail_rate",
)


def build_runtime_http_config(
    *,
    filter_settings: dict[str, Any],
    response_settings: dict[str, Any],
    request_settings: dict[str, Any],
    network_condition_settings: dict[str, Any],
) -> dict[str, Any]:
    config: dict[str, Any] = {}
    for settings in (filter_settings, response_settings, request_settings, network_condition_settings):
        config.update(settings)

    runtime_rules: list[dict[str, Any]] = []
    body_replace = response_settings.get("body_replace")
    if isinstance(body_replace, str) and body_replace.strip():
        pattern, replacement_text = body_replace.split("=", 1)
        search, replace = replacement_text.split(">>>", 1)
        runtime_rules.append(
            {
                "name": "startup-body-replace",
                "type": "body_replace",
                "enabled": True,
                "match_url": pattern.strip(),
                "search": search.strip(),
                "replace": replace.strip(),
                "source": "startup",
            }
        )

    json_replace = response_settings.get("json_replace")
    if isinstance(json_replace, dict):
        match_url = str(json_replace.get("match_url", "")).strip()
        json_path = str(json_replace.get("json_path", "")).strip()
        if match_url and json_path and "value" in json_replace:
            runtime_rules.append(
                {
                    "name": "startup-json-replace",
                    "type": "json_replace",
                    "enabled": True,
                    "match_url": match_url,
                    "json_path": json_path,
                    "value": json_replace.get("value"),
                    "source": "startup",
                }
            )

    request_header = request_settings.get("request_header")
    if isinstance(request_header, str) and request_header.strip():
        pattern, header_text = request_header.split("=", 1)
        header_name, header_value = header_text.split(":", 1)
        runtime_rules.append(
            {
                "name": "startup-request-header",
                "type": "request_header",
                "enabled": True,
                "match_url": pattern.strip(),
                "header_name": header_name.strip(),
                "header_value": header_value.strip(),
                "source": "startup",
            }
        )

    config[RUNTIME_METADATA_KEY] = {RULES_KEY: runtime_rules}
    return config


def runtime_config_path(lock_dir: Path, pid: int) -> Path:
    return lock_dir / f"runtime-rules-{pid}.json"


def runtime_status_path(lock_dir: Path, pid: int) -> Path:
    return lock_dir / f"runtime-status-{pid}.json"


def load_runtime_config(path: str | os.PathLike[str]) -> dict[str, Any]:
    config_path = Path(path)
    if not config_path.is_file():
        return {}
    with config_path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"Runtime config {str(config_path)!r} must contain a JSON object")
    return data


def _runtime_metadata(config: dict[str, Any]) -> dict[str, Any]:
    metadata = config.setdefault(RUNTIME_METADATA_KEY, {})
    if not isinstance(metadata, dict):
        raise ValueError("Runtime rule metadata must be a JSON object")
    return metadata


def _runtime_rules(config: dict[str, Any]) -> list[dict[str, Any]]:
    metadata = config.get(RUNTIME_METADATA_KEY, {})
    if not isinstance(metadata, dict):
        return []
    rules = metadata.get(RULES_KEY, [])
    if not isinstance(rules, list):
        return []
    return [rule for rule in rules if isinstance(rule, dict)]


def runtime_websocket_events(config: dict[str, Any]) -> list[dict[str, Any]]:
    metadata = config.get(RUNTIME_METADATA_KEY, {})
    if not isinstance(metadata, dict):
        return []
    events = metadata.get(WEBSOCKET_EVENTS_KEY, [])
    if not isinstance(events, list):
        return []
    return [event for event in events if isinstance(event, dict)]


def runtime_stream_events(config: dict[str, Any]) -> list[dict[str, Any]]:
    metadata = config.get(RUNTIME_METADATA_KEY, {})
    if not isinstance(metadata, dict):
        return []
    events = metadata.get(STREAM_EVENTS_KEY, [])
    if not isinstance(events, list):
        return []
    return [event for event in events if isinstance(event, dict)]


def _active_runtime_rule(config: dict[str, Any], rule_type: str) -> dict[str, Any] | None:
    rules = _runtime_rules(config)
    active: dict[str, Any] | None = None
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        if rule.get("type") != rule_type or not rule.get("enabled", True):
            continue
        active = rule
    return active


def _active_body_replace_rule(config: dict[str, Any]) -> dict[str, Any] | None:
    return _active_runtime_rule(config, "body_replace")


def _active_request_header_rule(config: dict[str, Any]) -> dict[str, Any] | None:
    return _active_runtime_rule(config, "request_header")


def _active_json_replace_rule(config: dict[str, Any]) -> dict[str, Any] | None:
    return _active_runtime_rule(config, "json_replace")


def normalize_runtime_config(config: dict[str, Any]) -> dict[str, Any]:
    normalized = {key: value for key, value in config.items() if key in HTTP_CONFIG_KEYS}

    metadata = config.get(RUNTIME_METADATA_KEY)
    if isinstance(metadata, dict):
        normalized[RUNTIME_METADATA_KEY] = metadata

    active = _active_body_replace_rule(config)
    if active is not None:
        normalized["body_replace"] = (
            f"{active['match_url']}={active['search']}>>>{active['replace']}"
        )
    else:
        normalized.pop("body_replace", None)

    active_request_header = _active_request_header_rule(config)
    if active_request_header is not None:
        normalized["request_header"] = (
            f"{active_request_header['match_url']}="
            f"{active_request_header['header_name']}:{active_request_header['header_value']}"
        )
    else:
        normalized.pop("request_header", None)

    return normalized


def write_runtime_config(path: str | os.PathLike[str], config: dict[str, Any]) -> None:
    config_path = Path(path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = config_path.with_suffix(config_path.suffix + ".tmp")
    normalized = normalize_runtime_config(config)
    with temp_path.open("w", encoding="utf-8") as handle:
        json.dump(normalized, handle, indent=2, sort_keys=True)
    temp_path.replace(config_path)


def add_body_replace_rule(
    path: str | os.PathLike[str],
    *,
    name: str,
    match_url: str,
    search: str,
    replace: str,
) -> dict[str, Any]:
    config = load_runtime_config(path)
    metadata = _runtime_metadata(config)
    rules = metadata.setdefault(RULES_KEY, [])
    if not isinstance(rules, list):
        raise ValueError("Runtime rules must be a JSON array")

    updated = False
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        if rule.get("name") == name:
            rule.update(
                {
                    "type": "body_replace",
                    "enabled": True,
                    "match_url": match_url,
                    "search": search,
                    "replace": replace,
                    "source": "runtime",
                }
            )
            updated = True
            break

    if not updated:
        rules.append(
            {
                "name": name,
                "type": "body_replace",
                "enabled": True,
                "match_url": match_url,
                "search": search,
                "replace": replace,
                "source": "runtime",
            }
        )

    write_runtime_config(path, config)
    return normalize_runtime_config(config)


def add_request_header_rule(
    path: str | os.PathLike[str],
    *,
    name: str,
    match_url: str,
    header_name: str,
    header_value: str,
) -> dict[str, Any]:
    config = load_runtime_config(path)
    metadata = _runtime_metadata(config)
    rules = metadata.setdefault(RULES_KEY, [])
    if not isinstance(rules, list):
        raise ValueError("Runtime rules must be a JSON array")

    updated = False
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        if rule.get("name") == name:
            rule.update(
                {
                    "type": "request_header",
                    "enabled": True,
                    "match_url": match_url,
                    "header_name": header_name,
                    "header_value": header_value,
                    "source": "runtime",
                }
            )
            updated = True
            break

    if not updated:
        rules.append(
            {
                "name": name,
                "type": "request_header",
                "enabled": True,
                "match_url": match_url,
                "header_name": header_name,
                "header_value": header_value,
                "source": "runtime",
            }
        )

    write_runtime_config(path, config)
    return normalize_runtime_config(config)


def add_json_replace_rule(
    path: str | os.PathLike[str],
    *,
    name: str,
    match_url: str,
    json_path: str,
    value: Any,
) -> dict[str, Any]:
    config = load_runtime_config(path)
    metadata = _runtime_metadata(config)
    rules = metadata.setdefault(RULES_KEY, [])
    if not isinstance(rules, list):
        raise ValueError("Runtime rules must be a JSON array")

    updated = False
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        if rule.get("name") == name:
            rule.update(
                {
                    "type": "json_replace",
                    "enabled": True,
                    "match_url": match_url,
                    "json_path": json_path,
                    "value": value,
                    "source": "runtime",
                }
            )
            updated = True
            break

    if not updated:
        rules.append(
            {
                "name": name,
                "type": "json_replace",
                "enabled": True,
                "match_url": match_url,
                "json_path": json_path,
                "value": value,
                "source": "runtime",
            }
        )

    write_runtime_config(path, config)
    return normalize_runtime_config(config)


def enqueue_websocket_event(
    path: str | os.PathLike[str],
    *,
    event_id: str,
    match_url: str,
    text: str,
    drop_live_server_messages: bool = False,
) -> dict[str, Any]:
    config = load_runtime_config(path)
    metadata = _runtime_metadata(config)
    events = metadata.setdefault(WEBSOCKET_EVENTS_KEY, [])
    if not isinstance(events, list):
        raise ValueError("Runtime WebSocket events must be a JSON array")
    events.append(
        {
            "id": event_id,
            "type": "websocket_send",
            "enabled": True,
            "match_url": match_url,
            "text": text,
            "drop_live_server_messages": drop_live_server_messages,
            "source": "runtime",
        }
    )
    write_runtime_config(path, config)
    return normalize_runtime_config(config)


def enqueue_stream_event(
    path: str | os.PathLike[str],
    *,
    event_id: str,
    match_url: str,
    chunk: str,
    event: str | None = None,
) -> dict[str, Any]:
    config = load_runtime_config(path)
    metadata = _runtime_metadata(config)
    events = metadata.setdefault(STREAM_EVENTS_KEY, [])
    if not isinstance(events, list):
        raise ValueError("Runtime stream events must be a JSON array")
    payload: dict[str, Any] = {
        "id": event_id,
        "type": "stream_send",
        "enabled": True,
        "match_url": match_url,
        "chunk": chunk,
        "source": "runtime",
    }
    if event:
        payload["event"] = event
    events.append(payload)
    write_runtime_config(path, config)
    return normalize_runtime_config(config)


def set_runtime_rule_enabled(
    path: str | os.PathLike[str],
    *,
    name: str,
    enabled: bool,
) -> dict[str, Any]:
    config = load_runtime_config(path)
    metadata = _runtime_metadata(config)
    rules = metadata.setdefault(RULES_KEY, [])
    if not isinstance(rules, list):
        raise ValueError("Runtime rules must be a JSON array")

    found = False
    for rule in rules:
        if isinstance(rule, dict) and rule.get("name") == name:
            rule["enabled"] = enabled
            found = True
    if not found:
        raise ValueError(f"Runtime rule {name!r} was not found")

    write_runtime_config(path, config)
    return normalize_runtime_config(config)


def remove_runtime_rule(
    path: str | os.PathLike[str],
    *,
    name: str,
) -> dict[str, Any]:
    config = load_runtime_config(path)
    metadata = _runtime_metadata(config)
    rules = metadata.setdefault(RULES_KEY, [])
    if not isinstance(rules, list):
        raise ValueError("Runtime rules must be a JSON array")

    removed = False
    new_rules: list[dict[str, Any]] = []
    for rule in rules:
        if isinstance(rule, dict) and rule.get("name") == name:
            removed = True
            continue
        new_rules.append(rule)
    if not removed:
        raise ValueError(f"Runtime rule {name!r} was not found")

    metadata[RULES_KEY] = new_rules
    write_runtime_config(path, config)
    return normalize_runtime_config(config)


def list_runtime_rules(path: str | os.PathLike[str]) -> list[dict[str, Any]]:
    return _runtime_rules(load_runtime_config(path))
