"""Command-line parsing for Jaala."""

from __future__ import annotations

import argparse
import json
from typing import Any

from . import __version__
from .network_conditions import (
    parse_delay_rules as _parse_delay_rules,
    parse_drop_connection_rules as _parse_drop_connection_rules,
    parse_fail_rate_rules as _parse_fail_rate_rules,
    parse_throttle_rules as _parse_throttle_rules,
)

JSONL_RECORD_TYPES = ["http", "websocket_message", "http_stream_chunk"]

ROOT_COMMANDS: tuple[tuple[tuple[str, ...], str], ...] = (
    (("run",), "start a full proxy session"),
    (("record",), "capture Simulator traffic to JSONL/HAR"),
    (("replay",), "replay recorded WebSocket server messages"),
    (("scenario",), "run scenario/config files"),
    (("status",), "inspect proxy/session readiness"),
    (("cert",), "inspect or trust Jaala certificates"),
    (("sims",), "list available simulators"),
    (("cleanup",), "restore proxy/session state"),
    (("rules",), "inspect or update live HTTP rules"),
    (("sockets",), "send live WebSocket events"),
    (("streams",), "send live HTTP stream chunks"),
    (("capabilities",), "print machine-readable CLI metadata"),
)

CAPABILITY_COMMANDS: tuple[dict[str, Any], ...] = (
    {"path": ["run"], "summary": "Start a full proxy session", "parser": "run", "outputs": ["jsonl", "har", "mitmproxy-flow"]},
    {"path": ["record"], "summary": "Capture Simulator traffic to JSONL/HAR", "parser": "record", "outputs": ["jsonl", "har"]},
    {"path": ["replay"], "summary": "Replay recorded WebSocket server messages", "parser": "replay", "outputs": ["mitmproxy-flow"]},
    {"path": ["scenario", "run"], "summary": "Run a scenario/config file", "parser": "scenario_run", "outputs": ["jsonl", "har", "mitmproxy-flow"]},
    {"path": ["status"], "summary": "Inspect proxy/session readiness", "parser": "status", "outputs": ["json"]},
    {"path": ["cert", "status"], "summary": "Inspect simulator certificate readiness", "parser": "cert_status", "outputs": ["json"]},
    {"path": ["cert", "trust-macos"], "summary": "Trust the Jaala CA in macOS", "parser": "cert_trust_macos", "outputs": []},
    {"path": ["sims", "list"], "summary": "List available simulators", "parser": "sims_list", "outputs": ["text"]},
    {"path": ["cleanup"], "summary": "Restore proxy/session state", "parser": "cleanup", "outputs": []},
    {"path": ["rules", "show"], "summary": "Show active runtime HTTP rules", "options": ["--json"], "outputs": ["json", "text"]},
    {"path": ["rules", "status"], "summary": "Show runtime reload status", "options": ["--json"], "outputs": ["json", "text"]},
    {"path": ["rules", "add", "response-text-replace"], "summary": "Add or update a live response text replacement rule", "options": ["--name", "--match-url", "--search", "--replace"], "outputs": []},
    {"path": ["rules", "add", "json-replace"], "summary": "Add or update a live JSON replacement rule", "options": ["--name", "--match-url", "--json-path", "--value-string", "--value-json"], "outputs": []},
    {"path": ["rules", "add", "request-header"], "summary": "Add or update a live request header rule", "options": ["--name", "--match-url", "--header-name", "--header-value"], "outputs": []},
    {"path": ["sockets", "send"], "summary": "Queue a live WebSocket event", "parser": "sockets_send", "outputs": ["json", "text"]},
    {"path": ["streams", "send"], "summary": "Queue a live HTTP stream chunk", "parser": "streams_send", "outputs": ["json", "text"]},
    {"path": ["capabilities"], "summary": "Print machine-readable CLI metadata", "parser": "capabilities", "outputs": ["json"]},
)

LEGACY_FLAG_ALIASES = {
    "--add-header",
    "--add-request-header",
    "--add-response-header",
    "--response-text-replace",
    "--cleanup",
    "--config",
    "--delay",
    "--drop-connection",
    "--fail-rate",
    "--filter",
    "--filter-user-agent",
    "--json",
    "--json-file",
    "--list-sims",
    "--map-local",
    "--map-remote",
    "--network-service",
    "--no-body",
    "--no-headers",
    "--no-websockets",
    "--output",
    "-o",
    "--port",
    "--probe-cert-readiness",
    "--probe-cert-readiness-json",
    "--profile",
    "--quiet",
    "-q",
    "--response-text-replace",
    "--request-body-replace",
    "--request-header",
    "--save-har",
    "--sim",
    "--status",
    "--status-code",
    "--status-json",
    "--throttle",
    "--trust-macos-cert",
    "--verbose",
    "-v",
    "--version",
    "--websocket-delay",
    "--websocket-drop-message",
    "--websocket-fail-rate",
    "--websocket-message-replace",
    "--websocket-replay",
    "--websocket-replay-pattern",
    "--websocket-throttle",
}


def format_root_help() -> str:
    lines = [
        "usage: jaala <command> [options]",
        "",
        "Jaala: iOS Simulator network capture, replay, and failure testing.",
        "",
        "Commands:",
    ]
    for path, summary in ROOT_COMMANDS:
        lines.append(f"  {' '.join(path):<13} {summary}")
    lines.extend(
        [
            "",
            "Use: jaala <command> --help",
            "Legacy flat flags still work. Advanced session options live under: jaala run --help",
        ]
    )
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="jaala",
        description="Capture iOS Simulator traffic for Jaala workflows.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--list-sims", action="store_true", help="List available simulators and exit")
    parser.add_argument(
        "--sim",
        metavar="UDID",
        default=None,
        help="Simulator UDID to use (default: first booted simulator)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=0,
        help="Proxy listen port (default: auto-select free port)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print each captured flow as JSON Lines",
    )
    parser.add_argument(
        "--json-file",
        metavar="FILE",
        default=None,
        help="Write captured flows as JSON Lines to FILE",
    )
    parser.add_argument(
        "--save-har",
        metavar="FILE",
        default=None,
        help="Save captured flows to a HAR file on exit",
    )
    parser.add_argument(
        "--no-headers",
        action="store_true",
        help="Hide request and response headers in console and JSON output",
    )
    parser.add_argument(
        "--no-body",
        action="store_true",
        help="Hide request and response bodies in console and JSON output",
    )
    parser.add_argument(
        "--no-websockets",
        action="store_true",
        help="Disable WebSocket capture and JSONL output",
    )
    parser.add_argument(
        "--output",
        "-o",
        metavar="FILE",
        default=None,
        help="Write raw mitmproxy flow data to FILE",
    )
    parser.add_argument(
        "--config",
        metavar="FILE",
        default=None,
        help="Load Jaala settings from JSON FILE",
    )
    parser.add_argument(
        "--profile",
        metavar="NAME",
        default=None,
        help="Select a named config profile from --config for scenario-style reuse",
    )
    parser.add_argument(
        "--filter",
        metavar="PATTERN",
        default=None,
        help="Only capture flows whose URL matches PATTERN",
    )
    parser.add_argument(
        "--filter-user-agent",
        metavar="PATTERN",
        default=None,
        help="Only capture flows whose User-Agent matches PATTERN",
    )
    parser.add_argument(
        "--map-local",
        metavar="PATTERN=FILE",
        default=None,
        help="Serve FILE as the response body for matching URLs",
    )
    parser.add_argument(
        "--map-remote",
        metavar="PATTERN=URL",
        default=None,
        help="Fetch URL and use it as the response for matching URLs",
    )
    parser.add_argument(
        "--status-code",
        metavar="PATTERN=CODE",
        default=None,
        help="Override the response status code for matching URLs",
    )
    parser.add_argument(
        "--add-response-header",
        "--add-header",
        dest="add_header",
        metavar="PATTERN=NAME:VALUE",
        default=None,
        help="Add a response header for matching URLs (--add-header is a legacy alias)",
    )
    parser.add_argument(
        "--response-text-replace",
        dest="response_text_replace",
        metavar="PATTERN=SEARCH>>>REPLACE",
        default=None,
        help="Replace matching text inside response bodies for matching URLs",
    )
    parser.add_argument(
        "--add-request-header",
        "--request-header",
        dest="request_header",
        metavar="PATTERN=NAME:VALUE",
        default=None,
        help="Add a request header for matching URLs (--request-header is also supported)",
    )
    parser.add_argument(
        "--request-body-replace",
        metavar="PATTERN=SEARCH>>>REPLACE",
        default=None,
        help="Replace request body text for matching URLs",
    )
    parser.add_argument(
        "--websocket-message-replace",
        metavar="PATTERN=SEARCH>>>REPLACE",
        default=None,
        help="Replace WebSocket message text for matching URLs",
    )
    parser.add_argument(
        "--websocket-drop-message",
        action="append",
        default=[],
        metavar="PATTERN",
        help="Drop WebSocket messages for matching URLs",
    )
    parser.add_argument(
        "--websocket-fail-rate",
        action="append",
        default=[],
        metavar="PATTERN=PERCENT",
        help="Drop WebSocket messages randomly at the given percentage",
    )
    parser.add_argument(
        "--websocket-delay",
        action="append",
        default=[],
        metavar="PATTERN=MS",
        help="Add artificial latency to WebSocket messages for matching URLs",
    )
    parser.add_argument(
        "--websocket-throttle",
        action="append",
        default=[],
        metavar="PATTERN=KBPS",
        help="Delay WebSocket messages based on payload size and throughput",
    )
    parser.add_argument(
        "--websocket-replay",
        metavar="FILE",
        default=None,
        help="Replay recorded server-to-client WebSocket text messages from a JSONL capture file",
    )
    parser.add_argument(
        "--websocket-replay-pattern",
        metavar="PATTERN",
        default=None,
        help="Replay all recorded WebSocket server messages into live flows matching PATTERN",
    )
    parser.add_argument(
        "--delay",
        action="append",
        default=None,
        metavar="PATTERN=MS",
        help="Add artificial latency in milliseconds for matching URLs",
    )
    parser.add_argument(
        "--throttle",
        action="append",
        default=None,
        metavar="PATTERN=KBPS",
        help="Limit response throughput in kilobytes per second for matching URLs",
    )
    parser.add_argument(
        "--drop-connection",
        action="append",
        default=None,
        metavar="PATTERN",
        help="Drop matching requests before a response is created",
    )
    parser.add_argument(
        "--fail-rate",
        action="append",
        default=None,
        metavar="PATTERN=PERCENT",
        help="Drop matching requests randomly at the given percentage",
    )
    parser.add_argument(
        "--network-service",
        default=None,
        help="macOS network service to proxy (default: auto-detect active service)",
    )
    parser.add_argument(
        "--cleanup",
        action="store_true",
        help="Restore proxy settings from a previous crashed session and exit",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        help="Inspect proxy/session/certificate readiness and exit",
    )
    parser.add_argument(
        "--status-json",
        action="store_true",
        help="Print readiness status as JSON and exit",
    )
    parser.add_argument(
        "--probe-cert-readiness",
        action="store_true",
        help="Resolve the simulator, probe cert readiness in its keychain, and exit",
    )
    parser.add_argument(
        "--probe-cert-readiness-json",
        action="store_true",
        help="Print simulator cert readiness probe results as JSON and exit",
    )
    parser.add_argument(
        "--trust-macos-cert",
        action="store_true",
        help="Trust the Jaala CA in the macOS System keychain using sudo",
    )
    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument("--quiet", "-q", action="store_true", help="Suppress startup and shutdown messages")
    verbosity.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose rule reload and mutation debug logging",
    )
    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    args = build_parser().parse_args(argv)
    args.delay = args.delay or []
    args.throttle = args.throttle or []
    args.drop_connection = args.drop_connection or []
    args.fail_rate = args.fail_rate or []
    return args


def _add_session_options(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("simulator/session")
    group.add_argument("--sim", metavar="UDID", default=None, help="Simulator UDID to use")
    group.add_argument("--port", type=int, default=0, help="Proxy listen port")
    group.add_argument("--network-service", default=None, help="macOS network service to proxy")


def _add_capture_options(parser: argparse.ArgumentParser, *, include_json_stdout: bool = True) -> None:
    group = parser.add_argument_group("capture/output")
    if include_json_stdout:
        group.add_argument("--json", action="store_true", help="Print each captured flow as JSON Lines")
    group.add_argument("--json-file", metavar="FILE", default=None, help="Write captured flows as JSON Lines to FILE")
    group.add_argument("--save-har", metavar="FILE", default=None, help="Save captured flows to a HAR file on exit")
    group.add_argument("--output", "-o", metavar="FILE", default=None, help="Write raw mitmproxy flow data to FILE")
    group.add_argument("--no-headers", action="store_true", help="Hide request and response headers")
    group.add_argument("--no-body", action="store_true", help="Hide request and response bodies")
    group.add_argument("--no-websockets", action="store_true", help="Disable WebSocket capture and JSONL output")


def _add_config_and_filter_options(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("matching/config")
    group.add_argument("--config", metavar="FILE", default=None, help="Load Jaala settings from JSON FILE")
    group.add_argument("--profile", metavar="NAME", default=None, help="Select a named config profile")
    group.add_argument("--filter", metavar="PATTERN", default=None, help="Only capture matching URLs")
    group.add_argument("--filter-user-agent", metavar="PATTERN", default=None, help="Only capture matching User-Agent traffic")


def _add_response_rule_options(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("response rules")
    group.add_argument("--map-local", metavar="PATTERN=FILE", default=None, help="Serve FILE as the response body for matching URLs")
    group.add_argument("--map-remote", metavar="PATTERN=URL", default=None, help="Fetch URL and use it as the response")
    group.add_argument("--status-code", metavar="PATTERN=CODE", default=None, help="Override the response status code")
    group.add_argument(
        "--add-response-header",
        "--add-header",
        dest="add_header",
        metavar="PATTERN=NAME:VALUE",
        default=None,
        help="Add a response header (--add-header is a legacy alias)",
    )
    group.add_argument(
        "--response-text-replace",
        dest="response_text_replace",
        metavar="PATTERN=SEARCH>>>REPLACE",
        default=None,
        help="Replace matching text inside response bodies",
    )


def _add_request_rule_options(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("request rules")
    group.add_argument(
        "--add-request-header",
        "--request-header",
        dest="request_header",
        metavar="PATTERN=NAME:VALUE",
        default=None,
        help="Add a request header (--request-header is also supported)",
    )
    group.add_argument("--request-body-replace", metavar="PATTERN=SEARCH>>>REPLACE", default=None, help="Replace request body text")


def _add_websocket_startup_options(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("WebSocket startup rules")
    group.add_argument("--websocket-message-replace", metavar="PATTERN=SEARCH>>>REPLACE", default=None, help="Replace WebSocket message text")
    group.add_argument("--websocket-drop-message", action="append", default=[], metavar="PATTERN", help="Drop WebSocket messages")
    group.add_argument("--websocket-fail-rate", action="append", default=[], metavar="PATTERN=PERCENT", help="Randomly drop WebSocket messages")
    group.add_argument("--websocket-delay", action="append", default=[], metavar="PATTERN=MS", help="Add WebSocket message latency")
    group.add_argument("--websocket-throttle", action="append", default=[], metavar="PATTERN=KBPS", help="Throttle WebSocket messages")
    group.add_argument("--websocket-replay", metavar="FILE", default=None, help="Replay WebSocket messages from JSONL")
    group.add_argument("--websocket-replay-pattern", metavar="PATTERN", default=None, help="Replay messages into matching live flows")


def _add_network_condition_options(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("network conditions")
    group.add_argument("--delay", action="append", default=[], metavar="PATTERN=MS", help="Add response latency")
    group.add_argument("--throttle", action="append", default=[], metavar="PATTERN=KBPS", help="Limit response throughput")
    group.add_argument("--drop-connection", action="append", default=[], metavar="PATTERN", help="Drop matching requests")
    group.add_argument("--fail-rate", action="append", default=[], metavar="PATTERN=PERCENT", help="Randomly drop matching requests")


def _add_verbosity_options(parser: argparse.ArgumentParser) -> None:
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--quiet", "-q", action="store_true", help="Suppress startup and shutdown messages")
    group.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")


def build_run_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala run", description="Start a full Jaala proxy session.")
    _add_session_options(parser)
    _add_capture_options(parser)
    _add_config_and_filter_options(parser)
    _add_response_rule_options(parser)
    _add_request_rule_options(parser)
    _add_websocket_startup_options(parser)
    _add_network_condition_options(parser)
    parser.add_argument("--trust-macos-cert", action="store_true", help="Trust the Jaala CA in the macOS System keychain using sudo")
    _add_verbosity_options(parser)
    return parser


def _add_common_run_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--sim", metavar="UDID", default=None, help="Simulator UDID to use")
    parser.add_argument("--port", type=int, default=0, help="Proxy listen port")
    parser.add_argument("--filter", metavar="PATTERN", default=None, help="Only capture matching URLs")
    parser.add_argument("--filter-user-agent", metavar="PATTERN", default=None, help="Only capture matching User-Agent traffic")
    parser.add_argument("--json-file", metavar="FILE", default=None, help="Write captured flows as JSON Lines to FILE")
    parser.add_argument("--save-har", metavar="FILE", default=None, help="Save captured flows to a HAR file on exit")
    parser.add_argument("--config", metavar="FILE", default=None, help="Load Jaala settings from JSON FILE")
    parser.add_argument("--profile", metavar="NAME", default=None, help="Select a named config profile")
    parser.add_argument("--quiet", "-q", action="store_true", help="Suppress startup and shutdown messages")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")


def build_record_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala record", description="Record Simulator traffic into agent-readable artifacts.")
    _add_common_run_options(parser)
    parser.add_argument("--json", action="store_true", help="Print each captured flow as JSON Lines")
    return parser


def build_replay_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala replay", description="Replay captured artifacts into a live Jaala session.")
    parser.add_argument("capture", help="JSONL capture file to replay")
    _add_common_run_options(parser)
    parser.add_argument("--websocket-pattern", metavar="PATTERN", default=None, help="Replay WebSocket server messages into live flows matching PATTERN")
    return parser


def build_scenario_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala scenario", description="Run agent-authored Jaala scenarios.")
    subparsers = parser.add_subparsers(dest="scenario_command", required=True)
    run_parser = subparsers.add_parser("run", help="Run a scenario JSON file")
    run_parser.add_argument("scenario_file", help="Scenario JSON file")
    _add_common_run_options(run_parser)
    return parser


def build_sockets_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala sockets", description="Control WebSocket events in the active Jaala session.")
    subparsers = parser.add_subparsers(dest="sockets_command", required=True)
    send_parser = subparsers.add_parser("send", help="Send a server-to-client text event on matching open WebSockets")
    send_parser.add_argument("--json", action="store_true", dest="json_output", help="Print command output as JSON")
    send_parser.add_argument("--match-url", required=True, help="Substring or re: regex to match WebSocket URL")
    send_parser.add_argument("--text", help="Text payload to send")
    send_parser.add_argument("--text-file", help="Read text payload from FILE")
    send_parser.add_argument("--drop-live-server-messages", action="store_true", help="Drop later live server messages for matching sockets")
    send_parser.add_argument("--id", default=None, help="Stable event id")
    return parser


def build_streams_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala streams", description="Control HTTP stream events in the active Jaala session.")
    subparsers = parser.add_subparsers(dest="streams_command", required=True)
    send_parser = subparsers.add_parser("send", help="Send a chunk on matching open HTTP streams")
    send_parser.add_argument("--json", action="store_true", dest="json_output", help="Print command output as JSON")
    send_parser.add_argument("--match-url", required=True, help="Substring or re: regex to match stream URL")
    send_parser.add_argument("--text", help="Raw chunk text to send")
    send_parser.add_argument("--text-file", help="Read raw chunk text from FILE")
    send_parser.add_argument("--event", help="SSE event name; formats --data-json or --data as an SSE event")
    send_parser.add_argument("--data", help="SSE data text")
    send_parser.add_argument("--data-json", help="SSE data JSON literal")
    send_parser.add_argument("--id", default=None, help="Stable event id")
    return parser


def build_status_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala status", description="Inspect proxy/session/certificate readiness.")
    parser.add_argument("--json", action="store_true", dest="json_output", help="Print readiness status as JSON")
    parser.add_argument("--network-service", default=None, help="macOS network service to inspect")
    return parser


def build_cert_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala cert", description="Inspect or trust Jaala certificates.")
    subparsers = parser.add_subparsers(dest="cert_command", required=True)
    status_parser = subparsers.add_parser("status", help="Inspect simulator certificate readiness")
    status_parser.add_argument("--json", action="store_true", dest="json_output", help="Print certificate readiness as JSON")
    status_parser.add_argument("--sim", metavar="UDID", default=None, help="Simulator UDID to inspect")
    trust_parser = subparsers.add_parser("trust-macos", help="Trust the Jaala CA in macOS")
    trust_parser.add_argument("--quiet", "-q", action="store_true", help="Suppress trust command output")
    return parser


def build_sims_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala sims", description="Inspect available iOS Simulators.")
    subparsers = parser.add_subparsers(dest="sims_command", required=True)
    subparsers.add_parser("list", help="List available simulators")
    return parser


def build_cleanup_parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(prog="jaala cleanup", description="Restore proxy settings from a previous Jaala session.")


def build_capabilities_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala capabilities", description="Print machine-readable CLI metadata.")
    parser.add_argument("--json", action="store_true", required=True, dest="json_output", help="Print CLI metadata as JSON")
    return parser


def parse_run_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_run_parser().parse_args(argv)


def parse_record_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_record_parser().parse_args(argv)


def parse_replay_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_replay_parser().parse_args(argv)


def parse_scenario_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_scenario_parser().parse_args(argv)


def parse_sockets_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_sockets_parser().parse_args(argv)


def parse_streams_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_streams_parser().parse_args(argv)


def parse_status_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_status_parser().parse_args(argv)


def parse_cert_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_cert_parser().parse_args(argv)


def parse_sims_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_sims_parser().parse_args(argv)


def parse_cleanup_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_cleanup_parser().parse_args(argv)


def parse_capabilities_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_capabilities_parser().parse_args(argv)


def build_rules_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala rules", description="Inspect and update active Jaala runtime rules.")
    parser.add_argument("--json", action="store_true", dest="json_output", help="Print rules output as JSON")
    subparsers = parser.add_subparsers(dest="rules_command", required=True)

    show_parser = subparsers.add_parser("show", help="Show active runtime rules")
    show_parser.add_argument("--json", action="store_true", dest="json_output", help="Print rules output as JSON")

    status_parser = subparsers.add_parser("status", help="Show runtime reload status")
    status_parser.add_argument("--json", action="store_true", dest="json_output", help="Print rules output as JSON")

    enable_parser = subparsers.add_parser("enable", help="Enable a runtime rule by name")
    enable_parser.add_argument("--name", required=True, help="Stable rule name")

    disable_parser = subparsers.add_parser("disable", help="Disable a runtime rule by name")
    disable_parser.add_argument("--name", required=True, help="Stable rule name")

    remove_parser = subparsers.add_parser("remove", help="Remove a runtime rule by name")
    remove_parser.add_argument("--name", required=True, help="Stable rule name")

    add_parser = subparsers.add_parser("add", help="Add or update a runtime rule")
    add_subparsers = add_parser.add_subparsers(dest="rule_type", required=True)

    response_text_replace = add_subparsers.add_parser("response-text-replace", help="Add or update a response text replacement rule")
    response_text_replace.add_argument("--name", required=True, help="Stable rule name")
    response_text_replace.add_argument("--match-url", required=True, help="Substring or re: regex to match request URL")
    response_text_replace.add_argument("--search", required=True, help="Text to replace in matching response bodies")
    response_text_replace.add_argument("--replace", required=True, help="Replacement text")

    json_replace = add_subparsers.add_parser("json-replace", help="Add or update a JSON path replacement rule")
    json_replace.add_argument("--name", required=True, help="Stable rule name")
    json_replace.add_argument("--match-url", required=True, help="Substring or re: regex to match request URL")
    json_replace.add_argument("--json-path", required=True, help="Dot-separated JSON path, with '*' allowed for wildcards")
    json_replace_value = json_replace.add_mutually_exclusive_group(required=True)
    json_replace_value.add_argument("--value-string", help="String value to assign at the JSON path")
    json_replace_value.add_argument("--value-json", help="Raw JSON literal to assign at the JSON path")

    request_header = add_subparsers.add_parser("request-header", help="Add or update a request header rule")
    request_header.add_argument("--name", required=True, help="Stable rule name")
    request_header.add_argument("--match-url", required=True, help="Substring or re: regex to match request URL")
    request_header.add_argument("--header-name", required=True, help="Request header name")
    request_header.add_argument("--header-value", required=True, help="Request header value")

    return parser


def parse_rules_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_rules_parser().parse_args(argv)


def emit_json(data) -> None:
    print(json.dumps(data, indent=2, sort_keys=True))


def _parser_actions(parser: argparse.ArgumentParser) -> list[argparse.Action]:
    return [action for action in parser._actions if not isinstance(action, argparse._HelpAction)]


def _option_metadata(parser: argparse.ArgumentParser) -> list[dict[str, Any]]:
    options: list[dict[str, Any]] = []
    for action in _parser_actions(parser):
        if not action.option_strings:
            continue
        if isinstance(action, argparse._SubParsersAction):
            continue
        options.append(
            {
                "flags": list(action.option_strings),
                "group": getattr(getattr(action, "container", None), "title", None),
                "metavar": action.metavar,
                "repeatable": isinstance(action, argparse._AppendAction),
                "legacy": any(flag in LEGACY_FLAG_ALIASES for flag in action.option_strings),
            }
        )
    return options


def _positionals_metadata(parser: argparse.ArgumentParser) -> list[dict[str, Any]]:
    positionals: list[dict[str, Any]] = []
    for action in _parser_actions(parser):
        if action.option_strings or isinstance(action, argparse._SubParsersAction):
            continue
        positionals.append({"name": action.dest, "metavar": action.metavar, "required": action.required})
    return positionals


def _subparser(parser: argparse.ArgumentParser, name: str) -> argparse.ArgumentParser:
    for action in _parser_actions(parser):
        if isinstance(action, argparse._SubParsersAction):
            return action.choices[name]
    raise KeyError(name)


def _capability_parser(kind: str) -> argparse.ArgumentParser | None:
    if kind == "run":
        return build_run_parser()
    if kind == "record":
        return build_record_parser()
    if kind == "replay":
        return build_replay_parser()
    if kind == "scenario_run":
        return _subparser(build_scenario_parser(), "run")
    if kind == "status":
        return build_status_parser()
    if kind == "cert_status":
        return _subparser(build_cert_parser(), "status")
    if kind == "cert_trust_macos":
        return _subparser(build_cert_parser(), "trust-macos")
    if kind == "sims_list":
        return _subparser(build_sims_parser(), "list")
    if kind == "cleanup":
        return build_cleanup_parser()
    if kind == "sockets_send":
        return _subparser(build_sockets_parser(), "send")
    if kind == "streams_send":
        return _subparser(build_streams_parser(), "send")
    if kind == "capabilities":
        return build_capabilities_parser()
    return None


def cli_capabilities() -> dict[str, Any]:
    commands: list[dict[str, Any]] = []
    for spec in CAPABILITY_COMMANDS:
        command = {
            "path": spec["path"],
            "summary": spec["summary"],
            "outputs": spec.get("outputs", []),
        }
        parser_kind = spec.get("parser")
        parser = _capability_parser(parser_kind) if parser_kind else None
        if parser is not None:
            command["options"] = _option_metadata(parser)
            command["positionals"] = _positionals_metadata(parser)
        else:
            command["options"] = [
                {"flags": [flag], "group": None, "metavar": None, "repeatable": False, "legacy": False}
                for flag in spec.get("options", [])
            ]
            command["positionals"] = []
        commands.append(command)
    return {
        "version": __version__,
        "legacy_flat_mode": True,
        "commands": commands,
        "jsonl_record_types": JSONL_RECORD_TYPES,
    }


def parse_delay_rules(raw_rules: list[str]) -> list[dict[str, int | str]]:
    return _parse_delay_rules(raw_rules)


def parse_throttle_rules(raw_rules: list[str]) -> list[dict[str, int | str]]:
    return _parse_throttle_rules(raw_rules)


def parse_drop_connection_rules(raw_rules: list[str]) -> list[str]:
    return _parse_drop_connection_rules(raw_rules)


def parse_fail_rate_rules(raw_rules: list[str]) -> list[dict[str, int | str]]:
    return _parse_fail_rate_rules(raw_rules)
