"""Replay recorded WebSocket server messages into matching live flows."""

from __future__ import annotations

import json
import os
from collections.abc import Callable
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .filtering import build_matcher, load_merged_config
from .websocket_message_rules import _drop_message

ENV_WEBSOCKET_REPLAY_FILE = "JAALA_WEBSOCKET_REPLAY_FILE"
ENV_WEBSOCKET_REPLAY_PATTERN = "JAALA_WEBSOCKET_REPLAY_PATTERN"

_REPLAY_INJECTED_KEY = "jaala_websocket_replay_injected"
_REPLAY_LIVE_SERVER_DROPPED_KEY = "jaala_websocket_replay_live_server_dropped"


@dataclass(frozen=True, slots=True)
class RecordedWebSocketMessage:
    url: str
    text: str


@dataclass(slots=True)
class WebSocketReplaySet:
    messages: list[RecordedWebSocketMessage]
    matcher: Callable[[str], bool] | None = None

    def has_messages(self) -> bool:
        return bool(self.messages)

    def matches(self, flow) -> bool:
        url = getattr(getattr(flow, "request", None), "pretty_url", "")
        if self.matcher is not None:
            return self.matcher(url)
        return any(message.url == url for message in self.messages)

    def messages_for(self, flow) -> list[RecordedWebSocketMessage]:
        url = getattr(getattr(flow, "request", None), "pretty_url", "")
        if self.matcher is not None:
            return list(self.messages)
        return [message for message in self.messages if message.url == url]

    def should_inject_after(self, flow, message) -> bool:
        if not self.has_messages() or not getattr(message, "from_client", False):
            return False
        if getattr(message, "injected", False):
            return False
        metadata = _flow_metadata(flow)
        if metadata.get(_REPLAY_INJECTED_KEY):
            return False
        return self.matches(flow)

    def should_drop_live_server_message(self, flow, message) -> bool:
        if not self.has_messages() or getattr(message, "from_client", True):
            return False
        if getattr(message, "injected", False):
            return False
        metadata = _flow_metadata(flow)
        if not metadata.get(_REPLAY_INJECTED_KEY):
            return False
        return self.matches(flow)

    def mark_injected(self, flow, count: int) -> None:
        metadata = _flow_metadata(flow)
        metadata[_REPLAY_INJECTED_KEY] = True
        metadata["jaala_websocket_replay_injected_count"] = count

    def mark_live_server_dropped(self, flow, message) -> None:
        metadata = _flow_metadata(flow)
        metadata[_REPLAY_LIVE_SERVER_DROPPED_KEY] = True
        _drop_message(message)


def build_websocket_replay(
    *,
    replay_file: str | None = None,
    replay_pattern: str | None = None,
) -> WebSocketReplaySet:
    messages = load_websocket_replay_messages(replay_file)
    matcher = build_matcher(replay_pattern) if replay_pattern else None
    return WebSocketReplaySet(messages=messages, matcher=matcher)


def resolve_websocket_replay_settings(
    *,
    config_path: str | None = None,
    config_profile: str | None = None,
    env: Mapping[str, str] | None = None,
    replay_file: str | None = None,
    replay_pattern: str | None = None,
) -> dict[str, str]:
    env = env or os.environ
    data = load_merged_config(config_path or env.get("JAALA_CONFIG"), profile=config_profile)
    resolved: dict[str, str] = {}
    _maybe_set_string(resolved, "websocket_replay", data.get("websocket_replay"), config_path)
    _maybe_set_string(resolved, "websocket_replay_pattern", data.get("websocket_replay_pattern"), config_path)
    _maybe_set_string(resolved, "websocket_replay", env.get(ENV_WEBSOCKET_REPLAY_FILE), None)
    _maybe_set_string(resolved, "websocket_replay_pattern", env.get(ENV_WEBSOCKET_REPLAY_PATTERN), None)
    _maybe_set_string(resolved, "websocket_replay", replay_file, None)
    _maybe_set_string(resolved, "websocket_replay_pattern", replay_pattern, None)
    if "websocket_replay_pattern" in resolved:
        build_matcher(resolved["websocket_replay_pattern"])
    return resolved


def load_websocket_replay_messages(path: str | None) -> list[RecordedWebSocketMessage]:
    if not path:
        return []

    replay_path = Path(path)
    if not replay_path.is_file():
        raise ValueError(f"WebSocket replay file does not exist: {path}")

    messages: list[RecordedWebSocketMessage] = []
    with replay_path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                record = json.loads(stripped)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid WebSocket replay JSONL at line {line_number}: {exc}") from exc
            message = _recorded_message_from_record(record)
            if message is not None:
                messages.append(message)
    return messages


def inject_replay_messages(flow, messages: list[RecordedWebSocketMessage]) -> int:
    return inject_text_messages(flow, [message.text for message in messages])


def inject_text_messages(flow, messages: list[str]) -> int:
    if not messages:
        return 0

    injected = 0
    for message in messages:
        content = message.encode("utf-8")
        if _inject_with_mitmproxy(flow, content):
            injected += 1
        elif _append_injected_test_message(flow, content):
            injected += 1
    return injected


def _recorded_message_from_record(record: Any) -> RecordedWebSocketMessage | None:
    if not isinstance(record, dict):
        return None
    if record.get("type") != "websocket_message":
        return None
    if record.get("direction") != "server_to_client":
        return None
    if record.get("opcode") != "text":
        return None
    url = record.get("url")
    message = record.get("message")
    if not isinstance(url, str) or not isinstance(message, dict):
        return None
    text = message.get("text")
    if not isinstance(text, str):
        return None
    return RecordedWebSocketMessage(url=url, text=text)


def _maybe_set_string(result: dict[str, str], key: str, value: Any, path: str | None) -> None:
    if value is None:
        return
    if not isinstance(value, str):
        location = f" {path!r}" if path else ""
        raise ValueError(f"WebSocket replay config{location} field {key!r} must be a string")
    normalized = value.strip()
    if normalized:
        result[key] = normalized


def _inject_with_mitmproxy(flow, content: bytes) -> bool:
    try:
        from mitmproxy import ctx  # type: ignore
    except Exception:
        return False
    try:
        ctx.master.commands.call("inject.websocket", flow, True, content, True)
    except Exception:
        return False
    return True


def _append_injected_test_message(flow, content: bytes) -> bool:
    websocket = getattr(flow, "websocket", None)
    messages = getattr(websocket, "messages", None)
    if messages is None:
        return False
    try:
        from types import SimpleNamespace

        messages.append(
            SimpleNamespace(
                from_client=False,
                is_text=True,
                text=content.decode("utf-8"),
                content=content,
                injected=True,
            )
        )
    except Exception:
        return False
    return True


def _flow_metadata(flow) -> dict:
    metadata = getattr(flow, "metadata", None)
    if metadata is None:
        metadata = {}
        flow.metadata = metadata
    return metadata
