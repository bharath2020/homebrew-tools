"""Tests for mitmproxy certificate generation and macOS trust helpers."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from jaala.certs import (
    CA_CERT_PEM,
    MITMPROXY_DIR,
    ensure_ca_cert,
    get_ca_cert_status,
    is_ca_cert_trusted_in_macos,
    trust_ca_cert_in_macos,
)


class TestConstants:
    def test_mitmproxy_dir_is_in_home(self):
        assert MITMPROXY_DIR == Path.home() / ".mitmproxy"

    def test_ca_cert_is_pem_in_mitmproxy_dir(self):
        assert CA_CERT_PEM == MITMPROXY_DIR / "mitmproxy-ca-cert.pem"


class TestEnsureCaCert:
    def test_returns_existing_cert_immediately(self, tmp_path):
        cert = tmp_path / "mitmproxy-ca-cert.pem"
        cert.write_text("fake cert")
        with patch("jaala.certs.CA_CERT_PEM", cert):
            assert ensure_ca_cert() == cert

    def test_generates_cert_via_mitmdump(self, tmp_path):
        cert = tmp_path / "mitmproxy-ca-cert.pem"
        mock_proc = MagicMock()
        mock_proc.terminate = MagicMock()
        mock_proc.wait = MagicMock()

        def create_cert(_seconds):
            cert.write_text("generated cert")

        with patch("jaala.certs.CA_CERT_PEM", cert), \
                patch("jaala.certs.subprocess.Popen", return_value=mock_proc) as mock_popen, \
                patch("jaala.certs.time.sleep", side_effect=create_cert):
            result = ensure_ca_cert()

        assert result == cert
        mock_popen.assert_called_once_with(
            ["mitmdump", "--listen-port", "0"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )


class TestTrust:
    @patch("jaala.certs.subprocess.run")
    def test_is_ca_cert_trusted_returns_true_on_success(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        assert is_ca_cert_trusted_in_macos("/tmp/mitm.pem") is True

    @patch("jaala.certs.subprocess.run")
    def test_is_ca_cert_trusted_returns_false_on_failure(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        assert is_ca_cert_trusted_in_macos("/tmp/mitm.pem") is False

    @patch("jaala.certs.is_ca_cert_trusted_in_macos", return_value=True)
    def test_get_ca_cert_status_ready(self, mock_trusted, tmp_path):
        cert = tmp_path / "mitmproxy-ca-cert.pem"
        cert.write_text("fake cert")

        status = get_ca_cert_status(cert)

        assert status == {
            "path": str(cert),
            "exists": True,
            "trusted_in_macos": True,
            "ready": True,
        }

    @patch("jaala.certs.is_ca_cert_trusted_in_macos")
    def test_get_ca_cert_status_missing_cert(self, mock_trusted, tmp_path):
        cert = tmp_path / "missing.pem"

        status = get_ca_cert_status(cert)

        assert status == {
            "path": str(cert),
            "exists": False,
            "trusted_in_macos": False,
            "ready": False,
        }
        mock_trusted.assert_not_called()

    @patch("jaala.certs.is_ca_cert_trusted_in_macos", return_value=False)
    @patch("jaala.certs.subprocess.run")
    def test_trust_ca_cert_invokes_sudo_security(self, mock_run, mock_trusted, capsys):
        trust_ca_cert_in_macos("/tmp/mitm.pem", quiet=False)
        mock_run.assert_called_once()
        assert "sudo may prompt" in capsys.readouterr().out

    @patch("jaala.certs.is_ca_cert_trusted_in_macos", return_value=True)
    @patch("jaala.certs.subprocess.run")
    def test_trust_ca_cert_skips_when_trusted(self, mock_run, mock_trusted, capsys):
        trust_ca_cert_in_macos("/tmp/mitm.pem")
        mock_run.assert_not_called()
        assert "already present" in capsys.readouterr().out

    @patch("jaala.certs.is_ca_cert_trusted_in_macos", return_value=False)
    @patch("jaala.certs.subprocess.run", side_effect=subprocess.CalledProcessError(1, "sudo"))
    def test_trust_ca_cert_exits_on_failure(self, mock_run, mock_trusted):
        with pytest.raises(SystemExit) as excinfo:
            trust_ca_cert_in_macos("/tmp/mitm.pem", quiet=True)
        assert excinfo.value.code == 1
