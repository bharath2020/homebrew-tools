"""Command-line parsing for Jaala."""

from __future__ import annotations

import argparse
import json

from . import __version__
from .network_conditions import (
    parse_delay_rules as _parse_delay_rules,
    parse_drop_connection_rules as _parse_drop_connection_rules,
    parse_fail_rate_rules as _parse_fail_rate_rules,
    parse_throttle_rules as _parse_throttle_rules,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="jaala",
        description="Capture iOS Simulator traffic for Jaala workflows.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--list-sims", action="store_true", help="List available simulators and exit")
    parser.add_argument(
        "--sim",
        metavar="UDID",
        default=None,
        help="Simulator UDID to use (default: first booted simulator)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=0,
        help="Proxy listen port (default: auto-select free port)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print each captured flow as JSON Lines",
    )
    parser.add_argument(
        "--json-file",
        metavar="FILE",
        default=None,
        help="Write captured flows as JSON Lines to FILE",
    )
    parser.add_argument(
        "--save-har",
        metavar="FILE",
        default=None,
        help="Save captured flows to a HAR file on exit",
    )
    parser.add_argument(
        "--no-headers",
        action="store_true",
        help="Hide request and response headers in console and JSON output",
    )
    parser.add_argument(
        "--no-body",
        action="store_true",
        help="Hide request and response bodies in console and JSON output",
    )
    parser.add_argument(
        "--no-websockets",
        action="store_true",
        help="Disable WebSocket capture and JSONL output",
    )
    parser.add_argument(
        "--output",
        "-o",
        metavar="FILE",
        default=None,
        help="Write raw mitmproxy flow data to FILE",
    )
    parser.add_argument(
        "--config",
        metavar="FILE",
        default=None,
        help="Load Jaala settings from JSON FILE",
    )
    parser.add_argument(
        "--profile",
        metavar="NAME",
        default=None,
        help="Select a named config profile from --config for scenario-style reuse",
    )
    parser.add_argument(
        "--filter",
        metavar="PATTERN",
        default=None,
        help="Only capture flows whose URL matches PATTERN",
    )
    parser.add_argument(
        "--filter-user-agent",
        metavar="PATTERN",
        default=None,
        help="Only capture flows whose User-Agent matches PATTERN",
    )
    parser.add_argument(
        "--map-local",
        metavar="PATTERN=FILE",
        default=None,
        help="Serve FILE as the response body for matching URLs",
    )
    parser.add_argument(
        "--map-remote",
        metavar="PATTERN=URL",
        default=None,
        help="Fetch URL and use it as the response for matching URLs",
    )
    parser.add_argument(
        "--status-code",
        metavar="PATTERN=CODE",
        default=None,
        help="Override the response status code for matching URLs",
    )
    parser.add_argument(
        "--add-header",
        metavar="PATTERN=NAME:VALUE",
        default=None,
        help="Add a response header for matching URLs",
    )
    parser.add_argument(
        "--body-replace",
        metavar="PATTERN=SEARCH>>>REPLACE",
        default=None,
        help="Replace response body text for matching URLs",
    )
    parser.add_argument(
        "--request-header",
        metavar="PATTERN=NAME:VALUE",
        default=None,
        help="Add a request header for matching URLs",
    )
    parser.add_argument(
        "--request-body-replace",
        metavar="PATTERN=SEARCH>>>REPLACE",
        default=None,
        help="Replace request body text for matching URLs",
    )
    parser.add_argument(
        "--websocket-message-replace",
        metavar="PATTERN=SEARCH>>>REPLACE",
        default=None,
        help="Replace WebSocket message text for matching URLs",
    )
    parser.add_argument(
        "--websocket-drop-message",
        action="append",
        default=[],
        metavar="PATTERN",
        help="Drop WebSocket messages for matching URLs",
    )
    parser.add_argument(
        "--websocket-fail-rate",
        action="append",
        default=[],
        metavar="PATTERN=PERCENT",
        help="Drop WebSocket messages randomly at the given percentage",
    )
    parser.add_argument(
        "--websocket-delay",
        action="append",
        default=[],
        metavar="PATTERN=MS",
        help="Add artificial latency to WebSocket messages for matching URLs",
    )
    parser.add_argument(
        "--websocket-throttle",
        action="append",
        default=[],
        metavar="PATTERN=KBPS",
        help="Delay WebSocket messages based on payload size and throughput",
    )
    parser.add_argument(
        "--websocket-replay",
        metavar="FILE",
        default=None,
        help="Replay recorded server-to-client WebSocket text messages from a JSONL capture file",
    )
    parser.add_argument(
        "--websocket-replay-pattern",
        metavar="PATTERN",
        default=None,
        help="Replay all recorded WebSocket server messages into live flows matching PATTERN",
    )
    parser.add_argument(
        "--delay",
        action="append",
        default=None,
        metavar="PATTERN=MS",
        help="Add artificial latency in milliseconds for matching URLs",
    )
    parser.add_argument(
        "--throttle",
        action="append",
        default=None,
        metavar="PATTERN=KBPS",
        help="Limit response throughput in kilobytes per second for matching URLs",
    )
    parser.add_argument(
        "--drop-connection",
        action="append",
        default=None,
        metavar="PATTERN",
        help="Drop matching requests before a response is created",
    )
    parser.add_argument(
        "--fail-rate",
        action="append",
        default=None,
        metavar="PATTERN=PERCENT",
        help="Drop matching requests randomly at the given percentage",
    )
    parser.add_argument(
        "--network-service",
        default=None,
        help="macOS network service to proxy (default: auto-detect active service)",
    )
    parser.add_argument(
        "--cleanup",
        action="store_true",
        help="Restore proxy settings from a previous crashed session and exit",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        help="Inspect proxy/session/certificate readiness and exit",
    )
    parser.add_argument(
        "--status-json",
        action="store_true",
        help="Print readiness status as JSON and exit",
    )
    parser.add_argument(
        "--probe-cert-readiness",
        action="store_true",
        help="Resolve the simulator, probe cert readiness in its keychain, and exit",
    )
    parser.add_argument(
        "--probe-cert-readiness-json",
        action="store_true",
        help="Print simulator cert readiness probe results as JSON and exit",
    )
    parser.add_argument(
        "--trust-macos-cert",
        action="store_true",
        help="Trust the Jaala CA in the macOS System keychain using sudo",
    )
    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument("--quiet", "-q", action="store_true", help="Suppress startup and shutdown messages")
    verbosity.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose rule reload and mutation debug logging",
    )
    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    args = build_parser().parse_args(argv)
    args.delay = args.delay or []
    args.throttle = args.throttle or []
    args.drop_connection = args.drop_connection or []
    args.fail_rate = args.fail_rate or []
    return args


def _add_common_run_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--sim", metavar="UDID", default=None, help="Simulator UDID to use")
    parser.add_argument("--port", type=int, default=0, help="Proxy listen port")
    parser.add_argument("--filter", metavar="PATTERN", default=None, help="Only capture matching URLs")
    parser.add_argument("--filter-user-agent", metavar="PATTERN", default=None, help="Only capture matching User-Agent traffic")
    parser.add_argument("--json-file", metavar="FILE", default=None, help="Write captured flows as JSON Lines to FILE")
    parser.add_argument("--save-har", metavar="FILE", default=None, help="Save captured flows to a HAR file on exit")
    parser.add_argument("--config", metavar="FILE", default=None, help="Load Jaala settings from JSON FILE")
    parser.add_argument("--profile", metavar="NAME", default=None, help="Select a named config profile")
    parser.add_argument("--quiet", "-q", action="store_true", help="Suppress startup and shutdown messages")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")


def build_record_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala record", description="Record Simulator traffic into agent-readable artifacts.")
    _add_common_run_options(parser)
    parser.add_argument("--json", action="store_true", help="Print each captured flow as JSON Lines")
    return parser


def build_replay_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala replay", description="Replay captured artifacts into a live Jaala session.")
    parser.add_argument("capture", help="JSONL capture file to replay")
    _add_common_run_options(parser)
    parser.add_argument("--websocket-pattern", metavar="PATTERN", default=None, help="Replay WebSocket server messages into live flows matching PATTERN")
    return parser


def build_scenario_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala scenario", description="Run agent-authored Jaala scenarios.")
    subparsers = parser.add_subparsers(dest="scenario_command", required=True)
    run_parser = subparsers.add_parser("run", help="Run a scenario JSON file")
    run_parser.add_argument("scenario_file", help="Scenario JSON file")
    _add_common_run_options(run_parser)
    return parser


def build_sockets_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala sockets", description="Control WebSocket events in the active Jaala session.")
    subparsers = parser.add_subparsers(dest="sockets_command", required=True)
    send_parser = subparsers.add_parser("send", help="Send a server-to-client text event on matching open WebSockets")
    send_parser.add_argument("--json", action="store_true", dest="json_output", help="Print command output as JSON")
    send_parser.add_argument("--match-url", required=True, help="Substring or re: regex to match WebSocket URL")
    send_parser.add_argument("--text", help="Text payload to send")
    send_parser.add_argument("--text-file", help="Read text payload from FILE")
    send_parser.add_argument("--drop-live-server-messages", action="store_true", help="Drop later live server messages for matching sockets")
    send_parser.add_argument("--id", default=None, help="Stable event id")
    return parser


def build_streams_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala streams", description="Control HTTP stream events in the active Jaala session.")
    subparsers = parser.add_subparsers(dest="streams_command", required=True)
    send_parser = subparsers.add_parser("send", help="Send a chunk on matching open HTTP streams")
    send_parser.add_argument("--json", action="store_true", dest="json_output", help="Print command output as JSON")
    send_parser.add_argument("--match-url", required=True, help="Substring or re: regex to match stream URL")
    send_parser.add_argument("--text", help="Raw chunk text to send")
    send_parser.add_argument("--text-file", help="Read raw chunk text from FILE")
    send_parser.add_argument("--event", help="SSE event name; formats --data-json or --data as an SSE event")
    send_parser.add_argument("--data", help="SSE data text")
    send_parser.add_argument("--data-json", help="SSE data JSON literal")
    send_parser.add_argument("--id", default=None, help="Stable event id")
    return parser


def parse_record_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_record_parser().parse_args(argv)


def parse_replay_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_replay_parser().parse_args(argv)


def parse_scenario_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_scenario_parser().parse_args(argv)


def parse_sockets_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_sockets_parser().parse_args(argv)


def parse_streams_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_streams_parser().parse_args(argv)


def build_rules_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jaala rules", description="Inspect and update active Jaala runtime rules.")
    parser.add_argument("--json", action="store_true", dest="json_output", help="Print rules output as JSON")
    subparsers = parser.add_subparsers(dest="rules_command", required=True)

    subparsers.add_parser("show", help="Show active runtime rules")
    subparsers.add_parser("status", help="Show runtime reload status")

    enable_parser = subparsers.add_parser("enable", help="Enable a runtime rule by name")
    enable_parser.add_argument("--name", required=True, help="Stable rule name")

    disable_parser = subparsers.add_parser("disable", help="Disable a runtime rule by name")
    disable_parser.add_argument("--name", required=True, help="Stable rule name")

    remove_parser = subparsers.add_parser("remove", help="Remove a runtime rule by name")
    remove_parser.add_argument("--name", required=True, help="Stable rule name")

    add_parser = subparsers.add_parser("add", help="Add or update a runtime rule")
    add_subparsers = add_parser.add_subparsers(dest="rule_type", required=True)

    body_replace = add_subparsers.add_parser("body-replace", help="Add or update a body replacement rule")
    body_replace.add_argument("--name", required=True, help="Stable rule name")
    body_replace.add_argument("--match-url", required=True, help="Substring or re: regex to match request URL")
    body_replace.add_argument("--search", required=True, help="Text to replace in matching response bodies")
    body_replace.add_argument("--replace", required=True, help="Replacement text")

    json_replace = add_subparsers.add_parser("json-replace", help="Add or update a JSON path replacement rule")
    json_replace.add_argument("--name", required=True, help="Stable rule name")
    json_replace.add_argument("--match-url", required=True, help="Substring or re: regex to match request URL")
    json_replace.add_argument("--json-path", required=True, help="Dot-separated JSON path, with '*' allowed for wildcards")
    json_replace_value = json_replace.add_mutually_exclusive_group(required=True)
    json_replace_value.add_argument("--value-string", help="String value to assign at the JSON path")
    json_replace_value.add_argument("--value-json", help="Raw JSON literal to assign at the JSON path")

    request_header = add_subparsers.add_parser("request-header", help="Add or update a request header rule")
    request_header.add_argument("--name", required=True, help="Stable rule name")
    request_header.add_argument("--match-url", required=True, help="Substring or re: regex to match request URL")
    request_header.add_argument("--header-name", required=True, help="Request header name")
    request_header.add_argument("--header-value", required=True, help="Request header value")

    return parser


def parse_rules_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_rules_parser().parse_args(argv)


def emit_json(data) -> None:
    print(json.dumps(data, indent=2, sort_keys=True))


def parse_delay_rules(raw_rules: list[str]) -> list[dict[str, int | str]]:
    return _parse_delay_rules(raw_rules)


def parse_throttle_rules(raw_rules: list[str]) -> list[dict[str, int | str]]:
    return _parse_throttle_rules(raw_rules)


def parse_drop_connection_rules(raw_rules: list[str]) -> list[str]:
    return _parse_drop_connection_rules(raw_rules)


def parse_fail_rate_rules(raw_rules: list[str]) -> list[dict[str, int | str]]:
    return _parse_fail_rate_rules(raw_rules)
