from __future__ import annotations

import json
import gzip
import os
from types import SimpleNamespace
from unittest.mock import patch

from jaala.addon import JaalaAddon
from jaala.runtime_rules import write_runtime_config
from jaala.response_rules import _set_text_body

from .test_addon import make_flow


def write_config(tmp_path, data):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps(data), encoding="utf-8")
    return config_path


def test_response_text_replace_mutates_matching_response_body(tmp_path):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=hello>>>world"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_body=b"hello from Jaala")
    addon.response(flow)

    assert flow.response.content == b"world from Jaala"


def test_response_text_replace_accepts_config_array_and_applies_matching_rule(tmp_path):
    config_path = write_config(
        tmp_path,
        {
            "response_text_replace": [
                "api.example.com=hello>>>world",
                "cdn.example.com=foo>>>bar",
            ]
        },
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    api_flow = make_flow(url="https://api.example.com/data", resp_body=b"hello from Jaala")
    cdn_flow = make_flow(url="https://cdn.example.com/data", resp_body=b"foo from Jaala")

    addon.response(api_flow)
    addon.response(cdn_flow)

    assert api_flow.response.content == b"world from Jaala"
    assert cdn_flow.response.content == b"bar from Jaala"


def test_response_text_replace_config_array_can_chain_rules_on_same_response(tmp_path):
    config_path = write_config(
        tmp_path,
        {
            "response_text_replace": [
                "api.example.com=hello>>>world",
                "api.example.com=world>>>JAALA",
            ]
        },
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(url="https://api.example.com/data", resp_body=b"hello from Jaala")
    addon.response(flow)

    assert flow.response.content == b"JAALA from Jaala"


def test_response_text_replace_drops_stale_encoding_headers_after_mutation(tmp_path):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=hello>>>world"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_body=b"hello from Jaala")
    flow.response.headers["content-encoding"] = "gzip"
    flow.response.headers["etag"] = "W/test"
    addon.response(flow)

    assert gzip.decompress(flow.response.content) == b"world from Jaala"
    assert flow.response.headers.get("content-encoding") == "gzip"
    assert "etag" not in flow.response.headers


def test_response_text_replace_drops_representation_specific_headers_after_mutation(tmp_path):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=hello>>>world"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_body=b"hello from Jaala")
    flow.response.headers["Accept-Ranges"] = "bytes"
    flow.response.headers["Content-Encoding"] = "br"
    flow.response.headers["Content-MD5"] = "deadbeef"
    flow.response.headers["Content-Range"] = "bytes 0-15/16"
    flow.response.headers["Digest"] = "sha-256=abc123"
    flow.response.headers["Last-Modified"] = "Mon, 13 Apr 2026 22:00:00 GMT"
    flow.response.headers["Content-Length"] = "999"
    addon.response(flow)

    assert flow.response.content == b"world from Jaala"
    assert flow.response.headers.get("content-length") == str(len(flow.response.content))
    assert "Accept-Ranges" not in flow.response.headers
    assert "Content-Encoding" not in flow.response.headers
    assert "Content-MD5" not in flow.response.headers
    assert "Content-Range" not in flow.response.headers
    assert "Digest" not in flow.response.headers
    assert "Last-Modified" not in flow.response.headers


def test_response_text_replace_decodes_gzip_encoded_json_before_mutation(tmp_path):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=American artificial intelligence company>>>JAALA DEMO"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_body=gzip.compress(b'{\"description\":\"American artificial intelligence company\"}'))
    flow.response.headers["Content-Encoding"] = "gzip"
    flow.response.headers["Content-Type"] = "application/json; charset=utf-8"
    addon.response(flow)

    assert gzip.decompress(flow.response.content) == b'{\"description\":\"JAALA DEMO\"}'
    assert flow.response.headers.get("Content-Encoding") == "gzip"
    assert flow.response.headers.get("content-length") == str(len(flow.response.content))
    assert flow.response.content.startswith(b"\x1f\x8b")


def test_set_text_body_falls_back_when_text_setter_does_not_update_content():
    response = SimpleNamespace(content=b"hello", text=None)

    content = _set_text_body(response, "world")

    assert content == b"world"
    assert response.content == b"world"


def test_set_raw_body_prefers_raw_content_when_available():
    response = SimpleNamespace(content=b"hello", raw_content=b"hello")

    from jaala.response_rules import _set_raw_body

    content = _set_raw_body(response, b"world")

    assert content == b"world"
    assert response.raw_content == b"world"


def test_response_text_replace_request_preserves_conditional_cache_headers_and_warns(tmp_path):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=hello>>>world"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        req_headers={
            "Host": "api.example.com",
            "User-Agent": "JaalaSample/1.0",
            "If-None-Match": 'W/"cached-etag"',
            "If-Modified-Since": "Mon, 13 Apr 2026 22:00:00 GMT",
        }
    )
    flow.response = None

    addon.request(flow)

    assert flow.request.headers.get("if-none-match") == 'W/"cached-etag"'
    assert flow.request.headers.get("if-modified-since") == "Mon, 13 Apr 2026 22:00:00 GMT"


def test_response_text_replace_request_keeps_conditional_cache_headers_for_non_matching_url(tmp_path):
    config_path = write_config(tmp_path, {"response_text_replace": "api.example.com=hello>>>world"})
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://other.example.com/data",
        req_headers={
            "Host": "other.example.com",
            "User-Agent": "JaalaSample/1.0",
            "If-None-Match": 'W/"cached-etag"',
        },
    )
    flow.response = None

    addon.request(flow)

    assert flow.request.headers.get("if-none-match") == 'W/"cached-etag"'


def test_runtime_response_text_replace_matches_url_patterns_containing_equals(tmp_path):
    config_path = tmp_path / "jaala.json"
    write_runtime_config(
        config_path,
        {
            "_jaala_runtime": {
                "rules": [
                    {
                        "name": "wiki-places-demo",
                        "type": "response_text_replace",
                        "enabled": True,
                        "match_url": "generator=search",
                        "search": "Union Square, San Francisco",
                        "replace": "JAALA PLACES DEMO",
                    }
                ]
            }
        },
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=nearcoord:5021m,37.786,-122.406",
        resp_body=b'{"title":"Union Square, San Francisco"}',
    )
    addon.response(flow)

    assert flow.response.content == b'{"title":"JAALA PLACES DEMO"}'


def test_runtime_json_replace_updates_nested_json_path(tmp_path):
    config_path = tmp_path / "jaala.json"
    write_runtime_config(
        config_path,
        {
            "_jaala_runtime": {
                "rules": [
                    {
                        "name": "wiki-featured-description",
                        "type": "json_replace",
                        "enabled": True,
                        "match_url": "feed/featured",
                        "json_path": "tfa.description",
                        "value": "JAALA JSON DEMO",
                    }
                ]
            }
        },
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/api/rest_v1/feed/featured/2026/04/14",
        resp_body=b'{"tfa":{"description":"Original featured description"}}',
    )
    flow.response.headers["Content-Type"] = "application/json; charset=utf-8"
    addon.response(flow)

    assert flow.response.content == b'{"tfa":{"description":"JAALA JSON DEMO"}}'


def test_runtime_json_replace_supports_wildcards_in_path(tmp_path):
    config_path = tmp_path / "jaala.json"
    write_runtime_config(
        config_path,
        {
            "_jaala_runtime": {
                "rules": [
                    {
                        "name": "wiki-search-description",
                        "type": "json_replace",
                        "enabled": True,
                        "match_url": "prefixsearch",
                        "json_path": "query.pages.*.description",
                        "value": "JAALA SEARCH JSON DEMO",
                    }
                ]
            }
        },
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/w/api.php?action=query&generator=prefixsearch&gpssearch=Anthropic",
        resp_body=(
            b'{"query":{"pages":{"1":{"description":"First"},"2":{"description":"Second"}}}}'
        ),
    )
    flow.response.headers["Content-Type"] = "application/json; charset=utf-8"
    addon.response(flow)

    assert flow.response.content == (
        b'{"query":{"pages":{"1":{"description":"JAALA SEARCH JSON DEMO"},'
        b'"2":{"description":"JAALA SEARCH JSON DEMO"}}}}'
    )


def test_startup_json_replace_updates_nested_json_path_from_config(tmp_path):
    config_path = write_config(
        tmp_path,
        {
            "json_replace": {
                "match_url": "feed/featured",
                "json_path": "tfa.description",
                "value": "JAALA STARTUP JSON DEMO",
            }
        },
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/api/rest_v1/feed/featured/2026/04/14",
        resp_body=b'{"tfa":{"description":"Original featured description"}}',
    )
    flow.response.headers["Content-Type"] = "application/json; charset=utf-8"
    addon.response(flow)

    assert flow.response.content == b'{"tfa":{"description":"JAALA STARTUP JSON DEMO"}}'


def test_runtime_json_replace_overrides_startup_json_replace(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "json_replace": {
                    "match_url": "feed/featured",
                    "json_path": "tfa.description",
                    "value": "STARTUP VALUE",
                },
                "_jaala_runtime": {
                    "rules": [
                        {
                            "name": "wiki-featured-description",
                            "type": "json_replace",
                            "enabled": True,
                            "match_url": "feed/featured",
                            "json_path": "tfa.description",
                            "value": "RUNTIME VALUE",
                        }
                    ]
                },
            }
        ),
        encoding="utf-8",
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(
        url="https://en.wikipedia.org/api/rest_v1/feed/featured/2026/04/14",
        resp_body=b'{"tfa":{"description":"Original featured description"}}',
    )
    flow.response.headers["Content-Type"] = "application/json; charset=utf-8"
    addon.response(flow)

    assert flow.response.content == b'{"tfa":{"description":"RUNTIME VALUE"}}'
