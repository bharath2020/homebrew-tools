#!/usr/bin/env bash
# validate-features-axe.sh - Demonstrate each Jaala feature family with AXe.

set -uo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

PASS=0
FAIL=0
FEATURE_CASES="${JAALA_FEATURE_CASES:-all}"

APP_BUNDLE_ID="com.jaala.sample"
APP_PROJECT="$ROOT_DIR/sample-app/JaalaSample.xcodeproj"
APP_SCHEME="JaalaSample"
APP_DERIVED_DATA="$ROOT_DIR/sample-app/build"
APP_BINARY="$APP_DERIVED_DATA/Build/Products/Debug-iphonesimulator/JaalaSample.app"

FILTER_PORT=8901
FILTER_UA_PORT=8902
JSON_FILE_PORT=8903
SAVE_HAR_PORT=8904
MAP_LOCAL_PORT=8905
MAP_REMOTE_PORT=8906
STATUS_CODE_PORT=8907
ADD_HEADER_PORT=8908
BODY_REPLACE_PORT=8909
REQUEST_HEADER_PORT=8910
REQUEST_BODY_PORT=8911
DELAY_PORT=8912
THROTTLE_PORT=8913
DROP_PORT=8914
FAIL_RATE_PORT=8915
JSON_REPLACE_PORT=8916
PROFILE_PORT=8917

JAAALA_PID=""
SCENARIO_SERVER_PID=""
SIM_NAME=""
SIM_UDID=""
NETWORK_SERVICE=""

OUTPUT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/jaala-features-XXXXXX")"
JAAALA_LOG=""
JSONL_FILE=""
HAR_FILE=""
PROXY_BEFORE_HTTP=""
PROXY_BEFORE_HTTPS=""
PROXY_AFTER_HTTP=""
PROXY_AFTER_HTTPS=""

cleanup() {
    if [[ -n "${SIM_UDID:-}" ]]; then
        xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
    fi

    if [[ -n "${JAAALA_PID:-}" ]] && kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        kill -TERM "$JAAALA_PID" >/dev/null 2>&1 || true
        for _ in {1..30}; do
            if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
        if kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
            kill -KILL "$JAAALA_PID" >/dev/null 2>&1 || true
        fi
        wait "$JAAALA_PID" >/dev/null 2>&1 || true
    fi

    if [[ -n "${SCENARIO_SERVER_PID:-}" ]] && kill -0 "$SCENARIO_SERVER_PID" >/dev/null 2>&1; then
        kill -TERM "$SCENARIO_SERVER_PID" >/dev/null 2>&1 || true
        for _ in {1..20}; do
            if ! kill -0 "$SCENARIO_SERVER_PID" >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
        if kill -0 "$SCENARIO_SERVER_PID" >/dev/null 2>&1; then
            kill -KILL "$SCENARIO_SERVER_PID" >/dev/null 2>&1 || true
        fi
        wait "$SCENARIO_SERVER_PID" >/dev/null 2>&1 || true
    fi

    if [[ -f "$HOME/.jaala/session.lock" ]]; then
        python3 -m jaala --cleanup >/dev/null 2>&1 || true
    fi
}

trap cleanup EXIT INT TERM

check() {
    local desc="$1"
    local result="${2:-false}"
    if [[ "$result" == "true" ]]; then
        echo -e "  ${GREEN}✓${NC} $desc"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}✗${NC} $desc"
        FAIL=$((FAIL + 1))
    fi
}

require_cmd() {
    local cmd="$1"
    if command -v "$cmd" >/dev/null 2>&1; then
        check "$cmd is installed" "true"
    else
        check "$cmd is installed" "false"
        exit 1
    fi
}

detect_active_service() {
    local service
    for service in "Wi-Fi" "Ethernet" "USB 10/100/1000 LAN"; do
        if networksetup -getinfo "$service" 2>/dev/null | grep -Fq "IP address"; then
            printf '%s' "$service"
            return 0
        fi
    done

    while IFS= read -r service; do
        service="${service#\*}"
        service="${service# }"
        service="${service% }"
        [[ -z "$service" ]] && continue
        if networksetup -getinfo "$service" 2>/dev/null | grep -Fq "IP address"; then
            printf '%s' "$service"
            return 0
        fi
    done < <(networksetup -listallnetworkservices 2>/dev/null | tail -n +2)

    return 1
}

capture_proxy_state() {
    networksetup -getwebproxy "$NETWORK_SERVICE" >"$PROXY_BEFORE_HTTP"
    networksetup -getsecurewebproxy "$NETWORK_SERVICE" >"$PROXY_BEFORE_HTTPS"
}

capture_proxy_state_after() {
    networksetup -getwebproxy "$NETWORK_SERVICE" >"$PROXY_AFTER_HTTP"
    networksetup -getsecurewebproxy "$NETWORK_SERVICE" >"$PROXY_AFTER_HTTPS"
}

wait_for_port() {
    local port="$1"
    local timeout_seconds="$2"
    python3 - "$port" "$timeout_seconds" <<'PY'
import socket
import sys
import time

port = int(sys.argv[1])
timeout = float(sys.argv[2])
deadline = time.monotonic() + timeout

while time.monotonic() < deadline:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.2):
            sys.exit(0)
    except OSError:
        time.sleep(0.1)

sys.exit(1)
PY
}

simulator_value() {
    local field="$1"
    printf '%s' "$SIM_JSON" | python3 -c '
import json
import sys

field = sys.argv[1]
data = json.load(sys.stdin)
for devices in data.get("devices", {}).values():
    for device in devices:
        if device.get("state") == "Booted":
            print(device.get(field, ""))
            raise SystemExit(0)
print("")
' "$field"
}

axe_wait_for_text() {
    local text="$1"
    local timeout_ms="$2"
    local deadline=$(( $(date +%s) + (timeout_ms + 999) / 1000 ))
    local ui

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        ui=$(axe describe-ui --udid "$SIM_UDID" 2>/dev/null || true)
        if printf '%s' "$ui" | grep -Fq "$text"; then
            return 0
        fi
        sleep 1
    done

    echo -e "  ${YELLOW}Last AXe UI snapshot did not contain: ${text}${NC}"
    return 1
}

axe_tap_label() {
    local label="$1"
    local timeout_ms="${2:-30000}"
    if ! axe_wait_for_text "$label" "$timeout_ms"; then
        return 1
    fi
    axe tap --label "$label" --udid "$SIM_UDID" >/dev/null
}

wait_for_result_label() {
    local label="$1"
    local timeout_ms="$2"

    if axe_wait_for_text "$label" "$timeout_ms"; then
        return 0
    fi

    local uppercase_label="${label/Results/RESULTS}"
    if [[ "$uppercase_label" != "$label" ]] && axe_wait_for_text "$uppercase_label" "$timeout_ms"; then
        return 0
    fi

    return 1
}

start_jaala() {
    local port="$1"
    shift
    JAAALA_PID=""
    python3 -m jaala \
        --quiet \
        --port "$port" \
        --json-file "$JSONL_FILE" \
        --save-har "$HAR_FILE" \
        "$@" \
        >"$JAAALA_LOG" 2>&1 &
    JAAALA_PID=$!

    if ! wait_for_port "$port" 30; then
        echo -e "${RED}Jaala did not start listening on port ${port}.${NC}"
        sed -n '1,220p' "$JAAALA_LOG"
        stop_jaala
        JAAALA_PID=""
        return 1
    fi

    if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        echo -e "${RED}Jaala exited before validation could start.${NC}"
        sed -n '1,220p' "$JAAALA_LOG"
        stop_jaala
        JAAALA_PID=""
        return 1
    fi

    return 0
}

stop_jaala() {
    if [[ -n "${JAAALA_PID:-}" ]] && kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        kill -TERM "$JAAALA_PID" >/dev/null 2>&1 || true
        for _ in {1..30}; do
            if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
        if kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
            echo -e "${RED}Jaala did not exit cleanly after SIGTERM.${NC}"
            return 1
        fi
        wait "$JAAALA_PID" >/dev/null 2>&1 || true
    fi
    return 0
}

start_remote_server() {
    local directory="$1"
    local port="$2"
    python3 -m http.server --bind 127.0.0.1 "$port" --directory "$directory" >/dev/null 2>&1 &
    SCENARIO_SERVER_PID=$!
    if ! wait_for_port "$port" 15; then
        echo -e "${RED}Local HTTP server did not start on port ${port}.${NC}"
        if kill -0 "$SCENARIO_SERVER_PID" >/dev/null 2>&1; then
            kill -TERM "$SCENARIO_SERVER_PID" >/dev/null 2>&1 || true
            wait "$SCENARIO_SERVER_PID" >/dev/null 2>&1 || true
        fi
        SCENARIO_SERVER_PID=""
        return 1
    fi
    return 0
}

stop_remote_server() {
    if [[ -n "${SCENARIO_SERVER_PID:-}" ]] && kill -0 "$SCENARIO_SERVER_PID" >/dev/null 2>&1; then
        kill -TERM "$SCENARIO_SERVER_PID" >/dev/null 2>&1 || true
        for _ in {1..20}; do
            if ! kill -0 "$SCENARIO_SERVER_PID" >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
        if kill -0 "$SCENARIO_SERVER_PID" >/dev/null 2>&1; then
            kill -KILL "$SCENARIO_SERVER_PID" >/dev/null 2>&1 || true
        fi
        wait "$SCENARIO_SERVER_PID" >/dev/null 2>&1 || true
    fi
    SCENARIO_SERVER_PID=""
}

launch_app() {
    local result_label="$1"
    : "${result_label:=}"
    xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
    if ! xcrun simctl launch "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null; then
        echo -e "${RED}Sample app failed to launch.${NC}"
        return 1
    fi
    if ! axe_wait_for_text "Run full capture matrix: expect 6 results" 30000; then
        return 1
    fi
    return 0
}

tap_and_wait() {
    local label="$1"
    local result_label="$2"
    local timeout_ms="${3:-60000}"
    if ! axe_tap_label "$label"; then
        return 1
    fi
    if ! wait_for_result_label "$result_label" "$timeout_ms"; then
        return 1
    fi
    return 0
}

assert_jsonl_count() {
    local file="$1"
    local expected="$2"
    python3 - "$file" "$expected" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected = int(sys.argv[2])
lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
records = [json.loads(line) for line in lines]
if len(records) != expected:
    raise SystemExit(f"JSONL captured {len(records)} records, expected {expected}")
PY
}

assert_jsonl_min_count() {
    local file="$1"
    local expected_min="$2"
    python3 - "$file" "$expected_min" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected_min = int(sys.argv[2])
lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
records = [json.loads(line) for line in lines]
if len(records) < expected_min:
    raise SystemExit(f"JSONL captured {len(records)} records, expected at least {expected_min}")
PY
}

assert_har_count_and_creator() {
    local file="$1"
    local expected="$2"
    python3 - "$file" "$expected" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected = int(sys.argv[2])
data = json.loads(path.read_text(encoding="utf-8"))
entries = data.get("log", {}).get("entries", [])
if data.get("log", {}).get("creator", {}).get("name") != "jaala":
    raise SystemExit("HAR creator name was not jaala")
if len(entries) != expected:
    raise SystemExit(f"HAR captured {len(entries)} entries, expected {expected}")
PY
}

assert_jsonl_urls() {
    local file="$1"
    shift
    python3 - "$file" "$@" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected = sys.argv[2:]
records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
urls = [record["url"] for record in records]
if set(urls) != set(expected):
    missing = sorted(set(expected) - set(urls))
    extra = sorted(set(urls) - set(expected))
    raise SystemExit(
        "JSONL URLs did not match expected sample traffic"
        + (f"; missing={missing}" if missing else "")
        + (f"; extra={extra}" if extra else "")
    )
PY
}

assert_jsonl_contains_urls() {
    local file="$1"
    shift
    python3 - "$file" "$@" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected = sys.argv[2:]
records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
urls = {record.get("url") for record in records}
missing = sorted(set(expected) - urls)
if missing:
    raise SystemExit(f"JSONL did not contain expected URLs: {missing}")
PY
}

assert_har_urls() {
    local file="$1"
    shift
    python3 - "$file" "$@" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected = sys.argv[2:]
data = json.loads(path.read_text(encoding="utf-8"))
entries = data.get("log", {}).get("entries", [])
urls = [entry.get("request", {}).get("url") for entry in entries]
if set(urls) != set(expected):
    missing = sorted(set(expected) - set(urls))
    extra = sorted(set(urls) - set(expected))
    raise SystemExit(
        "HAR URLs did not match expected sample traffic"
        + (f"; missing={missing}" if missing else "")
        + (f"; extra={extra}" if extra else "")
    )
PY
}

assert_har_contains_urls() {
    local file="$1"
    shift
    python3 - "$file" "$@" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected = sys.argv[2:]
data = json.loads(path.read_text(encoding="utf-8"))
entries = data.get("log", {}).get("entries", [])
if data.get("log", {}).get("creator", {}).get("name") != "jaala":
    raise SystemExit("HAR creator name was not jaala")
urls = {entry.get("request", {}).get("url") for entry in entries}
missing = sorted(set(expected) - urls)
if missing:
    raise SystemExit(f"HAR did not contain expected URLs: {missing}")
PY
}

assert_jsonl_response_status() {
    local file="$1"
    local expected="$2"
    python3 - "$file" "$expected" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected = int(sys.argv[2])
records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
if not records:
    raise SystemExit("JSONL did not contain any records")
for record in records:
    if record.get("status") == expected:
        sys.exit(0)
statuses = [record.get("status") for record in records]
raise SystemExit(f"JSONL statuses were {statuses}, expected to include {expected}")
PY
}

assert_jsonl_status() {
    assert_jsonl_response_status "$@"
}

assert_har_status() {
    local file="$1"
    local expected="$2"
    python3 - "$file" "$expected" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
expected = int(sys.argv[2])
data = json.loads(path.read_text(encoding="utf-8"))
entries = data.get("log", {}).get("entries", [])
if not entries:
    raise SystemExit("HAR did not contain any entries")
for entry in entries:
    if entry.get("response", {}).get("status") == expected:
        sys.exit(0)
statuses = [entry.get("response", {}).get("status") for entry in entries]
raise SystemExit(f"HAR statuses were {statuses}, expected to include {expected}")
PY
}

assert_jsonl_header() {
    local file="$1"
    local section="$2"
    local name="$3"
    local value="$4"
    python3 - "$file" "$section" "$name" "$value" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
section = sys.argv[2]
name = sys.argv[3].lower()
value = sys.argv[4]
records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
if not records:
    raise SystemExit("JSONL did not contain any records")
for record in records:
    headers = record.get(section, {}).get("headers", {})
    for key, header_value in headers.items():
        if key.lower() == name and header_value == value:
            sys.exit(0)
raise SystemExit(f"JSONL {section} headers did not contain {name}: {value}")
PY
}

assert_har_header() {
    local file="$1"
    local section="$2"
    local name="$3"
    local value="$4"
    python3 - "$file" "$section" "$name" "$value" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
section = sys.argv[2]
name = sys.argv[3].lower()
value = sys.argv[4]
data = json.loads(path.read_text(encoding="utf-8"))
entries = data.get("log", {}).get("entries", [])
if not entries:
    raise SystemExit("HAR did not contain any entries")
for entry in entries:
    headers = entry.get(section, {}).get("headers", [])
    for header in headers:
        if header.get("name", "").lower() == name and header.get("value") == value:
            sys.exit(0)
raise SystemExit(f"HAR {section} headers did not contain {name}: {value}")
PY
}

assert_jsonl_body_contains() {
    local file="$1"
    local section="$2"
    local needle="$3"
    python3 - "$file" "$section" "$needle" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
section = sys.argv[2]
needle = sys.argv[3]
records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
if not records:
    raise SystemExit("JSONL did not contain any records")
for record in records:
    body = record.get(section, {}).get("body")
    if body is None:
        continue
    if isinstance(body, (dict, list)):
        rendered = json.dumps(body, ensure_ascii=False)
    else:
        rendered = str(body)
    if needle in rendered:
        break
else:
    raise SystemExit(f"JSONL {section} body did not contain {needle!r}")
PY
}

assert_har_body_contains() {
    local file="$1"
    local section="$2"
    local needle="$3"
    python3 - "$file" "$section" "$needle" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
section = sys.argv[2]
needle = sys.argv[3]
data = json.loads(path.read_text(encoding="utf-8"))
entries = data.get("log", {}).get("entries", [])
if not entries:
    raise SystemExit("HAR did not contain any entries")
for entry in entries:
    if section == "request":
        body = entry.get(section, {}).get("postData", {}).get("text")
    else:
        body = entry.get(section, {}).get("content", {}).get("text")
    if body is not None and needle in str(body):
        break
else:
    raise SystemExit(f"HAR {section} body did not contain {needle!r}")
PY
}

assert_jsonl_count_zero() {
    local file="$1"
    python3 - "$file" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
if lines:
    raise SystemExit(f"JSONL captured {len(lines)} records, expected 0")
PY
}

assert_har_count_zero() {
    local file="$1"
    python3 - "$file" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
data = json.loads(path.read_text(encoding="utf-8"))
entries = data.get("log", {}).get("entries", [])
if entries:
    raise SystemExit(f"HAR captured {len(entries)} entries, expected 0")
PY
}

assert_jsonl_missing_url() {
    local file="$1"
    local url="$2"
    python3 - "$file" "$url" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
url = sys.argv[2]
if not path.exists():
    sys.exit(0)
records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
if any(record.get("url") == url for record in records):
    raise SystemExit(f"JSONL contained dropped URL {url}")
PY
}

assert_har_missing_url() {
    local file="$1"
    local url="$2"
    python3 - "$file" "$url" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
url = sys.argv[2]
if not path.exists():
    sys.exit(0)
data = json.loads(path.read_text(encoding="utf-8"))
entries = data.get("log", {}).get("entries", [])
if any(entry.get("request", {}).get("url") == url for entry in entries):
    raise SystemExit(f"HAR contained dropped URL {url}")
PY
}

assert_proxy_restored() {
    if cmp -s "$PROXY_BEFORE_HTTP" "$PROXY_AFTER_HTTP" && cmp -s "$PROXY_BEFORE_HTTPS" "$PROXY_AFTER_HTTPS"; then
        check "Host proxy settings are restored" "true"
    else
        check "Host proxy settings are restored" "false"
    fi
}

record_assert() {
    local desc="$1"
    shift
    if "$@"; then
        check "$desc" "true"
    else
        check "$desc" "false"
    fi
}

should_run_case() {
    local case_name="$1"
    if [[ "$FEATURE_CASES" == "all" ]]; then
        return 0
    fi

    local normalized=",$FEATURE_CASES,"
    [[ "$normalized" == *",$case_name,"* ]]
}

run_selected_case() {
    local case_name="$1"
    local case_runner="$2"

    if should_run_case "$case_name"; then
        "$case_runner"
    fi
}

prepare_case() {
    local name="$1"
    local port="$2"
    shift 2
    local case_dir="$OUTPUT_DIR/$name"
    mkdir -p "$case_dir"
    JAAALA_LOG="$case_dir/jaala.log"
    JSONL_FILE="$case_dir/traffic.jsonl"
    HAR_FILE="$case_dir/traffic.har"
    PROXY_BEFORE_HTTP="$case_dir/proxy-before-http.txt"
    PROXY_BEFORE_HTTPS="$case_dir/proxy-before-https.txt"
    PROXY_AFTER_HTTP="$case_dir/proxy-after-http.txt"
    PROXY_AFTER_HTTPS="$case_dir/proxy-after-https.txt"
    capture_proxy_state
    if ! start_jaala "$port" "$@"; then
        return 1
    fi
    return 0
}

finish_case() {
    local expect_proxy_restore="${1:-true}"
    if ! stop_jaala; then
        return 1
    fi
    stop_remote_server
    capture_proxy_state_after
    if [[ "$expect_proxy_restore" == "true" ]]; then
        assert_proxy_restored
    fi
    JAAALA_PID=""
    return 0
}

run_filter_case() {
    local url_1="https://httpbin.org/json"
    local url_2="https://httpbin.org/post"
    local url_3="https://jsonplaceholder.typicode.com/todos/1"
    if ! prepare_case "filter" "$FILTER_PORT" --filter 're:httpbin\.org|jsonplaceholder\.typicode\.com'; then
        check "Filter scenario starts Jaala" "false"
        return
    fi
    check "Filter scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "Filter scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Run full capture matrix: expect 6 results" "Results (6)" 60000; then
        check "Filter scenario runs all sample requests" "false"
        finish_case
        return
    fi
    check "Filter scenario runs all sample requests" "true"
    if ! finish_case; then
        check "Filter scenario cleans up Jaala" "false"
        return
    fi
    record_assert "--filter captures only matching URLs" assert_jsonl_count "$JSONL_FILE" 3
    record_assert "--filter saves a HAR subset" assert_har_count_and_creator "$HAR_FILE" 3
    record_assert "--filter JSONL URLs match the subset" assert_jsonl_urls "$JSONL_FILE" "$url_1" "$url_2" "$url_3"
    record_assert "--filter HAR URLs match the subset" assert_har_urls "$HAR_FILE" "$url_1" "$url_2" "$url_3"
}

run_filter_user_agent_case() {
    if ! prepare_case "filter-user-agent" "$FILTER_UA_PORT" --filter-user-agent "JaalaSample/1.0"; then
        check "Filter-User-Agent scenario starts Jaala" "false"
        return
    fi
    check "Filter-User-Agent scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "Filter-User-Agent scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--filter-user-agent matches the sample app request" "false"
        finish_case
        return
    fi
    check "--filter-user-agent matches the sample app request" "true"
    finish_case
    record_assert "--filter-user-agent captures one request" assert_jsonl_count "$JSONL_FILE" 1
    record_assert "--filter-user-agent writes a HAR entry" assert_har_count_and_creator "$HAR_FILE" 1
}

run_json_file_case() {
    if ! prepare_case "json-file" "$JSON_FILE_PORT"; then
        check "--json-file scenario starts Jaala" "false"
        return
    fi
    check "--json-file scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--json-file scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--json-file captures one request" "false"
        finish_case
        return
    fi
    check "--json-file captures one request" "true"
    finish_case
    record_assert "--json-file writes JSONL capture output" assert_jsonl_contains_urls "$JSONL_FILE" "https://httpbin.org/json"
    record_assert "--json-file writes a matching HAR entry" assert_har_contains_urls "$HAR_FILE" "https://httpbin.org/json"
}

run_save_har_case() {
    if ! prepare_case "save-har" "$SAVE_HAR_PORT"; then
        check "--save-har scenario starts Jaala" "false"
        return
    fi
    check "--save-har scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--save-har scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--save-har captures one request" "false"
        finish_case
        return
    fi
    check "--save-har captures one request" "true"
    finish_case
    record_assert "--save-har writes a HAR file" assert_har_contains_urls "$HAR_FILE" "https://httpbin.org/json"
}

run_map_local_case() {
    local case_dir="$OUTPUT_DIR/map-local"
    mkdir -p "$case_dir"
    local fixture="$case_dir/map-local.json"
    cat >"$fixture" <<'EOF'
{
  "message": "map-local-fixture",
  "source": "local"
}
EOF
    if ! prepare_case "map-local" "$MAP_LOCAL_PORT" --map-local "httpbin.org/json=$fixture"; then
        check "--map-local scenario starts Jaala" "false"
        return
    fi
    check "--map-local scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--map-local scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--map-local captures the mapped response" "false"
        finish_case
        return
    fi
    check "--map-local captures the mapped response" "true"
    finish_case
    record_assert "--map-local writes the expected JSONL status" assert_jsonl_response_status "$JSONL_FILE" 200
    record_assert "--map-local writes the expected HAR status" assert_har_status "$HAR_FILE" 200
    record_assert "--map-local writes the local fixture to JSONL" assert_jsonl_body_contains "$JSONL_FILE" response "map-local-fixture"
    record_assert "--map-local writes the local fixture to HAR" assert_har_body_contains "$HAR_FILE" response "map-local-fixture"
}

run_map_remote_case() {
    local case_dir="$OUTPUT_DIR/map-remote"
    mkdir -p "$case_dir"
    local remote_fixture="$case_dir/remote.json"
    cat >"$remote_fixture" <<'EOF'
{
  "message": "map-remote-fixture",
  "source": "local-file"
}
EOF
    local remote_url
    remote_url="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve().as_uri())' "$remote_fixture")"
    if ! prepare_case "map-remote" "$MAP_REMOTE_PORT" --map-remote "httpbin.org/json=$remote_url"; then
        check "--map-remote scenario starts Jaala" "false"
        return
    fi
    check "--map-remote scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--map-remote scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--map-remote captures the remote response" "false"
        finish_case
        return
    fi
    check "--map-remote captures the remote response" "true"
    finish_case
    record_assert "--map-remote writes the expected JSONL status" assert_jsonl_response_status "$JSONL_FILE" 200
    record_assert "--map-remote writes the expected HAR status" assert_har_status "$HAR_FILE" 200
    record_assert "--map-remote writes the remote fixture to JSONL" assert_jsonl_body_contains "$JSONL_FILE" response "map-remote-fixture"
    record_assert "--map-remote writes the remote fixture to HAR" assert_har_body_contains "$HAR_FILE" response "map-remote-fixture"
}

run_status_code_case() {
    local case_dir="$OUTPUT_DIR/status-code"
    mkdir -p "$case_dir"
    local fixture="$case_dir/status.json"
    cat >"$fixture" <<'EOF'
{
  "message": "status-code-fixture"
}
EOF
    if ! prepare_case "status-code" "$STATUS_CODE_PORT" --map-local "httpbin.org/json=$fixture" --status-code "httpbin.org/json=503"; then
        check "--status-code scenario starts Jaala" "false"
        return
    fi
    check "--status-code scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--status-code scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--status-code mutates the response" "false"
        finish_case
        return
    fi
    check "--status-code mutates the response" "true"
    finish_case
    record_assert "--status-code overrides the JSONL status" assert_jsonl_status "$JSONL_FILE" 503
    record_assert "--status-code overrides the HAR status" assert_har_status "$HAR_FILE" 503
}

run_add_header_case() {
    local case_dir="$OUTPUT_DIR/add-header"
    mkdir -p "$case_dir"
    local fixture="$case_dir/header.json"
    cat >"$fixture" <<'EOF'
{
  "message": "add-header-fixture"
}
EOF
    if ! prepare_case "add-header" "$ADD_HEADER_PORT" --map-local "httpbin.org/json=$fixture" --add-header "httpbin.org/json=X-Jaala-Scenario:added"; then
        check "--add-header scenario starts Jaala" "false"
        return
    fi
    check "--add-header scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--add-header scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--add-header mutates the response headers" "false"
        finish_case
        return
    fi
    check "--add-header mutates the response headers" "true"
    finish_case
    record_assert "--add-header writes the response header to JSONL" assert_jsonl_header "$JSONL_FILE" response "X-Jaala-Scenario" "added"
    record_assert "--add-header writes the response header to HAR" assert_har_header "$HAR_FILE" response "X-Jaala-Scenario" "added"
}

run_body_replace_case() {
    local case_dir="$OUTPUT_DIR/body-replace"
    mkdir -p "$case_dir"
    local fixture="$case_dir/body.json"
    cat >"$fixture" <<'EOF'
{
  "message": "replace-me",
  "detail": "body replace fixture"
}
EOF
    if ! prepare_case "body-replace" "$BODY_REPLACE_PORT" --map-local "httpbin.org/json=$fixture" --body-replace "httpbin.org/json=replace-me>>>replaced-ok"; then
        check "--body-replace scenario starts Jaala" "false"
        return
    fi
    check "--body-replace scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--body-replace scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--body-replace mutates the response body" "false"
        finish_case
        return
    fi
    check "--body-replace mutates the response body" "true"
    finish_case
    record_assert "--body-replace writes the modified body to JSONL" assert_jsonl_body_contains "$JSONL_FILE" response "replaced-ok"
    record_assert "--body-replace writes the modified body to HAR" assert_har_body_contains "$HAR_FILE" response "replaced-ok"
}

run_json_replace_case() {
    local case_dir="$OUTPUT_DIR/json-replace"
    mkdir -p "$case_dir"
    local fixture="$case_dir/json-replace.json"
    local config="$case_dir/jaala.json"
    cat >"$fixture" <<'EOF'
{
  "message": "replace-me",
  "detail": "json replace fixture"
}
EOF
    cat >"$config" <<EOF
{
  "map_local": "httpbin.org/json=$fixture",
  "json_replace": {
    "match_url": "httpbin.org/json",
    "json_path": "message",
    "value": "JAALA STARTUP JSON DEMO"
  }
}
EOF
    if ! prepare_case "json-replace" "$JSON_REPLACE_PORT" --config "$config"; then
        check "--config json_replace scenario starts Jaala" "false"
        return
    fi
    check "--config json_replace scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--config json_replace scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--config json_replace captures the JSON response" "false"
        finish_case
        return
    fi
    check "--config json_replace reaches the sample app through AXe-driven flow" "true"
    finish_case
    record_assert "--config json_replace writes the modified body to JSONL" assert_jsonl_body_contains "$JSONL_FILE" response "JAALA STARTUP JSON DEMO"
    record_assert "--config json_replace writes the modified body to HAR" assert_har_body_contains "$HAR_FILE" response "JAALA STARTUP JSON DEMO"
}

run_request_header_case() {
    local case_dir="$OUTPUT_DIR/request-header"
    mkdir -p "$case_dir"
    local fixture="$case_dir/request-header.json"
    cat >"$fixture" <<'EOF'
{
  "message": "request-header-fixture"
}
EOF
    if ! prepare_case "request-header" "$REQUEST_HEADER_PORT" --map-local "httpbin.org/post=$fixture" --request-header "httpbin.org/post=X-Jaala-Request:yes"; then
        check "--request-header scenario starts Jaala" "false"
        return
    fi
    check "--request-header scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--request-header scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Request mutation: expect POST JSON" "Results (1)" 30000; then
        check "--request-header mutates the request headers" "false"
        finish_case
        return
    fi
    check "--request-header mutates the request headers" "true"
    finish_case
    record_assert "--request-header writes the request header to JSONL" assert_jsonl_header "$JSONL_FILE" request "X-Jaala-Request" "yes"
    record_assert "--request-header writes the request header to HAR" assert_har_header "$HAR_FILE" request "X-Jaala-Request" "yes"
}

run_request_body_replace_case() {
    local case_dir="$OUTPUT_DIR/request-body"
    mkdir -p "$case_dir"
    local fixture="$case_dir/request-body.json"
    cat >"$fixture" <<'EOF'
{
  "message": "request-body-fixture"
}
EOF
    if ! prepare_case "request-body" "$REQUEST_BODY_PORT" --map-local "httpbin.org/post=$fixture" --request-body-replace "httpbin.org/post=hello from jaala sample>>>hello from jaala sample (rewritten)"; then
        check "--request-body-replace scenario starts Jaala" "false"
        return
    fi
    check "--request-body-replace scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--request-body-replace scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Request mutation: expect POST JSON" "Results (1)" 30000; then
        check "--request-body-replace mutates the request body" "false"
        finish_case
        return
    fi
    check "--request-body-replace mutates the request body" "true"
    finish_case
    record_assert "--request-body-replace writes the modified request body to JSONL" assert_jsonl_body_contains "$JSONL_FILE" request "rewritten"
    record_assert "--request-body-replace writes the modified request body to HAR" assert_har_body_contains "$HAR_FILE" request "rewritten"
}

run_delay_case() {
    local case_dir="$OUTPUT_DIR/delay"
    mkdir -p "$case_dir"
    local fixture="$case_dir/delay.json"
    cat >"$fixture" <<'EOF'
{
  "message": "delay-fixture"
}
EOF
    if ! prepare_case "delay" "$DELAY_PORT" --map-local "httpbin.org/json=$fixture" --delay "httpbin.org/json=1500"; then
        check "--delay scenario starts Jaala" "false"
        return
    fi
    check "--delay scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--delay scenario launches the sample app" "false"
        finish_case
        return
    fi
    local start_ms end_ms elapsed_ms
    start_ms=$(python3 - <<'PY'
import time
print(int(time.time() * 1000))
PY
)
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--delay delays the response" "false"
        finish_case
        return
    fi
    end_ms=$(python3 - <<'PY'
import time
print(int(time.time() * 1000))
PY
)
    elapsed_ms=$((end_ms - start_ms))
    check "--delay delays the response" "true"
    finish_case
    record_assert "--delay writes the expected JSONL status" assert_jsonl_response_status "$JSONL_FILE" 200
    if [[ "$elapsed_ms" -ge 1200 ]]; then
        check "--delay adds visible latency (${elapsed_ms}ms)" "true"
    else
        check "--delay adds visible latency (${elapsed_ms}ms)" "false"
    fi
}

run_throttle_case() {
    local case_dir="$OUTPUT_DIR/throttle"
    mkdir -p "$case_dir"
    local fixture="$case_dir/throttle.txt"
    python3 - "$fixture" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
chunk = ("throttle-fixture-line\n" * 2048).encode("utf-8")
path.write_bytes(chunk)
PY
    if ! prepare_case "throttle" "$THROTTLE_PORT" --map-local "httpbin.org/json=$fixture" --throttle "httpbin.org/json=64"; then
        check "--throttle scenario starts Jaala" "false"
        return
    fi
    check "--throttle scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--throttle scenario launches the sample app" "false"
        finish_case
        return
    fi
    local start_ms end_ms elapsed_ms
    start_ms=$(python3 - <<'PY'
import time
print(int(time.time() * 1000))
PY
)
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 60000; then
        check "--throttle slows the response" "false"
        finish_case
        return
    fi
    end_ms=$(python3 - <<'PY'
import time
print(int(time.time() * 1000))
PY
)
    elapsed_ms=$((end_ms - start_ms))
    check "--throttle slows the response" "true"
    finish_case
    record_assert "--throttle writes JSONL capture output" assert_jsonl_min_count "$JSONL_FILE" 1
    record_assert "--throttle writes the throttled payload to JSONL" assert_jsonl_body_contains "$JSONL_FILE" response "throttle-fixture-line"
    if [[ "$elapsed_ms" -ge 1200 ]]; then
        check "--throttle adds visible transfer time (${elapsed_ms}ms)" "true"
    else
        check "--throttle adds visible transfer time (${elapsed_ms}ms)" "false"
    fi
}

run_drop_connection_case() {
    if ! prepare_case "drop-connection" "$DROP_PORT" --drop-connection "httpbin.org/json"; then
        check "--drop-connection scenario starts Jaala" "false"
        return
    fi
    check "--drop-connection scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--drop-connection scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--drop-connection drops the response" "false"
        finish_case
        return
    fi
    check "--drop-connection drops the response" "true"
    finish_case
    record_assert "--drop-connection leaves no JSONL capture artifacts" assert_jsonl_missing_url "$JSONL_FILE" "https://httpbin.org/json"
    record_assert "--drop-connection leaves no HAR capture artifacts" assert_har_missing_url "$HAR_FILE" "https://httpbin.org/json"
}

run_fail_rate_case() {
    if ! prepare_case "fail-rate" "$FAIL_RATE_PORT" --fail-rate "httpbin.org/json=100"; then
        check "--fail-rate scenario starts Jaala" "false"
        return
    fi
    check "--fail-rate scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--fail-rate scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--fail-rate drops the response" "false"
        finish_case
        return
    fi
    check "--fail-rate drops the response" "true"
    finish_case
    record_assert "--fail-rate leaves no JSONL capture artifacts" assert_jsonl_missing_url "$JSONL_FILE" "https://httpbin.org/json"
    record_assert "--fail-rate leaves no HAR capture artifacts" assert_har_missing_url "$HAR_FILE" "https://httpbin.org/json"
}

run_profile_case() {
    local case_dir="$OUTPUT_DIR/profile"
    mkdir -p "$case_dir"
    local base_fixture="$case_dir/base.json"
    local profile_fixture="$case_dir/profile.json"
    local config="$case_dir/jaala.json"
    cat >"$base_fixture" <<'EOF'
{
  "message": "base-profile-fixture",
  "source": "base"
}
EOF
    cat >"$profile_fixture" <<'EOF'
{
  "message": "named-profile-fixture",
  "source": "profile"
}
EOF
    cat >"$config" <<EOF
{
  "map_local": "httpbin.org/json=$base_fixture",
  "request_header": "httpbin.org/json=X-Jaala-Profile:base",
  "profiles": {
    "sample-profile": {
      "map_local": "httpbin.org/json=$profile_fixture",
      "request_header": "httpbin.org/json=X-Jaala-Profile:selected"
    }
  }
}
EOF
    if ! prepare_case "profile" "$PROFILE_PORT" --config "$config" --profile "sample-profile"; then
        check "--profile scenario starts Jaala" "false"
        return
    fi
    check "--profile scenario starts Jaala" "true"
    if ! launch_app "Results (0)"; then
        check "--profile scenario launches the sample app" "false"
        finish_case
        return
    fi
    if ! tap_and_wait "Capture JSON: expect 200 body" "Results (1)" 30000; then
        check "--profile drives the sample app through the named scenario" "false"
        finish_case
        return
    fi
    check "--profile drives the sample app through the named scenario" "true"
    finish_case
    record_assert "--profile writes the profile-selected fixture to JSONL" assert_jsonl_body_contains "$JSONL_FILE" response "named-profile-fixture"
    record_assert "--profile writes the profile-selected fixture to HAR" assert_har_body_contains "$HAR_FILE" response "named-profile-fixture"
    record_assert "--profile applies profile request-header override to JSONL" assert_jsonl_header "$JSONL_FILE" request "X-Jaala-Profile" "selected"
    record_assert "--profile applies profile request-header override to HAR" assert_har_header "$HAR_FILE" request "X-Jaala-Profile" "selected"
}

echo "========================================"
echo "  Jaala feature AXe validation"
echo "========================================"
echo ""

echo "Step 0: Checking prerequisites..."
require_cmd python3
require_cmd xcodebuild
require_cmd xcrun
require_cmd axe
require_cmd mitmdump
require_cmd curl

python3 -m jaala --cleanup >/dev/null 2>&1 || true

SIM_JSON=$(xcrun simctl list devices booted -j 2>/dev/null)
SIM_UDID=$(simulator_value udid)
SIM_NAME=$(simulator_value name)

if [[ -z "$SIM_UDID" ]]; then
    echo -e "${RED}No booted simulator found. Boot a simulator and retry.${NC}"
    exit 1
fi

NETWORK_SERVICE="$(detect_active_service)"
if [[ -z "$NETWORK_SERVICE" ]]; then
    echo -e "${RED}No active network service found.${NC}"
    exit 1
fi

echo -e "  Booted simulator: ${YELLOW}${SIM_NAME} (${SIM_UDID})${NC}"
echo -e "  Active network service: ${YELLOW}${NETWORK_SERVICE}${NC}"
echo ""

echo "Step 1: Building and installing the sample app..."
if xcodebuild \
    -project "$APP_PROJECT" \
    -scheme "$APP_SCHEME" \
    -configuration Debug \
    -sdk iphonesimulator \
    -derivedDataPath "$APP_DERIVED_DATA" \
    build >/tmp/jaala_features_xcodebuild_$$.log 2>&1; then
    check "Sample app builds for iOS Simulator" "true"
else
    check "Sample app builds for iOS Simulator" "false"
    echo ""
    echo "xcodebuild log:"
    sed -n '1,220p' "/tmp/jaala_features_xcodebuild_$$.log"
    exit 1
fi

if xcrun simctl install "$SIM_UDID" "$APP_BINARY" >/dev/null; then
    check "Sample app installs on the booted Simulator" "true"
else
    check "Sample app installs on the booted Simulator" "false"
    exit 1
fi
echo ""

run_selected_case filter run_filter_case
run_selected_case filter-user-agent run_filter_user_agent_case
run_selected_case json-file run_json_file_case
run_selected_case save-har run_save_har_case
run_selected_case map-local run_map_local_case
run_selected_case map-remote run_map_remote_case
run_selected_case status-code run_status_code_case
run_selected_case add-header run_add_header_case
run_selected_case body-replace run_body_replace_case
run_selected_case json-replace run_json_replace_case
run_selected_case request-header run_request_header_case
run_selected_case request-body-replace run_request_body_replace_case
run_selected_case delay run_delay_case
run_selected_case throttle run_throttle_case
run_selected_case drop-connection run_drop_connection_case
run_selected_case fail-rate run_fail_rate_case
run_selected_case profile run_profile_case

echo ""
echo "========================================"
echo -e "  Results: ${GREEN}$PASS passed${NC}, ${RED}$FAIL failed${NC}"
echo "========================================"

if [[ "$FAIL" -gt 0 ]]; then
    exit 1
fi

echo -e "${GREEN}All validations passed.${NC}"
