"""Session lock file management for crash recovery."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any


LOCK_DIR = Path.home() / ".jaala"
LOCK_FILE = LOCK_DIR / "session.lock"


def write_lock(
    pid: int,
    network_service: str,
    port: int,
    original_http: dict[str, str] | None,
    original_https: dict[str, str] | None,
    runtime_config_path: str | None = None,
    runtime_status_path: str | None = None,
) -> None:
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "pid": pid,
        "network_service": network_service,
        "port": port,
        "original_http": original_http,
        "original_https": original_https,
        "runtime_config_path": runtime_config_path,
        "runtime_status_path": runtime_status_path,
    }
    LOCK_FILE.write_text(json.dumps(payload))


def read_lock() -> dict | None:
    if not LOCK_FILE.exists():
        return None
    try:
        return json.loads(LOCK_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def remove_lock() -> None:
    try:
        LOCK_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def collect_session_status() -> dict[str, Any]:
    """Inspect the Jaala session lock and whether it blocks a new run."""
    lock = read_lock()
    if lock is None:
        return {
            "lock_present": False,
            "pid": None,
            "network_service": None,
            "port": None,
            "process_running": False,
            "stale": False,
            "blocking": False,
        }

    pid = lock.get("pid")
    running = bool(pid) and is_process_running(int(pid))
    stale = not running
    return {
        "lock_present": True,
        "pid": pid,
        "network_service": lock.get("network_service"),
        "port": lock.get("port"),
        "process_running": running,
        "stale": stale,
        "blocking": running or stale,
    }


def check_stale_session() -> None:
    status = collect_session_status()
    if not status["lock_present"]:
        return

    pid = status["pid"] or 0
    service = status["network_service"] or ""

    if status["process_running"]:
        print(
            f"Warning: Another Jaala session (PID {pid}) appears to be running.\n"
            f"If this is stale, run: jaala --cleanup",
            file=sys.stderr,
        )
        sys.exit(1)

    print(
        f"Warning: Found stale session lock (PID {pid} on '{service}').\n"
        f"Previous session may have crashed without restoring proxy settings.\n"
        f"Run: jaala --cleanup",
        file=sys.stderr,
    )
    sys.exit(1)


def do_cleanup() -> bool:
    from .network import ProxyConfig

    lock = read_lock()
    if lock is None:
        print("No stale session found. Proxy settings are clean.")
        return False

    pid = lock.get("pid", 0)
    service = lock.get("network_service", "")

    if is_process_running(pid):
        print(
            f"Session (PID {pid}) is still running. Stop it first or use kill {pid}.",
            file=sys.stderr,
        )
        return False

    proxy_config = ProxyConfig(port=0, service=service)
    proxy_config._original_http = lock.get("original_http")
    proxy_config._original_https = lock.get("original_https")
    proxy_config.disable()
    remove_lock()
    print("Cleanup complete. Proxy settings restored.")
    return True
