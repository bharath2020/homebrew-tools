# Jaala

Jaala is a Simulator-first network testing tool for iOS apps.

It records iOS Simulator traffic, exports JSONL and HAR capture artifacts, and
can simulate responses, request mutations, and network conditions for contract
and resilience testing.

## Requirements

- macOS with Xcode and iOS Simulator tools
- A booted iOS Simulator
- `mitmdump` from [mitmproxy](https://mitmproxy.org/)
- [`axe`](https://github.com/cameroncooke/AXe)

## Quick Start

```bash
python3 -m jaala run
python3 -m jaala record --json-file traffic.jsonl --save-har traffic.har --filter api.example.com
python3 -m jaala replay traffic.jsonl --websocket-pattern ws.example.com/socket
python3 -m jaala run --filter-user-agent JaalaSample/1.0 --json-file traffic.jsonl
python3 -m jaala run --delay api.example.com=1500 --fail-rate api.example.com=25
```

Jaala temporarily configures the macOS host HTTP and HTTPS proxy so real
Simulator app traffic routes through the local proxy. It restores the proxy
state when the session exits. A Simulator-local mode is intentionally not
provided; see
[`docs/simulator-only-investigation.md`](docs/simulator-only-investigation.md).

Legacy flat invocations still work, including `python3 -m jaala` and
`python3 -m jaala --filter api.example.com --json-file traffic.jsonl`. New
automation should prefer the command-shaped surface below.

| Task | Command |
| --- | --- |
| Start default capture | `python3 -m jaala run` |
| Record JSONL/HAR | `python3 -m jaala record --json-file traffic.jsonl --save-har traffic.har` |
| Mock a response body | `python3 -m jaala run --map-local api.example.com=fixture.json` |
| Add latency | `python3 -m jaala run --delay api.example.com=1500` |
| Replay WebSocket messages | `python3 -m jaala replay ws.jsonl --websocket-pattern /socket` |
| Send a live WebSocket event | `python3 -m jaala sockets send --match-url /socket --text '{"event":"ready"}'` |
| Send an SSE chunk | `python3 -m jaala streams send --match-url /events --event message --data-json '{"ok":true}'` |
| Inspect readiness | `python3 -m jaala status --json` |
| Inspect certificate readiness | `python3 -m jaala cert status --json` |
| List simulators | `python3 -m jaala sims list` |
| Cleanup proxy state | `python3 -m jaala cleanup` |
| Discover CLI metadata | `python3 -m jaala capabilities --json` |

## Core Options

| Option | Purpose |
| --- | --- |
| `--filter PATTERN` | Capture/display only matching URLs |
| `--filter-user-agent PATTERN` | Capture/display only matching User-Agent traffic |
| `--json`, `--json-file FILE` | Emit JSON Lines traffic data |
| `--save-har FILE` | Export a HAR file |
| `--map-local PATTERN=FILE` | Serve a local response for matching URLs |
| `--map-remote PATTERN=URL` | Redirect matching requests to another origin |
| `--status-code PATTERN=CODE` | Override response status |
| `--add-header PATTERN=NAME:VALUE` | Add or replace response headers |
| `--body-replace PATTERN=S>>>R` | Replace response body text |
| `--request-header PATTERN=NAME:VALUE` | Add or replace request headers |
| `--request-body-replace PATTERN=S>>>R` | Replace request body text |
| `--websocket-message-replace PATTERN=S>>>R` | Replace matching WebSocket text messages |
| `--websocket-replay FILE` | Inject recorded server WebSocket text messages from JSONL |
| `--websocket-replay-pattern PATTERN` | Replay recorded WebSocket messages into a different matching live URL |
| `--delay PATTERN=MS` | Add latency |
| `--throttle PATTERN=KBPS` | Throttle response delivery |
| `--drop-connection PATTERN` | Drop matching requests |
| `--fail-rate PATTERN=PERCENT` | Randomly drop a percentage of matching requests |

WebSocket messages are captured as `websocket_message` JSONL records. Recorded
server-to-client text messages can be replayed into a matching live WebSocket
with `--websocket-replay traffic.jsonl`; use `--websocket-replay-pattern` when
the replay target URL differs from the recorded URL. During replay Jaala injects
the recorded messages after the first matching client message and drops matching
live server messages to avoid duplicate upstream events.

Agents can queue one-shot runtime events into an active Jaala session:

```bash
python3 -m jaala sockets send \
  --match-url ws.example.com/socket \
  --text '{"event":"ready"}' \
  --drop-live-server-messages

python3 -m jaala streams send \
  --match-url api.example.com/events \
  --event message \
  --data-json '{"ok":true}'
```

`sockets send` injects a server-to-client text message into the next matching
open WebSocket flow observed by Jaala. `streams send` queues an SSE or raw text
chunk for matching HTTP streams as Jaala processes that open stream.

Server-streamed responses such as `text/event-stream`, chunked responses, and
newline-delimited JSON streams are captured as `http_stream_chunk` JSONL
records. Matching `--body-replace` rules are applied to streamed UTF-8 text as
chunks pass through the proxy.

## Validate

```bash
python3 -m pytest
./validate-axe.sh
./validate-features-axe.sh
./validate-websocket-axe.sh
./validate-streaming-axe.sh
JAALA_CLI_MODE=commands ./validate-axe.sh
JAALA_CLI_MODE=commands ./validate-features-axe.sh
JAALA_CLI_MODE=commands ./validate-websocket-axe.sh
JAALA_CLI_MODE=commands ./validate-streaming-axe.sh
```

The validation script builds the sample app, runs `python3 -m jaala`, drives
the app with AXe, and verifies the captured traffic and cleanup behavior.
`validate-features-axe.sh` runs shorter AXe-backed sessions to demonstrate the
individual option families.
`validate-streaming-axe.sh` runs a local HTTP streaming server, drives the
Simulator sample app, and verifies Jaala captures and mutates streamed chunks.
Set `JAALA_CLI_MODE=commands` to run the same harnesses through `jaala run`,
`jaala record`, `jaala replay`, and `jaala cleanup`.

## Wikipedia Demo Target

Jaala also pins the official Wikimedia iOS app as a submodule at
`demo-apps/wikipedia-ios` so the repo can demonstrate contract-style testing
against a real open-source client/server app without vendoring its source into
Jaala itself.

Initialize it after cloning Jaala:

```bash
git submodule update --init --recursive
```

The demo workflow is documented in
[`docs/wikipedia-demo.md`](docs/wikipedia-demo.md).

A runnable harness for the pinned app lives at
[`demo/wikipedia/README.md`](demo/wikipedia/README.md) and covers live record,
exact replay, delayed replay, and status-override replay.
