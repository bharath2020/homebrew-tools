# Agentic CLI API Assessment

This assessment reviews whether Jaala's CLI is a good control surface for agents
that need to record live traffic, replay or mock responses, and drive WebSocket
or HTTP streaming scenarios without depending on the original backend.

## Success Criteria

- Agents can record HTTP, WebSocket, and server-streamed traffic into stable,
  machine-readable artifacts.
- Agents can replay captured responses as deterministic fixtures.
- Agents can mock server responses without the original server.
- Agents can control event delivery while a WebSocket is open.
- Agents can control event delivery while an HTTP stream is open.
- Agents can inspect readiness, active rules, and reload status with
  machine-readable output.
- The CLI vocabulary is discoverable and maps cleanly to agent actions.

## Current Fit

Jaala is relevant for agentic workflows, but the current CLI is only partially
friendly for them.

The strongest surface today is capture. `--json`, `--json-file`, `--save-har`,
`--filter`, and `--filter-user-agent` give agents deterministic artifacts and a
way to narrow traffic. The JSONL record types are also useful: ordinary HTTP is
captured as `http`, WebSocket messages are captured as `websocket_message`, and
server streams are captured as `http_stream_chunk`.

The new WebSocket replay flags are useful but narrow. `--websocket-replay FILE`
and `--websocket-replay-pattern PATTERN` let an agent turn a recorded
server-to-client WebSocket text frame into a mocked server event on a later run.
That covers the "record then replay mocked socket response" demo path.

Runtime control now covers HTTP rules plus one-shot socket and stream events.
`jaala rules --json`, `jaala rules status --json`, `jaala sockets send`, and
`jaala streams send` give agents a machine-usable control plane while Jaala is
running.

## Requirement Coverage

| Requirement | Current support | Assessment |
| --- | --- | --- |
| Record traffic | `--json-file`, `--save-har`, JSONL records | Good fit |
| Replay HTTP responses | `--map-local`, `--map-remote`, `--status-code`, `--body-replace`, `--json-replace` | Useful, but not exposed as a first-class replay workflow |
| Replay WebSocket responses | `--websocket-replay`, `--websocket-replay-pattern` | Useful for server text messages after a live client frame |
| Mock without actual server | HTTP can use `--map-local`; WebSocket replay still needs a live socket flow | Incomplete |
| Control WebSocket event sending while open | `jaala sockets send --match-url ... --text ...` | Basic one-shot support |
| Control HTTP stream events while open | `jaala streams send --match-url ... --event ... --data-json ...` | Basic one-shot support while Jaala is processing the stream |
| Agent-readable status | `--status-json`, `--probe-cert-readiness-json`, `jaala rules --json`, `jaala rules status --json` | Good fit |
| Agent-friendly vocabulary | `record`, `replay`, `scenario run`, `sockets send`, and `streams send` exist | Improved, still needs richer scenario semantics |

## Design Gaps

The CLI has many capabilities, but agents need fewer, higher-level verbs.
`python3 -m jaala --json-file traffic.jsonl` works, but an agent would benefit
from an explicit `record` command that declares the artifact contract and exits
predictably after a condition or timeout.

WebSocket replay is tied to a live upstream socket. It injects recorded
server-to-client text messages only after the first matching client message.
That is enough for echo-style tests, but it does not let an agent fully replace
the backend or push arbitrary events whenever the app reaches a subscribed
state.

The runtime socket control plane is intentionally small. Once Jaala is running,
an agent can queue a one-shot server-to-client text event with `sockets send`.
The remaining gaps are listing open sockets, closing sockets, binary frames,
multi-message scripts, and stronger acknowledgements that a specific socket
received a specific event.

HTTP stream support captures, mutates chunks, and now queues runtime SSE or raw
text chunks with `streams send`. This is enough for many active-stream tests,
but Jaala still does not provide a complete synthetic stream server that can
open a response and hold it without upstream participation.

The replay artifact format is implicit JSONL. It is readable, but there is no
declared scenario format for agents to generate directly, such as a JSON file
containing routes, socket scripts, stream scripts, timing, matching rules, and
assertions.

## Recommended CLI Shape

Add first-class commands around agent workflows while keeping the existing flags
as lower-level compatibility primitives.

```bash
jaala record --json-file traffic.jsonl --filter api.example.com
jaala replay traffic.jsonl --websocket-pattern ws.example.com/socket
jaala scenario run scenario.json --json-file traffic.jsonl
```

Current runtime command for sockets:

```bash
jaala sockets send --match-url /socket --text '{"event":"ready"}'
```

Current runtime commands for HTTP streams:

```bash
jaala streams send --match-url /events --event message --data-json '{"ok":true}'
jaala streams send --match-url /events --text-file chunks.txt
```

Add a scenario format for deterministic tests:

```json
{
  "routes": [
    {
      "match_url": "api.example.com/profile",
      "response": {"status": 200, "body_file": "fixtures/profile.json"}
    }
  ],
  "websockets": [
    {
      "match_url": "/socket",
      "on_open": [
        {"send_text": "{\"event\":\"connected\"}"},
        {"wait_ms": 500},
        {"send_json": {"event": "updated"}}
      ],
      "drop_live_server_messages": true
    }
  ],
  "streams": [
    {
      "match_url": "/events",
      "content_type": "text/event-stream",
      "events": [
        {"event": "message", "data": {"step": 1}},
        {"event": "message", "data": {"step": 2}}
      ]
    }
  ]
}
```

## Implementation Priority

1. Add machine-readable discovery: `jaala capabilities --json` describing
   supported record types, rule types, runtime commands, and artifact schemas.
2. Extend runtime WebSocket commands to list open flows, send binary frames,
   queue multi-message scripts, and close sockets.
3. Extend stream injection into a full synthetic stream server for SSE and
   NDJSON.
4. Expand `scenario run` beyond config aliases into first-class scenario
   execution.
5. Publish JSON schemas for capture records and scenario files.

## Bottom Line

The current CLI is relevant for agentic testing and now supports record/replay
verbs plus one-shot runtime controls for WebSocket and HTTP stream events. It is
closer to agent-friendly, but a complete backend-free test platform still needs
socket/stream listing, close controls, multi-event scripts, stronger delivery
acknowledgements, and a richer scenario file format agents can write directly.
