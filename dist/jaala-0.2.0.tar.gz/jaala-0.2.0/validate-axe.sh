#!/usr/bin/env bash
# validate-axe.sh - Validate Jaala end to end with AXe and the sample app.

set -uo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

PASS=0
FAIL=0

APP_BUNDLE_ID="com.jaala.sample"
APP_PROJECT="$ROOT_DIR/sample-app/JaalaSample.xcodeproj"
APP_SCHEME="JaalaSample"
APP_DERIVED_DATA="$ROOT_DIR/sample-app/build"
APP_BINARY="$APP_DERIVED_DATA/Build/Products/Debug-iphonesimulator/JaalaSample.app"
JAAALA_PORT=8899
JAAALA_PID=""
OUTPUT_DIR="$(mktemp -d "${TMPDIR:-/tmp}/jaala-validate-XXXXXX")"
JAAALA_LOG="$OUTPUT_DIR/jaala.log"
JSONL_FILE="$OUTPUT_DIR/traffic.jsonl"
HAR_FILE="$OUTPUT_DIR/traffic.har"
PROXY_BEFORE_HTTP="$OUTPUT_DIR/proxy-before-http.txt"
PROXY_BEFORE_HTTPS="$OUTPUT_DIR/proxy-before-https.txt"
PROXY_AFTER_HTTP="$OUTPUT_DIR/proxy-after-http.txt"
PROXY_AFTER_HTTPS="$OUTPUT_DIR/proxy-after-https.txt"
SIM_NAME=""
SIM_UDID=""
NETWORK_SERVICE=""

cleanup() {
    if [[ -n "${SIM_UDID:-}" ]]; then
        xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
    fi

    if [[ -n "${JAAALA_PID:-}" ]] && kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        kill -TERM "$JAAALA_PID" >/dev/null 2>&1 || true
        for _ in {1..30}; do
            if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
        if kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
            kill -KILL "$JAAALA_PID" >/dev/null 2>&1 || true
        fi
        wait "$JAAALA_PID" >/dev/null 2>&1 || true
    fi

    if [[ -f "$HOME/.jaala/session.lock" ]]; then
        python3 -m jaala --cleanup >/dev/null 2>&1 || true
    fi
}

trap cleanup EXIT INT TERM

check() {
    local desc="$1"
    local result="${2:-false}"
    if [[ "$result" == "true" ]]; then
        echo -e "  ${GREEN}✓${NC} $desc"
        PASS=$((PASS + 1))
    else
        echo -e "  ${RED}✗${NC} $desc"
        FAIL=$((FAIL + 1))
    fi
}

require_cmd() {
    local cmd="$1"
    if command -v "$cmd" >/dev/null 2>&1; then
        check "$cmd is installed" "true"
    else
        check "$cmd is installed" "false"
        exit 1
    fi
}

detect_active_service() {
    local service
    for service in "Wi-Fi" "Ethernet" "USB 10/100/1000 LAN"; do
        if networksetup -getinfo "$service" 2>/dev/null | grep -Fq "IP address"; then
            printf '%s' "$service"
            return 0
        fi
    done

    while IFS= read -r service; do
        service="${service#\*}"
        service="${service# }"
        service="${service% }"
        [[ -z "$service" ]] && continue
        if networksetup -getinfo "$service" 2>/dev/null | grep -Fq "IP address"; then
            printf '%s' "$service"
            return 0
        fi
    done < <(networksetup -listallnetworkservices 2>/dev/null | tail -n +2)

    return 1
}

capture_proxy_state() {
    networksetup -getwebproxy "$NETWORK_SERVICE" >"$PROXY_BEFORE_HTTP"
    networksetup -getsecurewebproxy "$NETWORK_SERVICE" >"$PROXY_BEFORE_HTTPS"
}

capture_proxy_state_after() {
    networksetup -getwebproxy "$NETWORK_SERVICE" >"$PROXY_AFTER_HTTP"
    networksetup -getsecurewebproxy "$NETWORK_SERVICE" >"$PROXY_AFTER_HTTPS"
}

wait_for_port() {
    local port="$1"
    local timeout_seconds="$2"
    python3 - "$port" "$timeout_seconds" <<'PY'
import socket
import sys
import time

port = int(sys.argv[1])
timeout = float(sys.argv[2])
deadline = time.monotonic() + timeout

while time.monotonic() < deadline:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.2):
            sys.exit(0)
    except OSError:
        time.sleep(0.1)

sys.exit(1)
PY
}

simulator_value() {
    local field="$1"
    printf '%s' "$SIM_JSON" | python3 -c '
import json
import sys

field = sys.argv[1]
data = json.load(sys.stdin)
for devices in data.get("devices", {}).values():
    for device in devices:
        if device.get("state") == "Booted":
            print(device.get(field, ""))
            raise SystemExit(0)
print("")
' "$field"
}

axe_wait_for_text() {
    local text="$1"
    local timeout_ms="$2"
    local deadline=$(( $(date +%s) + (timeout_ms + 999) / 1000 ))
    local ui

    while [[ "$(date +%s)" -le "$deadline" ]]; do
        ui=$(axe describe-ui --udid "$SIM_UDID" 2>/dev/null || true)
        if printf '%s' "$ui" | grep -Fq "$text"; then
            return 0
        fi
        sleep 1
    done

    echo -e "  ${YELLOW}Last AXe UI snapshot did not contain: ${text}${NC}"
    return 1
}

echo "========================================"
echo "  Jaala end-to-end AXe validation"
echo "========================================"
echo ""

echo "Step 0: Checking prerequisites..."
require_cmd python3
require_cmd xcodebuild
require_cmd xcrun
require_cmd axe
require_cmd mitmdump
require_cmd curl

SIM_JSON=$(xcrun simctl list devices booted -j 2>/dev/null)
SIM_UDID=$(simulator_value udid)
SIM_NAME=$(simulator_value name)

if [[ -z "$SIM_UDID" ]]; then
    echo -e "${RED}No booted simulator found. Boot a simulator and retry.${NC}"
    exit 1
fi

NETWORK_SERVICE="$(detect_active_service)"
if [[ -z "$NETWORK_SERVICE" ]]; then
    echo -e "${RED}No active network service found.${NC}"
    exit 1
fi

echo -e "  Booted simulator: ${YELLOW}${SIM_NAME} (${SIM_UDID})${NC}"
echo -e "  Active network service: ${YELLOW}${NETWORK_SERVICE}${NC}"
echo ""

echo "Step 1: Building and installing the sample app..."
if xcodebuild \
    -project "$APP_PROJECT" \
    -scheme "$APP_SCHEME" \
    -configuration Debug \
    -sdk iphonesimulator \
    -derivedDataPath "$APP_DERIVED_DATA" \
    build >/tmp/jaala_xcodebuild_$$.log 2>&1; then
    check "Sample app builds for iOS Simulator" "true"
else
    check "Sample app builds for iOS Simulator" "false"
    echo ""
    echo "xcodebuild log:"
    sed -n '1,220p' "/tmp/jaala_xcodebuild_$$.log"
    exit 1
fi

if xcrun simctl install "$SIM_UDID" "$APP_BINARY" >/dev/null; then
    check "Sample app installs on the booted Simulator" "true"
else
    check "Sample app installs on the booted Simulator" "false"
    exit 1
fi
echo ""

capture_proxy_state

echo "Step 2: Starting Jaala..."
python3 -m jaala \
    --quiet \
    --port "$JAAALA_PORT" \
    --json-file "$JSONL_FILE" \
    --save-har "$HAR_FILE" \
    --filter-user-agent "JaalaSample/1.0" \
    >"$JAAALA_LOG" 2>&1 &
JAAALA_PID=$!

if ! wait_for_port "$JAAALA_PORT" 30; then
    echo -e "${RED}Jaala did not start listening on port ${JAAALA_PORT}.${NC}"
    sed -n '1,220p' "$JAAALA_LOG"
    exit 1
fi

if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
    echo -e "${RED}Jaala exited before validation could start.${NC}"
    sed -n '1,220p' "$JAAALA_LOG"
    exit 1
fi

check "Jaala starts on fixed port ${JAAALA_PORT}" "true"

echo "Step 3: Driving the app with AXe..."
xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
if xcrun simctl launch "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null; then
    check "Sample app launches" "true"
else
    check "Sample app launches" "false"
    exit 1
fi

if axe_wait_for_text "Run full capture matrix: expect 6 results" 30000; then
    check "AXe can observe the request controls" "true"
else
    check "AXe can observe the request controls" "false"
    exit 1
fi

if axe tap --label "Run full capture matrix: expect 6 results" --udid "$SIM_UDID" >/dev/null; then
    check "AXe can tap Run full capture matrix: expect 6 results" "true"
else
    check "AXe can tap Run full capture matrix: expect 6 results" "false"
    exit 1
fi

if axe_wait_for_text "Results (6)" 60000; then
    check "Sample app records all six request results" "true"
else
    check "Sample app records all six request results" "false"
fi

echo ""
echo "Step 4: Stopping Jaala and validating capture artifacts..."
if kill -TERM "$JAAALA_PID" >/dev/null 2>&1; then
    check "Jaala receives shutdown signal" "true"
else
    check "Jaala receives shutdown signal" "false"
    exit 1
fi

for _ in {1..30}; do
    if ! kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

if kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
    echo -e "${RED}Jaala did not exit cleanly after SIGTERM.${NC}"
    exit 1
fi
wait "$JAAALA_PID" >/dev/null 2>&1 || true
check "Jaala process exits cleanly" "true"

capture_proxy_state_after
if cmp -s "$PROXY_BEFORE_HTTP" "$PROXY_AFTER_HTTP" && cmp -s "$PROXY_BEFORE_HTTPS" "$PROXY_AFTER_HTTPS"; then
    check "Host proxy settings are restored" "true"
else
    check "Host proxy settings are restored" "false"
fi

python3 - "$JSONL_FILE" "$HAR_FILE" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
har_path = Path(sys.argv[2])
expected_urls = [
    "https://httpbin.org/json",
    "https://jsonplaceholder.typicode.com/todos/1",
    "https://api.open-meteo.com/v1/forecast?latitude=37.7749&longitude=-122.4194&current=temperature_2m",
    "https://en.wikipedia.org/w/api.php?action=query&meta=siteinfo&siprop=general&format=json",
    "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=dQw4w9WgXcQ&format=json",
    "https://httpbin.org/post",
]

jsonl_lines = [line for line in jsonl_path.read_text(encoding="utf-8").splitlines() if line.strip()]
records = [json.loads(line) for line in jsonl_lines]
urls = [record["url"] for record in records]

if len(records) != 6:
    raise SystemExit(f"JSONL captured {len(records)} flows, expected 6")

if set(urls) != set(expected_urls):
    missing = sorted(set(expected_urls) - set(urls))
    extra = sorted(set(urls) - set(expected_urls))
    raise SystemExit(
        "JSONL URLs did not match expected sample traffic"
        + (f"; missing={missing}" if missing else "")
        + (f"; extra={extra}" if extra else "")
    )

har = json.loads(har_path.read_text(encoding="utf-8"))
entries = har.get("log", {}).get("entries", [])
har_urls = [entry.get("request", {}).get("url") for entry in entries]

if har.get("log", {}).get("creator", {}).get("name") != "jaala":
    raise SystemExit("HAR creator name was not jaala")

if len(entries) != 6:
    raise SystemExit(f"HAR captured {len(entries)} entries, expected 6")

if set(har_urls) != set(expected_urls):
    missing = sorted(set(expected_urls) - set(har_urls))
    extra = sorted(set(har_urls) - set(expected_urls))
    raise SystemExit(
        "HAR URLs did not match expected sample traffic"
        + (f"; missing={missing}" if missing else "")
        + (f"; extra={extra}" if extra else "")
    )
PY

check "JSONL contains the six sample endpoints" "true"
check "HAR contains the six sample endpoints" "true"

if pgrep -f "python3 -m jaala --quiet --port ${JAAALA_PORT}" >/dev/null 2>&1; then
    check "No jaala process remains" "false"
else
    check "No jaala process remains" "true"
fi

if pgrep -f "mitmdump --listen-port ${JAAALA_PORT}" >/dev/null 2>&1; then
    check "No mitmdump process remains" "false"
else
    check "No mitmdump process remains" "true"
fi

echo ""
echo "========================================"
echo -e "  Results: ${GREEN}$PASS passed${NC}, ${RED}$FAIL failed${NC}"
echo "========================================"

if [[ "$FAIL" -gt 0 ]]; then
    exit 1
fi

echo -e "${GREEN}All validations passed.${NC}"
