from __future__ import annotations

import argparse
import json
import pytest
from unittest.mock import MagicMock, patch

from jaala.cli import (
    build_parser,
    format_root_help,
    parse_capabilities_args,
    parse_cert_args,
    parse_args,
    parse_record_args,
    parse_replay_args,
    parse_rules_args,
    parse_run_args,
    parse_scenario_args,
    parse_sims_args,
    parse_sockets_args,
    parse_status_args,
    parse_streams_args,
)


def test_parse_args_defaults():
    args = parse_args([])

    assert args.list_sims is False
    assert args.sim is None
    assert args.port == 0
    assert args.json is False
    assert args.json_file is None
    assert args.save_har is None
    assert args.no_headers is False
    assert args.no_body is False
    assert args.no_websockets is False
    assert args.output is None
    assert args.config is None
    assert args.profile is None
    assert args.filter is None
    assert args.filter_user_agent is None
    assert args.map_local is None
    assert args.map_remote is None
    assert args.status_code is None
    assert args.add_header is None
    assert args.response_text_replace is None
    assert args.request_header is None
    assert args.request_body_replace is None
    assert args.websocket_message_replace is None
    assert args.websocket_drop_message == []
    assert args.websocket_fail_rate == []
    assert args.websocket_delay == []
    assert args.websocket_throttle == []
    assert args.websocket_replay is None
    assert args.websocket_replay_pattern is None
    assert args.delay == []
    assert args.throttle == []
    assert args.drop_connection == []
    assert args.fail_rate == []
    assert args.network_service is None
    assert args.cleanup is False
    assert args.status is False
    assert args.status_json is False
    assert args.probe_cert_readiness is False
    assert args.probe_cert_readiness_json is False
    assert args.trust_macos_cert is False
    assert args.quiet is False
    assert args.verbose is False


def test_build_parser_program_name():
    parser = build_parser()
    assert parser.prog == "jaala"


def test_json_and_artifact_flags_parse():
    args = parse_args(
        [
            "--json",
            "--json-file",
            "/tmp/traffic.jsonl",
            "--save-har",
            "/tmp/traffic.har",
            "--no-headers",
            "--no-body",
            "--no-websockets",
            "-o",
            "/tmp/traffic.flow",
        ]
    )

    assert args.json is True
    assert args.json_file == "/tmp/traffic.jsonl"
    assert args.save_har == "/tmp/traffic.har"
    assert args.no_headers is True
    assert args.no_body is True
    assert args.no_websockets is True
    assert args.output == "/tmp/traffic.flow"


def test_filter_and_config_flags_parse():
    args = parse_args(
        [
            "--config",
            "/tmp/filters.json",
            "--profile",
            "slow-api",
            "--filter",
            "api.example.com",
            "--filter-user-agent",
            "JaalaSample",
        ]
    )

    assert args.config == "/tmp/filters.json"
    assert args.profile == "slow-api"
    assert args.filter == "api.example.com"
    assert args.filter_user_agent == "JaalaSample"


def test_response_rule_flags_parse():
    args = parse_args(
        [
            "--map-local",
            "api.example.com=/tmp/fixture.json",
            "--map-remote",
            "api.example.com=https://example.com/fixture.json",
            "--status-code",
            "api.example.com=503",
            "--add-header",
            "api.example.com=X-Test:yes",
            "--response-text-replace",
            "api.example.com=hello>>>world",
        ]
    )

    assert args.map_local == "api.example.com=/tmp/fixture.json"
    assert args.map_remote == "api.example.com=https://example.com/fixture.json"
    assert args.status_code == "api.example.com=503"
    assert args.add_header == "api.example.com=X-Test:yes"
    assert args.response_text_replace == "api.example.com=hello>>>world"


def test_old_body_replace_flag_is_not_supported():
    try:
        parse_args(["--body-replace", "api.example.com=hello>>>world"])
    except SystemExit as exc:
        assert exc.code == 2
    else:
        raise AssertionError("Expected --body-replace to be rejected")


def test_request_rule_flags_parse():
    args = parse_args(
        [
            "--request-header",
            "api.example.com=X-Test:yes",
            "--request-body-replace",
            "api.example.com=hello>>>world",
            "--websocket-message-replace",
            "ws.example.com/socket=hello>>>world",
            "--websocket-drop-message",
            "ws.example.com/drop",
            "--websocket-fail-rate",
            "ws.example.com/flaky=100",
            "--websocket-delay",
            "ws.example.com/slow=250",
            "--websocket-throttle",
            "ws.example.com/large=1",
            "--websocket-replay",
            "/tmp/ws.jsonl",
            "--websocket-replay-pattern",
            "ws.example.com/socket",
        ]
    )

    assert args.request_header == "api.example.com=X-Test:yes"
    assert args.request_body_replace == "api.example.com=hello>>>world"
    assert args.websocket_message_replace == "ws.example.com/socket=hello>>>world"
    assert args.websocket_drop_message == ["ws.example.com/drop"]
    assert args.websocket_fail_rate == ["ws.example.com/flaky=100"]
    assert args.websocket_delay == ["ws.example.com/slow=250"]
    assert args.websocket_throttle == ["ws.example.com/large=1"]
    assert args.websocket_replay == "/tmp/ws.jsonl"
    assert args.websocket_replay_pattern == "ws.example.com/socket"


def test_network_condition_flags_parse():
    args = parse_args(
        [
            "--delay",
            "api.example.com=2000",
            "--throttle",
            "api.example.com=50",
            "--drop-connection",
            "api.example.com/flaky",
            "--fail-rate",
            "api.example.com=30",
        ]
    )

    assert args.delay == ["api.example.com=2000"]
    assert args.throttle == ["api.example.com=50"]
    assert args.drop_connection == ["api.example.com/flaky"]
    assert args.fail_rate == ["api.example.com=30"]


def test_unknown_flag_is_rejected():
    with pytest.raises(SystemExit):
        parse_args(["--simulator-only"])


def test_status_flags_parse():
    args = parse_args(["--status", "--status-json", "--network-service", "Wi-Fi"])
    assert args.status is True
    assert args.status_json is True
    assert args.network_service == "Wi-Fi"


def test_probe_cert_readiness_flags_parse():
    args = parse_args(["--probe-cert-readiness", "--probe-cert-readiness-json", "--sim", "ABC-123"])
    assert args.probe_cert_readiness is True
    assert args.probe_cert_readiness_json is True
    assert args.sim == "ABC-123"


def test_verbose_flag_parse():
    args = parse_args(["--verbose"])
    assert args.verbose is True
    assert args.quiet is False


def test_rules_add_response_text_replace_parse():
    args = parse_rules_args(
        [
            "add",
            "response-text-replace",
            "--name",
            "wiki-openai-temp",
            "--match-url",
            "wikipedia.org",
            "--search",
            "OpenAI",
            "--replace",
            "JAALA TEMP ITEM",
        ]
    )

    assert args.rules_command == "add"
    assert args.rule_type == "response-text-replace"
    assert args.name == "wiki-openai-temp"
    assert args.match_url == "wikipedia.org"
    assert args.search == "OpenAI"
    assert args.replace == "JAALA TEMP ITEM"


def test_rules_add_old_body_replace_command_is_not_supported():
    try:
        parse_rules_args(["add", "body-replace"])
    except SystemExit as exc:
        assert exc.code == 2
    else:
        raise AssertionError("Expected body-replace rule command to be rejected")


def test_rules_add_json_replace_parse():
    args = parse_rules_args(
        [
            "add",
            "json-replace",
            "--name",
            "wiki-featured-description",
            "--match-url",
            "feed/featured",
            "--json-path",
            "tfa.description",
            "--value-string",
            "JAALA JSON DEMO",
        ]
    )

    assert args.rules_command == "add"
    assert args.rule_type == "json-replace"
    assert args.name == "wiki-featured-description"
    assert args.match_url == "feed/featured"
    assert args.json_path == "tfa.description"
    assert args.value_string == "JAALA JSON DEMO"
    assert args.value_json is None


def test_rules_enable_disable_remove_parse():
    enable_args = parse_rules_args(["enable", "--name", "wiki-openai-temp"])
    disable_args = parse_rules_args(["disable", "--name", "wiki-openai-temp"])
    remove_args = parse_rules_args(["remove", "--name", "wiki-openai-temp"])

    assert enable_args.rules_command == "enable"
    assert enable_args.name == "wiki-openai-temp"
    assert disable_args.rules_command == "disable"
    assert disable_args.name == "wiki-openai-temp"
    assert remove_args.rules_command == "remove"
    assert remove_args.name == "wiki-openai-temp"


def test_rules_show_status_accept_trailing_json_parse():
    show_args = parse_rules_args(["show", "--json"])
    status_args = parse_rules_args(["status", "--json"])

    assert show_args.rules_command == "show"
    assert show_args.json_output is True
    assert status_args.rules_command == "status"
    assert status_args.json_output is True


def test_agentic_command_parsers():
    record_args = parse_record_args(["--json-file", "/tmp/traffic.jsonl", "--filter", "api.example.com"])
    replay_args = parse_replay_args(["/tmp/traffic.jsonl", "--websocket-pattern", "ws.example.com/socket"])
    scenario_args = parse_scenario_args(["run", "scenario.json", "--quiet"])
    sockets_args = parse_sockets_args(["send", "--match-url", "/socket", "--text", '{"event":"ready"}'])
    streams_args = parse_streams_args(["send", "--match-url", "/events", "--event", "message", "--data-json", '{"ok":true}'])

    assert record_args.json_file == "/tmp/traffic.jsonl"
    assert record_args.filter == "api.example.com"
    assert replay_args.capture == "/tmp/traffic.jsonl"
    assert replay_args.websocket_pattern == "ws.example.com/socket"
    assert scenario_args.scenario_command == "run"
    assert scenario_args.scenario_file == "scenario.json"
    assert scenario_args.quiet is True
    assert sockets_args.sockets_command == "send"
    assert sockets_args.text == '{"event":"ready"}'
    assert streams_args.streams_command == "send"
    assert streams_args.data_json == '{"ok":true}'


def test_run_parser_accepts_session_start_legacy_surface():
    args = parse_run_args(
        [
            "--sim",
            "ABC-123",
            "--port",
            "9000",
            "--network-service",
            "Wi-Fi",
            "--json",
            "--json-file",
            "/tmp/traffic.jsonl",
            "--save-har",
            "/tmp/traffic.har",
            "--output",
            "/tmp/traffic.flow",
            "--no-headers",
            "--no-body",
            "--no-websockets",
            "--config",
            "/tmp/jaala.json",
            "--profile",
            "slow",
            "--filter",
            "api.example.com",
            "--filter-user-agent",
            "JaalaSample",
            "--map-local",
            "api.example.com=/tmp/fixture.json",
            "--map-remote",
            "api.example.com=https://example.com/fixture.json",
            "--status-code",
            "api.example.com=503",
            "--add-header",
            "api.example.com=X-Test:yes",
            "--response-text-replace",
            "api.example.com=hello>>>world",
            "--request-header",
            "api.example.com=X-Test:yes",
            "--request-body-replace",
            "api.example.com=hello>>>world",
            "--websocket-message-replace",
            "ws.example.com=hello>>>world",
            "--websocket-drop-message",
            "ws.example.com/drop",
            "--websocket-fail-rate",
            "ws.example.com/flaky=50",
            "--websocket-delay",
            "ws.example.com/slow=250",
            "--websocket-throttle",
            "ws.example.com/large=1",
            "--websocket-replay",
            "/tmp/ws.jsonl",
            "--websocket-replay-pattern",
            "ws.example.com/socket",
            "--delay",
            "api.example.com=200",
            "--throttle",
            "api.example.com=50",
            "--drop-connection",
            "api.example.com/drop",
            "--fail-rate",
            "api.example.com=30",
            "--trust-macos-cert",
            "--quiet",
        ]
    )

    assert args.sim == "ABC-123"
    assert args.port == 9000
    assert args.network_service == "Wi-Fi"
    assert args.json is True
    assert args.no_websockets is True
    assert args.map_local == "api.example.com=/tmp/fixture.json"
    assert args.websocket_drop_message == ["ws.example.com/drop"]
    assert args.delay == ["api.example.com=200"]
    assert args.trust_macos_cert is True
    assert args.quiet is True


def test_operational_command_parsers():
    status_args = parse_status_args(["--json", "--network-service", "Wi-Fi"])
    cert_status_args = parse_cert_args(["status", "--json", "--sim", "ABC-123"])
    cert_trust_args = parse_cert_args(["trust-macos", "--quiet"])
    sims_args = parse_sims_args(["list"])
    capabilities_args = parse_capabilities_args(["--json"])

    assert status_args.json_output is True
    assert status_args.network_service == "Wi-Fi"
    assert cert_status_args.cert_command == "status"
    assert cert_status_args.json_output is True
    assert cert_status_args.sim == "ABC-123"
    assert cert_trust_args.cert_command == "trust-macos"
    assert cert_trust_args.quiet is True
    assert sims_args.sims_command == "list"
    assert capabilities_args.json_output is True


def test_root_help_is_compact_command_index():
    help_text = format_root_help()

    for command in ("run", "status", "cert", "sims", "cleanup", "capabilities"):
        assert command in help_text
    assert "--websocket-message-replace" not in help_text
    assert len(help_text.split()) < 120


@patch("jaala.__main__.print_readiness_status")
@patch("jaala.__main__.collect_readiness_status")
@patch("jaala.__main__.parse_args")
def test_main_dispatches_run_command_to_legacy_session_args(mock_parse_args, mock_collect_status, mock_print_status):
    mock_parse_args.return_value = argparse.Namespace(
        status=True,
        status_json=False,
        network_service="Wi-Fi",
        probe_cert_readiness=False,
        probe_cert_readiness_json=False,
        cleanup=False,
        list_sims=False,
    )
    mock_collect_status.return_value = {
        "ready": True,
        "blockers": [],
        "proxy": {},
        "session": {},
        "cert": {},
    }

    from jaala.__main__ import main

    exit_code = main(["run", "--filter", "api.example.com", "--json-file", "/tmp/traffic.jsonl", "--delay", "api.example.com=200"])

    assert exit_code == 0
    mock_parse_args.assert_called_once_with(["--json-file", "/tmp/traffic.jsonl", "--filter", "api.example.com", "--delay", "api.example.com=200"])


def test_main_root_help_prints_command_index(capsys):
    from jaala.__main__ import main

    exit_code = main(["--help"])

    assert exit_code == 0
    out = capsys.readouterr().out
    assert "usage: jaala <command> [options]" in out
    assert "capabilities" in out
    assert "--map-local" not in out


@patch("jaala.__main__.print_readiness_status")
@patch("jaala.__main__.collect_readiness_status")
def test_main_status_returns_success_when_ready(mock_collect_status, mock_print_status):
    mock_collect_status.return_value = {
        "ready": True,
        "blockers": [],
        "proxy": {},
        "session": {},
        "cert": {},
    }

    from jaala.__main__ import main

    exit_code = main(["--status"])

    assert exit_code == 0
    mock_print_status.assert_called_once_with(mock_collect_status.return_value, as_json=False)


@patch("jaala.__main__.print_readiness_status")
@patch("jaala.__main__.collect_readiness_status")
def test_main_status_json_returns_failure_when_not_ready(mock_collect_status, mock_print_status):
    mock_collect_status.return_value = {
        "ready": False,
        "blockers": ["missing cert"],
        "proxy": {},
        "session": {},
        "cert": {},
    }

    from jaala.__main__ import main

    exit_code = main(["--status-json"])

    assert exit_code == 1
    mock_print_status.assert_called_once_with(mock_collect_status.return_value, as_json=True)


@patch("jaala.__main__.print_readiness_status")
@patch("jaala.__main__.collect_readiness_status")
def test_main_status_command_matches_legacy_status_path(mock_collect_status, mock_print_status):
    mock_collect_status.return_value = {
        "ready": True,
        "blockers": [],
        "proxy": {},
        "session": {},
        "cert": {},
    }

    from jaala.__main__ import main

    exit_code = main(["status", "--json", "--network-service", "Wi-Fi"])

    assert exit_code == 0
    mock_collect_status.assert_called_once_with(network_service="Wi-Fi")
    mock_print_status.assert_called_once_with(mock_collect_status.return_value, as_json=True)


@patch("jaala.__main__.print_cert_probe_status")
@patch("jaala.__main__.collect_cert_probe_status")
def test_main_probe_cert_readiness_returns_success_when_ready(mock_collect_status, mock_print_status):
    mock_collect_status.return_value = {
        "ready": True,
        "blockers": [],
        "cert": {},
        "simulator": {},
    }

    from jaala.__main__ import main

    exit_code = main(["--probe-cert-readiness", "--sim", "ABC-123"])

    assert exit_code == 0
    mock_collect_status.assert_called_once_with(simulator_udid="ABC-123")
    mock_print_status.assert_called_once_with(mock_collect_status.return_value, as_json=False)


@patch("jaala.__main__.print_cert_probe_status")
@patch("jaala.__main__.collect_cert_probe_status")
def test_main_probe_cert_readiness_json_returns_failure_when_not_ready(mock_collect_status, mock_print_status):
    mock_collect_status.return_value = {
        "ready": False,
        "blockers": ["not booted"],
        "cert": {},
        "simulator": {},
    }

    from jaala.__main__ import main

    exit_code = main(["--probe-cert-readiness-json"])

    assert exit_code == 1


@patch("jaala.__main__.print_cert_probe_status")
@patch("jaala.__main__.collect_cert_probe_status")
def test_main_cert_status_command_matches_legacy_probe_path(mock_collect_status, mock_print_status):
    mock_collect_status.return_value = {
        "ready": True,
        "blockers": [],
        "cert": {},
        "simulator": {},
    }

    from jaala.__main__ import main

    exit_code = main(["cert", "status", "--json", "--sim", "ABC-123"])

    assert exit_code == 0
    mock_collect_status.assert_called_once_with(simulator_udid="ABC-123")
    mock_print_status.assert_called_once_with(mock_collect_status.return_value, as_json=True)


@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
def test_main_cert_trust_macos_command_matches_legacy_trust_path(mock_ensure_ca, mock_trust):
    from jaala.__main__ import main

    exit_code = main(["cert", "trust-macos", "--quiet"])

    assert exit_code == 0
    mock_trust.assert_called_once_with("/tmp/ca.pem", quiet=True)


@patch("jaala.__main__.print_simulators")
def test_main_sims_list_command_matches_legacy_list_path(mock_print_simulators):
    from jaala.__main__ import main

    exit_code = main(["sims", "list"])

    assert exit_code == 0
    mock_print_simulators.assert_called_once_with()


@patch("jaala.__main__.do_cleanup", return_value=True)
def test_main_cleanup_command_matches_legacy_cleanup_path(mock_cleanup):
    from jaala.__main__ import main

    exit_code = main(["cleanup"])

    assert exit_code == 0
    mock_cleanup.assert_called_once_with()


def test_capabilities_json_includes_command_paths_and_legacy_options(capsys):
    from jaala.__main__ import main

    exit_code = main(["capabilities", "--json"])

    assert exit_code == 0
    payload = json.loads(capsys.readouterr().out)
    paths = {tuple(command["path"]) for command in payload["commands"]}
    assert ("run",) in paths
    assert ("status",) in paths
    assert ("cert", "status") in paths
    assert ("cert", "trust-macos") in paths
    assert ("sims", "list") in paths
    assert ("cleanup",) in paths
    assert ("capabilities",) in paths
    run = next(command for command in payload["commands"] if command["path"] == ["run"])
    run_flags = {flag for option in run["options"] for flag in option["flags"]}
    assert {"--filter", "--json-file", "--map-local", "--websocket-replay", "--trust-macos-cert"} <= run_flags
    assert any(option["legacy"] for option in run["options"] if "--json-file" in option["flags"])
    assert payload["legacy_flat_mode"] is True
    assert "websocket_message" in payload["jsonl_record_types"]


@patch("jaala.__main__._handle_rules", return_value=0)
def test_main_dispatches_rules_commands(mock_handle_rules):
    from jaala.__main__ import main

    exit_code = main(["rules", "show"])

    assert exit_code == 0
    mock_handle_rules.assert_called_once_with(["show"])


@patch("jaala.__main__._handle_sockets", return_value=0)
def test_main_dispatches_sockets_commands(mock_handle_sockets):
    from jaala.__main__ import main

    exit_code = main(["sockets", "send", "--match-url", "/socket", "--text", "hello"])

    assert exit_code == 0
    mock_handle_sockets.assert_called_once_with(["send", "--match-url", "/socket", "--text", "hello"])


@patch("jaala.__main__._handle_streams", return_value=0)
def test_main_dispatches_streams_commands(mock_handle_streams):
    from jaala.__main__ import main

    exit_code = main(["streams", "send", "--match-url", "/events", "--text", "data: hi\n\n"])

    assert exit_code == 0
    mock_handle_streams.assert_called_once_with(["send", "--match-url", "/events", "--text", "data: hi\n\n"])


@patch("jaala.session.is_process_running", return_value=True)
@patch("jaala.__main__.read_lock")
def test_rules_add_response_text_replace_updates_active_runtime_config(mock_read_lock, mock_running, tmp_path):
    runtime_config = tmp_path / "runtime.json"
    runtime_config.write_text(json.dumps({"_jaala_runtime": {"rules": []}}), encoding="utf-8")
    mock_read_lock.return_value = {
        "pid": 1234,
        "runtime_config_path": str(runtime_config),
        "runtime_status_path": str(tmp_path / "status.json"),
    }

    from jaala.__main__ import main

    exit_code = main(
        [
            "rules",
            "add",
            "response-text-replace",
            "--name",
            "wiki-openai-temp",
            "--match-url",
            "wikipedia.org",
            "--search",
            "OpenAI",
            "--replace",
            "JAALA TEMP ITEM",
        ]
    )

    assert exit_code == 0
    payload = json.loads(runtime_config.read_text(encoding="utf-8"))
    assert payload["response_text_replace"] == "wikipedia.org=OpenAI>>>JAALA TEMP ITEM"


@patch("jaala.session.is_process_running", return_value=True)
@patch("jaala.__main__.read_lock")
def test_rules_add_json_replace_updates_active_runtime_config(mock_read_lock, mock_running, tmp_path):
    runtime_config = tmp_path / "runtime.json"
    runtime_config.write_text(json.dumps({"_jaala_runtime": {"rules": []}}), encoding="utf-8")
    mock_read_lock.return_value = {
        "pid": 1234,
        "runtime_config_path": str(runtime_config),
        "runtime_status_path": str(tmp_path / "status.json"),
    }

    from jaala.__main__ import main

    exit_code = main(
        [
            "rules",
            "add",
            "json-replace",
            "--name",
            "wiki-featured-description",
            "--match-url",
            "feed/featured",
            "--json-path",
            "tfa.description",
            "--value-string",
            "JAALA JSON DEMO",
        ]
    )

    assert exit_code == 0
    payload = json.loads(runtime_config.read_text(encoding="utf-8"))
    assert payload["_jaala_runtime"]["rules"][0]["type"] == "json_replace"
    assert payload["_jaala_runtime"]["rules"][0]["json_path"] == "tfa.description"
    assert payload["_jaala_runtime"]["rules"][0]["value"] == "JAALA JSON DEMO"


@patch("jaala.session.is_process_running", return_value=True)
@patch("jaala.__main__.read_lock")
def test_sockets_send_queues_runtime_websocket_event(mock_read_lock, mock_running, tmp_path):
    runtime_config = tmp_path / "runtime.json"
    runtime_config.write_text(json.dumps({"_jaala_runtime": {"rules": []}}), encoding="utf-8")
    mock_read_lock.return_value = {
        "pid": 1234,
        "runtime_config_path": str(runtime_config),
        "runtime_status_path": str(tmp_path / "status.json"),
    }

    from jaala.__main__ import main

    exit_code = main(
        [
            "sockets",
            "send",
            "--match-url",
            "ws.example.com/socket",
            "--text",
            '{"event":"ready"}',
            "--id",
            "evt-1",
            "--drop-live-server-messages",
        ]
    )

    assert exit_code == 0
    payload = json.loads(runtime_config.read_text(encoding="utf-8"))
    event = payload["_jaala_runtime"]["websocket_events"][0]
    assert event["id"] == "evt-1"
    assert event["match_url"] == "ws.example.com/socket"
    assert event["text"] == '{"event":"ready"}'
    assert event["drop_live_server_messages"] is True


@patch("jaala.session.is_process_running", return_value=True)
@patch("jaala.__main__.read_lock")
def test_streams_send_queues_runtime_sse_event(mock_read_lock, mock_running, tmp_path):
    runtime_config = tmp_path / "runtime.json"
    runtime_config.write_text(json.dumps({"_jaala_runtime": {"rules": []}}), encoding="utf-8")
    mock_read_lock.return_value = {
        "pid": 1234,
        "runtime_config_path": str(runtime_config),
        "runtime_status_path": str(tmp_path / "status.json"),
    }

    from jaala.__main__ import main

    exit_code = main(
        [
            "streams",
            "send",
            "--match-url",
            "api.example.com/events",
            "--event",
            "message",
            "--data-json",
            '{"ok":true}',
            "--id",
            "stream-1",
        ]
    )

    assert exit_code == 0
    payload = json.loads(runtime_config.read_text(encoding="utf-8"))
    event = payload["_jaala_runtime"]["stream_events"][0]
    assert event["id"] == "stream-1"
    assert event["match_url"] == "api.example.com/events"
    assert event["chunk"] == 'event: message\ndata: {"ok":true}\n\n'


@patch("jaala.session.is_process_running", return_value=True)
@patch("jaala.__main__.read_lock")
def test_rules_enable_disable_remove_update_active_runtime_config(mock_read_lock, mock_running, tmp_path):
    runtime_config = tmp_path / "runtime.json"
    runtime_config.write_text(
        json.dumps(
            {
                "_jaala_runtime": {
                    "rules": [
                        {
                            "name": "first",
                            "type": "response_text_replace",
                            "enabled": True,
                            "match_url": "wikipedia.org",
                            "search": "OpenAI",
                            "replace": "ONE",
                        },
                        {
                            "name": "second",
                            "type": "response_text_replace",
                            "enabled": True,
                            "match_url": "wikipedia.org",
                            "search": "OpenAI",
                            "replace": "TWO",
                        },
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    mock_read_lock.return_value = {
        "pid": 1234,
        "runtime_config_path": str(runtime_config),
        "runtime_status_path": str(tmp_path / "status.json"),
    }

    from jaala.__main__ import main

    disable_exit = main(["rules", "disable", "--name", "second"])
    assert disable_exit == 0
    payload = json.loads(runtime_config.read_text(encoding="utf-8"))
    assert payload["response_text_replace"] == "wikipedia.org=OpenAI>>>ONE"

    enable_exit = main(["rules", "enable", "--name", "second"])
    assert enable_exit == 0
    payload = json.loads(runtime_config.read_text(encoding="utf-8"))
    assert payload["response_text_replace"] == "wikipedia.org=OpenAI>>>TWO"

    remove_exit = main(["rules", "remove", "--name", "second"])
    assert remove_exit == 0
    payload = json.loads(runtime_config.read_text(encoding="utf-8"))
    assert [rule["name"] for rule in payload["_jaala_runtime"]["rules"]] == ["first"]
    assert payload["response_text_replace"] == "wikipedia.org=OpenAI>>>ONE"


@patch("jaala.__main__.remove_lock")
@patch("jaala.__main__.write_lock")
@patch("jaala.__main__.write_runtime_config")
@patch("jaala.__main__.preflight_checks")
@patch("jaala.__main__.check_stale_session")
@patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
@patch("jaala.__main__.install_cert_in_simulator")
@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ProxyConfig")
@patch("jaala.__main__.find_free_port", return_value=9999)
@patch("jaala.__main__.start_mitmdump")
def test_main_passes_capture_flags_to_proxy(
    mock_start,
    mock_find_port,
    mock_proxy_config,
    mock_trust,
    mock_install,
    mock_ensure_ca,
    mock_resolve,
    mock_check_stale,
    mock_preflight,
    mock_write_runtime_config,
    mock_write_lock,
    mock_remove_lock,
):
    mock_proc = MagicMock()
    mock_proc.wait.return_value = 0
    mock_proc.poll.return_value = 0
    mock_start.return_value = mock_proc

    from jaala.__main__ import main

    exit_code = main(
        [
            "--json",
            "--json-file",
            "/tmp/traffic.jsonl",
            "--save-har",
            "/tmp/traffic.har",
            "--no-headers",
            "--no-body",
            "-o",
            "/tmp/traffic.flow",
            "--quiet",
        ]
    )

    assert exit_code == 0
    mock_start.assert_called_once()
    call_kwargs = mock_start.call_args.kwargs
    assert call_kwargs["json_mode"] is True
    assert call_kwargs["json_file"] == "/tmp/traffic.jsonl"
    assert call_kwargs["save_har"] == "/tmp/traffic.har"
    assert call_kwargs["no_headers"] is True
    assert call_kwargs["no_body"] is True
    assert call_kwargs["no_websockets"] is False
    assert call_kwargs["output_file"] == "/tmp/traffic.flow"
    assert call_kwargs["quiet"] is True


@patch("jaala.__main__.remove_lock")
@patch("jaala.__main__.write_lock")
@patch("jaala.__main__.write_runtime_config")
@patch("jaala.__main__.preflight_checks")
@patch("jaala.__main__.check_stale_session")
@patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
@patch("jaala.__main__.install_cert_in_simulator")
@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ProxyConfig")
@patch("jaala.__main__.find_free_port", return_value=9999)
@patch("jaala.__main__.start_mitmdump")
def test_main_passes_no_websockets_flag_to_proxy(
    mock_start,
    mock_find_port,
    mock_proxy_config,
    mock_trust,
    mock_install,
    mock_ensure_ca,
    mock_resolve,
    mock_check_stale,
    mock_preflight,
    mock_write_runtime_config,
    mock_write_lock,
    mock_remove_lock,
):
    mock_proc = MagicMock()
    mock_proc.wait.return_value = 0
    mock_proc.poll.return_value = 0
    mock_start.return_value = mock_proc

    from jaala.__main__ import main

    exit_code = main(["--no-websockets", "--quiet"])

    assert exit_code == 0
    call_kwargs = mock_start.call_args.kwargs
    assert call_kwargs["no_websockets"] is True


@patch("jaala.__main__.remove_lock")
@patch("jaala.__main__.write_lock")
@patch("jaala.__main__.write_runtime_config")
@patch("jaala.__main__.preflight_checks")
@patch("jaala.__main__.check_stale_session")
@patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
@patch("jaala.__main__.install_cert_in_simulator")
@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ProxyConfig")
@patch("jaala.__main__.find_free_port", return_value=9999)
@patch("jaala.__main__.start_mitmdump")
def test_main_passes_filter_flags_to_proxy(
    mock_start,
    mock_find_port,
    mock_proxy_config,
    mock_trust,
    mock_install,
    mock_ensure_ca,
    mock_resolve,
    mock_check_stale,
    mock_preflight,
    mock_write_runtime_config,
    mock_write_lock,
    mock_remove_lock,
):
    mock_proc = MagicMock()
    mock_proc.wait.return_value = 0
    mock_proc.poll.return_value = 0
    mock_start.return_value = mock_proc

    from jaala.__main__ import main

    exit_code = main(
        [
            "--config",
            "/tmp/filters.json",
            "--filter",
            "api.example.com",
            "--filter-user-agent",
            "JaalaSample",
            "--quiet",
        ]
    )

    assert exit_code == 0
    runtime_config = mock_write_runtime_config.call_args.args[1]
    assert runtime_config["filter"] == "api.example.com"
    assert runtime_config["filter_user_agent"] == "JaalaSample"


@patch("jaala.__main__.remove_lock")
@patch("jaala.__main__.write_lock")
@patch("jaala.__main__.write_runtime_config")
@patch("jaala.__main__.preflight_checks")
@patch("jaala.__main__.check_stale_session")
@patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
@patch("jaala.__main__.install_cert_in_simulator")
@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ProxyConfig")
@patch("jaala.__main__.find_free_port", return_value=9999)
@patch("jaala.__main__.start_mitmdump")
def test_main_passes_response_flags_to_proxy(
    mock_start,
    mock_find_port,
    mock_proxy_config,
    mock_trust,
    mock_install,
    mock_ensure_ca,
    mock_resolve,
    mock_check_stale,
    mock_preflight,
    mock_write_runtime_config,
    mock_write_lock,
    mock_remove_lock,
):
    mock_proc = MagicMock()
    mock_proc.wait.return_value = 0
    mock_proc.poll.return_value = 0
    mock_start.return_value = mock_proc

    from jaala.__main__ import main

    exit_code = main(
        [
            "--map-local",
            "api.example.com=/tmp/fixture.json",
            "--map-remote",
            "api.example.com=https://example.com/fixture.json",
            "--status-code",
            "api.example.com=503",
            "--add-header",
            "api.example.com=X-Test:yes",
            "--response-text-replace",
            "api.example.com=hello>>>world",
            "--quiet",
        ]
    )

    assert exit_code == 0
    runtime_config = mock_write_runtime_config.call_args.args[1]
    assert runtime_config["map_local"] == "api.example.com=/tmp/fixture.json"
    assert runtime_config["map_remote"] == "api.example.com=https://example.com/fixture.json"
    assert runtime_config["status_code"] == "api.example.com=503"
    assert runtime_config["add_header"] == "api.example.com=X-Test:yes"
    assert runtime_config["response_text_replace"] == "api.example.com=hello>>>world"


@patch("jaala.__main__.remove_lock")
@patch("jaala.__main__.write_lock")
@patch("jaala.__main__.write_runtime_config")
@patch("jaala.__main__.preflight_checks")
@patch("jaala.__main__.check_stale_session")
@patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
@patch("jaala.__main__.install_cert_in_simulator")
@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ProxyConfig")
@patch("jaala.__main__.find_free_port", return_value=9999)
@patch("jaala.__main__.start_mitmdump")
def test_main_passes_request_flags_to_proxy(
    mock_start,
    mock_find_port,
    mock_proxy_config,
    mock_trust,
    mock_install,
    mock_ensure_ca,
    mock_resolve,
    mock_check_stale,
    mock_preflight,
    mock_write_runtime_config,
    mock_write_lock,
    mock_remove_lock,
):
    mock_proc = MagicMock()
    mock_proc.wait.return_value = 0
    mock_proc.poll.return_value = 0
    mock_start.return_value = mock_proc

    from jaala.__main__ import main

    exit_code = main(
        [
            "--request-header",
            "api.example.com=X-Test:yes",
            "--request-body-replace",
            "api.example.com=hello>>>world",
            "--quiet",
        ]
    )

    assert exit_code == 0
    runtime_config = mock_write_runtime_config.call_args.args[1]
    assert runtime_config["request_header"] == "api.example.com=X-Test:yes"
    assert runtime_config["request_body_replace"] == "api.example.com=hello>>>world"


@patch("jaala.__main__.remove_lock")
@patch("jaala.__main__.write_lock")
@patch("jaala.__main__.write_runtime_config")
@patch("jaala.__main__.preflight_checks")
@patch("jaala.__main__.check_stale_session")
@patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
@patch("jaala.__main__.install_cert_in_simulator")
@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ProxyConfig")
@patch("jaala.__main__.find_free_port", return_value=9999)
@patch("jaala.__main__.start_mitmdump")
def test_main_passes_websocket_message_replace_flag_to_proxy(
    mock_start,
    mock_find_port,
    mock_proxy_config,
    mock_trust,
    mock_install,
    mock_ensure_ca,
    mock_resolve,
    mock_check_stale,
    mock_preflight,
    mock_write_runtime_config,
    mock_write_lock,
    mock_remove_lock,
    tmp_path,
):
    mock_proc = MagicMock()
    mock_proc.wait.return_value = 0
    mock_proc.poll.return_value = 0
    mock_start.return_value = mock_proc
    replay_path = tmp_path / "ws.jsonl"
    replay_path.write_text(
        json.dumps(
            {
                "type": "websocket_message",
                "url": "wss://ws.example.com/socket",
                "direction": "server_to_client",
                "opcode": "text",
                "message": {"text": "mock"},
            }
        ),
        encoding="utf-8",
    )

    from jaala.__main__ import main

    exit_code = main(
        [
            "--websocket-message-replace",
            "ws.example.com/socket=hello>>>world",
            "--websocket-drop-message",
            "ws.example.com/drop",
            "--websocket-fail-rate",
            "ws.example.com/flaky=100",
            "--websocket-delay",
            "ws.example.com/slow=250",
            "--websocket-throttle",
            "ws.example.com/large=1",
            "--websocket-replay",
            str(replay_path),
            "--websocket-replay-pattern",
            "ws.example.com/socket",
            "--quiet",
        ]
    )

    assert exit_code == 0
    call_kwargs = mock_start.call_args.kwargs
    assert call_kwargs["websocket_message_replace"] == "ws.example.com/socket=hello>>>world"
    assert call_kwargs["websocket_drop_message"] == ["ws.example.com/drop"]
    assert call_kwargs["websocket_fail_rate"] == ["ws.example.com/flaky=100"]
    assert call_kwargs["websocket_delay"] == ["ws.example.com/slow=250"]
    assert call_kwargs["websocket_throttle"] == ["ws.example.com/large=1"]
    assert call_kwargs["websocket_replay_file"] == str(replay_path)
    assert call_kwargs["websocket_replay_pattern"] == "ws.example.com/socket"


@patch("jaala.__main__.remove_lock")
@patch("jaala.__main__.write_lock")
@patch("jaala.__main__.write_runtime_config")
@patch("jaala.__main__.preflight_checks")
@patch("jaala.__main__.check_stale_session")
@patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
@patch("jaala.__main__.install_cert_in_simulator")
@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ProxyConfig")
@patch("jaala.__main__.find_free_port", return_value=9999)
@patch("jaala.__main__.start_mitmdump")
def test_main_passes_network_condition_flags_to_proxy(
    mock_start,
    mock_find_port,
    mock_proxy_config,
    mock_trust,
    mock_install,
    mock_ensure_ca,
    mock_resolve,
    mock_check_stale,
    mock_preflight,
    mock_write_runtime_config,
    mock_write_lock,
    mock_remove_lock,
):
    mock_proc = MagicMock()
    mock_proc.wait.return_value = 0
    mock_proc.poll.return_value = 0
    mock_start.return_value = mock_proc

    from jaala.__main__ import main

    exit_code = main(
        [
            "--delay",
            "api.example.com=2000",
            "--throttle",
            "api.example.com=50",
            "--drop-connection",
            "api.example.com/flaky",
            "--fail-rate",
            "api.example.com=30",
            "--quiet",
        ]
    )

    assert exit_code == 0
    runtime_config = mock_write_runtime_config.call_args.args[1]
    assert runtime_config["delay"] == ["api.example.com=2000"]
    assert runtime_config["throttle"] == ["api.example.com=50"]
    assert runtime_config["drop_connection"] == ["api.example.com/flaky"]
    assert runtime_config["fail_rate"] == ["api.example.com=30"]


@patch("jaala.__main__.remove_lock")
@patch("jaala.__main__.write_lock")
@patch("jaala.__main__.write_runtime_config")
@patch("jaala.__main__.preflight_checks")
@patch("jaala.__main__.check_stale_session")
@patch("jaala.__main__.resolve_simulator", return_value={"udid": "ABC-123", "name": "iPhone 15"})
@patch("jaala.__main__.ensure_ca_cert", return_value="/tmp/ca.pem")
@patch("jaala.__main__.install_cert_in_simulator")
@patch("jaala.__main__.trust_ca_cert_in_macos")
@patch("jaala.__main__.ProxyConfig")
@patch("jaala.__main__.find_free_port", return_value=9999)
@patch("jaala.__main__.start_mitmdump")
def test_main_applies_named_profile_overrides_to_runtime_config(
    mock_start,
    mock_find_port,
    mock_proxy_config,
    mock_trust,
    mock_install,
    mock_ensure_ca,
    mock_resolve,
    mock_check_stale,
    mock_preflight,
    mock_write_runtime_config,
    mock_write_lock,
    mock_remove_lock,
    tmp_path,
):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps(
            {
                "filter": "base.example.com",
                "filter_user_agent": "BaseUA",
                "map_local": "base.example.com=/tmp/base.json",
                "request_header": "base.example.com=X-Base:yes",
                "websocket_drop_message": ["base.example.com/drop"],
                "delay": ["base.example.com=100"],
                "profiles": {
                    "slow-api": {
                        "filter": "profile.example.com",
                        "map_local": "profile.example.com=/tmp/profile.json",
                        "request_header": "profile.example.com=X-Profile:yes",
                        "websocket_drop_message": ["profile.example.com/drop"],
                        "delay": ["profile.example.com=900"],
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    mock_proc = MagicMock()
    mock_proc.wait.return_value = 0
    mock_proc.poll.return_value = 0
    mock_start.return_value = mock_proc

    from jaala.__main__ import main

    exit_code = main(["--config", str(config_path), "--profile", "slow-api", "--quiet"])

    assert exit_code == 0
    runtime_config = mock_write_runtime_config.call_args.args[1]
    assert runtime_config["filter"] == "profile.example.com"
    assert runtime_config["filter_user_agent"] == "BaseUA"
    assert runtime_config["map_local"] == "profile.example.com=/tmp/profile.json"
    assert runtime_config["request_header"] == "profile.example.com=X-Profile:yes"
    assert runtime_config["delay"] == ["profile.example.com=900"]
    call_kwargs = mock_start.call_args.kwargs
    assert call_kwargs["websocket_drop_message"] == ["profile.example.com/drop"]
