from __future__ import annotations

import json
import os
from unittest.mock import patch

from jaala.addon import JaalaAddon

from .test_addon import make_flow


def test_map_local_replaces_response_with_fixture(tmp_path):
    fixture = tmp_path / "fixture.json"
    fixture.write_text('{"source":"local"}', encoding="utf-8")
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"map_local": f"api.example.com={fixture}"}), encoding="utf-8")

    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow()
    addon.response(flow)

    assert flow.response.status_code == 200
    assert flow.response.content == b'{"source":"local"}'
    assert flow.response.headers.get("content-type") == "application/json"
