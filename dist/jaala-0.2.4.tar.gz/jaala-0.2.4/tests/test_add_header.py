from __future__ import annotations

import json
import os
from unittest.mock import patch

from jaala.addon import JaalaAddon

from .test_addon import make_flow


def test_add_header_appends_matching_header(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"add_header": "api.example.com=X-Test:yes"}), encoding="utf-8")
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow()
    addon.response(flow)

    assert flow.response.headers.get("X-Test") == "yes"
