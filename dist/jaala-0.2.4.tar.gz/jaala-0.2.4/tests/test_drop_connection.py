from __future__ import annotations

import json
import os
from unittest.mock import MagicMock, patch

from jaala.addon import JaalaAddon
from jaala.cli import parse_args, parse_drop_connection_rules


def test_drop_connection_flag_parses():
    args = parse_args(["--drop-connection", "api.example.com/flaky"])
    assert args.drop_connection == ["api.example.com/flaky"]


def test_parse_drop_connection_rules_validates():
    rules = parse_drop_connection_rules(["api.example.com"])
    assert rules == ["api.example.com"]


def test_drop_connection_kills_flow(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"drop_connection": ["api.example.com"]}), encoding="utf-8")
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = MagicMock()
    flow.request.pretty_url = "https://api.example.com/data"
    flow.request.method = "GET"
    flow.metadata = {}

    addon.request(flow)

    flow.kill.assert_called_once()
    assert flow.metadata["jaala_dropped"] is True
