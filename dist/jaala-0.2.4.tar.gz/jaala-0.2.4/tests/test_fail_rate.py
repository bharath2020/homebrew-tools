from __future__ import annotations

import json
import os
from unittest.mock import MagicMock, patch

import pytest

from jaala.addon import JaalaAddon
from jaala.cli import parse_args, parse_fail_rate_rules


def test_fail_rate_flag_parses():
    args = parse_args(["--fail-rate", "api.example.com=30"])
    assert args.fail_rate == ["api.example.com=30"]


def test_parse_fail_rate_rules_validates():
    rules = parse_fail_rate_rules(["api.example.com=30"])
    assert rules == [{"pattern": "api.example.com", "percent": 30}]


def test_parse_fail_rate_rules_rejects_bad_percent():
    with pytest.raises(ValueError):
        parse_fail_rate_rules(["api.example.com=101"])


def test_fail_rate_can_drop_request(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"fail_rate": ["api.example.com=30"]}), encoding="utf-8")
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = MagicMock()
    flow.request.pretty_url = "https://api.example.com/data"
    flow.request.method = "GET"
    flow.metadata = {}

    with patch("jaala.network_conditions.random.randint", return_value=30):
        addon.request(flow)

    flow.kill.assert_called_once()
    assert flow.metadata["jaala_fail_rate_dropped"] is True
    assert flow.metadata["jaala_fail_rate_percent"] == 30
