from __future__ import annotations

import json
import os
from unittest.mock import patch

import pytest

from jaala.addon import JaalaAddon
from jaala.websocket_replay import (
    build_websocket_replay,
    load_websocket_replay_messages,
)

from .test_websocket_capture import make_websocket_flow


def write_replay(path, *, url="wss://ws.example.com/socket", text="mock event"):
    records = [
        {"type": "http", "url": "https://api.example.com/ignored"},
        {
            "type": "websocket_message",
            "url": url,
            "direction": "client_to_server",
            "opcode": "text",
            "message": {"text": "client ping"},
        },
        {
            "type": "websocket_message",
            "url": url,
            "direction": "server_to_client",
            "opcode": "text",
            "message": {"text": text},
        },
        {
            "type": "websocket_message",
            "url": url,
            "direction": "server_to_client",
            "opcode": "binary",
            "message": {"size": 2},
        },
    ]
    path.write_text("\n".join(json.dumps(record) for record in records), encoding="utf-8")


def test_load_websocket_replay_messages_reads_server_text_records(tmp_path):
    replay_path = tmp_path / "traffic.jsonl"
    write_replay(replay_path)

    messages = load_websocket_replay_messages(str(replay_path))

    assert len(messages) == 1
    assert messages[0].url == "wss://ws.example.com/socket"
    assert messages[0].text == "mock event"


def test_load_websocket_replay_messages_rejects_missing_file(tmp_path):
    with pytest.raises(ValueError, match="does not exist"):
        load_websocket_replay_messages(str(tmp_path / "missing.jsonl"))


def test_build_websocket_replay_uses_recorded_url_when_no_pattern(tmp_path):
    replay_path = tmp_path / "traffic.jsonl"
    write_replay(replay_path)
    replay = build_websocket_replay(replay_file=str(replay_path))

    assert replay.matches(make_websocket_flow(url="wss://ws.example.com/socket"))
    assert not replay.matches(make_websocket_flow(url="wss://other.example.com/socket"))


def test_build_websocket_replay_pattern_redirects_records_to_matching_live_url(tmp_path):
    replay_path = tmp_path / "traffic.jsonl"
    write_replay(replay_path, url="wss://recorded.example.com/socket")
    replay = build_websocket_replay(
        replay_file=str(replay_path),
        replay_pattern="live.example.com/socket",
    )

    flow = make_websocket_flow(url="wss://live.example.com/socket")

    assert replay.matches(flow)
    assert [message.text for message in replay.messages_for(flow)] == ["mock event"]


def test_websocket_replay_injects_recorded_server_message_after_client_message(tmp_path, capsys):
    replay_path = tmp_path / "traffic.jsonl"
    write_replay(replay_path, text="mock event one")
    with patch.dict(
        os.environ,
        {
            "JAALA_JSON": "1",
            "JAALA_WEBSOCKET_REPLAY_FILE": str(replay_path),
        },
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow(text="client ping", content=b"client ping")
    addon.websocket_message(flow)

    record = json.loads(capsys.readouterr().out.strip())
    assert record["direction"] == "client_to_server"
    assert flow.metadata["jaala_websocket_replay_injected"] is True
    assert flow.metadata["jaala_websocket_replay_injected_count"] == 1
    injected = flow.websocket.messages[-1]
    assert injected.injected is True
    assert injected.from_client is False
    assert injected.text == "mock event one"


def test_websocket_replay_drops_live_server_message_after_injection(tmp_path, capsys):
    replay_path = tmp_path / "traffic.jsonl"
    write_replay(replay_path)
    with patch.dict(
        os.environ,
        {
            "JAALA_JSON": "1",
            "JAALA_WEBSOCKET_REPLAY_FILE": str(replay_path),
        },
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow(text="client ping", content=b"client ping")
    addon.websocket_message(flow)
    capsys.readouterr()
    live_server = make_websocket_flow(
        from_client=False,
        text="real upstream event",
        content=b"real upstream event",
    ).websocket.messages[-1]
    flow.websocket.messages.append(live_server)

    addon.websocket_message(flow)

    assert capsys.readouterr().out == ""
    assert flow.metadata["jaala_websocket_replay_live_server_dropped"] is True
    assert live_server.dropped is True


def test_runtime_websocket_send_injects_queued_event(tmp_path, capsys):
    config_path = tmp_path / "runtime.json"
    config_path.write_text(
        json.dumps(
            {
                "_jaala_runtime": {
                    "websocket_events": [
                        {
                            "id": "evt-1",
                            "type": "websocket_send",
                            "match_url": "ws.example.com/socket",
                            "text": "runtime event",
                            "drop_live_server_messages": True,
                        }
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    with patch.dict(
        os.environ,
        {
            "JAALA_JSON": "1",
            "JAALA_CONFIG": str(config_path),
        },
        clear=False,
    ):
        addon = JaalaAddon()

    flow = make_websocket_flow(text="client ping", content=b"client ping")
    addon.websocket_message(flow)

    record = json.loads(capsys.readouterr().out.strip())
    assert record["direction"] == "client_to_server"
    assert flow.websocket.messages[-1].injected is True
    assert flow.websocket.messages[-1].text == "runtime event"
    assert flow.metadata["jaala_runtime_websocket_drop_live_server"] is True
