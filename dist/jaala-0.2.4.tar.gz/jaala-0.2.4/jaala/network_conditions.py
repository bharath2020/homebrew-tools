"""Network-condition parsing and simulation for Jaala."""

from __future__ import annotations

import json
import os
import random
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field

from .filtering import build_matcher, load_merged_config

ENV_CONFIG = "JAALA_CONFIG"

NETWORK_KEYS = ("delay", "throttle", "drop_connection", "fail_rate")


def _normalize(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _split_once(value: str, separator: str, label: str) -> tuple[str, str]:
    left, found, right = value.partition(separator)
    if not found or not left.strip() or not right.strip():
        raise ValueError(f"Invalid {label} rule {value!r}")
    return left.strip(), right.strip()


def _content_bytes(content: bytes | bytearray | memoryview | None) -> bytes:
    if content is None:
        return b""
    if isinstance(content, bytes):
        return content
    if isinstance(content, bytearray):
        return bytes(content)
    if isinstance(content, memoryview):
        return content.tobytes()
    return bytes(content)


def _load_json_list(raw_value: str | None, label: str) -> list[str]:
    normalized = _normalize(raw_value)
    if normalized is None:
        return []

    try:
        value = json.loads(normalized)
    except (json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"{label} must be a JSON array of strings") from exc

    if not isinstance(value, list):
        raise ValueError(f"{label} must be a JSON array of strings")

    result: list[str] = []
    for item in value:
        if not isinstance(item, str):
            raise ValueError(f"{label} entries must be strings")
        normalized_item = _normalize(item)
        if normalized_item is not None:
            result.append(normalized_item)
    return result


def _validate_pattern(pattern: str, label: str) -> str:
    normalized = _normalize(pattern)
    if normalized is None:
        raise ValueError(f"Invalid {label} rule: pattern must not be empty")
    build_matcher(normalized)
    return normalized


def _coerce_raw_rules(value: Sequence[str] | str | None) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [_normalize(value)] if _normalize(value) is not None else []
    result: list[str] = []
    for item in value:
        normalized = _normalize(item)
        if normalized is not None:
            result.append(normalized)
    return result


def parse_delay_rules(raw_rules: Sequence[str]) -> list[dict[str, int | str]]:
    rules: list[dict[str, int | str]] = []
    for raw in raw_rules:
        normalized = _normalize(raw)
        if normalized is None:
            raise ValueError("Invalid delay rule: pattern and milliseconds must not be empty")
        pattern, ms_text = _split_once(normalized, "=", "delay")
        pattern = _validate_pattern(pattern, "delay")
        try:
            delay_ms = int(ms_text)
        except ValueError as exc:
            raise ValueError(f"Invalid delay rule {raw!r}: milliseconds must be an integer") from exc
        if delay_ms < 0:
            raise ValueError(f"Invalid delay rule {raw!r}: milliseconds must be non-negative")
        rules.append({"pattern": pattern, "delay_ms": delay_ms})
    return rules


def parse_throttle_rules(raw_rules: Sequence[str]) -> list[dict[str, int | str]]:
    rules: list[dict[str, int | str]] = []
    for raw in raw_rules:
        normalized = _normalize(raw)
        if normalized is None:
            raise ValueError("Invalid throttle rule: pattern and KBPS must not be empty")
        pattern, kbps_text = _split_once(normalized, "=", "throttle")
        pattern = _validate_pattern(pattern, "throttle")
        try:
            kbps = int(kbps_text)
        except ValueError as exc:
            raise ValueError(f"Invalid throttle rule {raw!r}: KBPS must be an integer") from exc
        if kbps <= 0:
            raise ValueError(f"Invalid throttle rule {raw!r}: KBPS must be positive")
        rules.append({"pattern": pattern, "kbps": kbps})
    return rules


def parse_drop_connection_rules(raw_rules: Sequence[str]) -> list[str]:
    rules: list[str] = []
    for raw in raw_rules:
        pattern = _validate_pattern(raw, "drop-connection")
        rules.append(pattern)
    return rules


def parse_fail_rate_rules(raw_rules: Sequence[str]) -> list[dict[str, int | str]]:
    rules: list[dict[str, int | str]] = []
    for raw in raw_rules:
        normalized = _normalize(raw)
        if normalized is None:
            raise ValueError("Invalid fail-rate rule: pattern and percent must not be empty")
        pattern, percent_text = _split_once(normalized, "=", "fail-rate")
        pattern = _validate_pattern(pattern, "fail-rate")
        try:
            percent = int(percent_text)
        except ValueError as exc:
            raise ValueError(f"Invalid fail-rate rule {raw!r}: percent must be an integer") from exc
        if percent < 0 or percent > 100:
            raise ValueError(f"Invalid fail-rate rule {raw!r}: percent must be between 0 and 100")
        rules.append({"pattern": pattern, "percent": percent})
    return rules


@dataclass(slots=True)
class NetworkConditionRuleSet:
    delay: list[tuple[Callable[[str], bool], int]] = field(default_factory=list)
    throttle: list[tuple[Callable[[str], bool], int]] = field(default_factory=list)
    drop_connection: list[Callable[[str], bool]] = field(default_factory=list)
    fail_rate: list[tuple[Callable[[str], bool], int]] = field(default_factory=list)

    def _flow_metadata(self, flow) -> dict:
        metadata = getattr(flow, "metadata", None)
        if metadata is None:
            metadata = {}
            flow.metadata = metadata
        return metadata

    def _url(self, flow) -> str:
        return getattr(flow.request, "pretty_url", "")

    def _match_first(self, rules, url: str):
        for rule in rules:
            matcher = rule[0]
            if matcher(url):
                return rule[1]
        return None

    def _drop_flow(self, flow) -> None:
        killer = getattr(flow, "kill", None)
        if callable(killer):
            killer()

    def _apply_fail_rate(self, flow, url: str) -> bool:
        percent = self._match_first(self.fail_rate, url)
        if percent is None or percent <= 0:
            return False

        if percent >= 100 or random.randint(1, 100) <= percent:
            metadata = self._flow_metadata(flow)
            metadata["jaala_dropped"] = True
            metadata["jaala_fail_rate_dropped"] = True
            metadata["jaala_fail_rate_percent"] = percent
            self._drop_flow(flow)
            return True
        return False

    def _apply_drop_connection(self, flow, url: str) -> bool:
        if not any(matcher(url) for matcher in self.drop_connection):
            return False

        metadata = self._flow_metadata(flow)
        metadata["jaala_dropped"] = True
        metadata["jaala_drop_connection"] = True
        self._drop_flow(flow)
        return True

    def _match_delay(self, url: str) -> int | None:
        return self._match_first(self.delay, url)

    def _match_throttle(self, url: str) -> int | None:
        return self._match_first(self.throttle, url)

    def _apply_delay(self, flow, url: str) -> bool:
        delay_ms = self._match_delay(url)
        if delay_ms is None:
            return False

        if delay_ms > 0:
            time.sleep(delay_ms / 1000.0)

        metadata = self._flow_metadata(flow)
        metadata["jaala_delayed_ms"] = delay_ms
        return True

    def _apply_throttle(self, flow, url: str) -> bool:
        throttle_kbps = self._match_throttle(url)
        if throttle_kbps is None:
            return False

        response = getattr(flow, "response", None)
        if response is None:
            return False

        body_size = len(_content_bytes(getattr(response, "content", None)))
        expected_seconds = body_size / (throttle_kbps * 1024)
        request_start = getattr(flow.request, "timestamp_start", None)
        response_end = getattr(response, "timestamp_end", None)
        actual_seconds = 0.0
        if request_start is not None and response_end is not None:
            actual_seconds = max(0.0, response_end - request_start)

        sleep_seconds = expected_seconds - actual_seconds
        if sleep_seconds > 0:
            time.sleep(sleep_seconds)

        metadata = self._flow_metadata(flow)
        metadata["jaala_throttled_kbps"] = throttle_kbps
        return True

    def apply_request(self, flow) -> bool:
        metadata = self._flow_metadata(flow)
        if metadata.get("jaala_dropped"):
            return False

        url = self._url(flow)
        if self._apply_fail_rate(flow, url):
            return True
        if self._apply_drop_connection(flow, url):
            return True
        return False

    def apply_response(self, flow) -> bool:
        metadata = self._flow_metadata(flow)
        if metadata.get("jaala_dropped"):
            return False

        url = self._url(flow)
        mutated = False
        mutated |= self._apply_delay(flow, url)
        mutated |= self._apply_throttle(flow, url)
        return mutated


def build_network_condition_rules(settings: Mapping[str, Sequence[str]] | None = None) -> NetworkConditionRuleSet:
    settings = settings or {}

    delay_raw = _coerce_raw_rules(settings.get("delay"))
    throttle_raw = _coerce_raw_rules(settings.get("throttle"))
    drop_connection_raw = _coerce_raw_rules(settings.get("drop_connection"))
    fail_rate_raw = _coerce_raw_rules(settings.get("fail_rate"))

    compiled = NetworkConditionRuleSet()

    for rule in parse_delay_rules(delay_raw):
        matcher = build_matcher(str(rule["pattern"]))
        compiled.delay.append((matcher, int(rule["delay_ms"])))

    for rule in parse_throttle_rules(throttle_raw):
        matcher = build_matcher(str(rule["pattern"]))
        compiled.throttle.append((matcher, int(rule["kbps"])))

    for pattern in parse_drop_connection_rules(drop_connection_raw):
        matcher = build_matcher(pattern)
        compiled.drop_connection.append(matcher)

    for rule in parse_fail_rate_rules(fail_rate_raw):
        matcher = build_matcher(str(rule["pattern"]))
        compiled.fail_rate.append((matcher, int(rule["percent"])))

    return compiled


def load_network_conditions_config(path: str | None, profile: str | None = None) -> dict[str, list[str]]:
    data = load_merged_config(path, profile=profile)

    result: dict[str, list[str]] = {}
    for key in NETWORK_KEYS:
        value = data.get(key)
        if value is None:
            continue
        if not isinstance(value, list):
            raise ValueError(f"Network conditions config {path!r} field {key!r} must be a JSON array")
        normalized_values: list[str] = []
        for item in value:
            if not isinstance(item, str):
                raise ValueError(f"Network conditions config {path!r} field {key!r} entries must be strings")
            normalized = _normalize(item)
            if normalized is not None:
                normalized_values.append(normalized)
        result[key] = normalized_values
    return result


def resolve_network_condition_settings(
    *,
    config_path: str | None = None,
    config_profile: str | None = None,
    env: Mapping[str, str] | None = None,
    delay: Sequence[str] | None = None,
    throttle: Sequence[str] | None = None,
    drop_connection: Sequence[str] | None = None,
    fail_rate: Sequence[str] | None = None,
) -> dict[str, list[str]]:
    env = env or os.environ
    resolved = load_network_conditions_config(config_path or env.get(ENV_CONFIG), profile=config_profile)

    if delay:
        resolved.setdefault("delay", []).extend(_coerce_raw_rules(delay))
    if throttle:
        resolved.setdefault("throttle", []).extend(_coerce_raw_rules(throttle))
    if drop_connection:
        resolved.setdefault("drop_connection", []).extend(_coerce_raw_rules(drop_connection))
    if fail_rate:
        resolved.setdefault("fail_rate", []).extend(_coerce_raw_rules(fail_rate))

    return resolved
