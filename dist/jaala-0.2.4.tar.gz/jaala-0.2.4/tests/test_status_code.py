from __future__ import annotations

import json
import os
from unittest.mock import patch

from jaala.addon import JaalaAddon

from .test_addon import make_flow


def test_status_code_overrides_matching_response(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"status_code": "api.example.com=418"}), encoding="utf-8")
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow()
    addon.response(flow)

    assert flow.response.status_code == 418
