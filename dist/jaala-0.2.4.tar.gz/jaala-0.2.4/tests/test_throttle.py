from __future__ import annotations

import json
import os
from unittest.mock import patch

import pytest

from jaala.addon import JaalaAddon
from jaala.cli import parse_args, parse_throttle_rules

from .test_addon import make_flow


def test_throttle_flag_parses():
    args = parse_args(["--throttle", "api.example.com=50"])
    assert args.throttle == ["api.example.com=50"]


def test_parse_throttle_rules_validates():
    rules = parse_throttle_rules(["api.example.com=50"])
    assert rules == [{"pattern": "api.example.com", "kbps": 50}]


def test_parse_throttle_rules_rejects_bad_kbps():
    with pytest.raises(ValueError):
        parse_throttle_rules(["api.example.com=0"])


def test_throttle_applies_sleep_and_metadata(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"throttle": ["api.example.com=10"]}), encoding="utf-8")
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(resp_body=b"x" * 10240)
    flow.request.timestamp_start = 1000.0
    flow.response.timestamp_end = 1000.1

    with patch("jaala.network_conditions.time.sleep") as mock_sleep:
        addon.response(flow)

    mock_sleep.assert_called_once()
    assert abs(mock_sleep.call_args.args[0] - 0.9) < 0.01
    assert flow.metadata["jaala_throttled_kbps"] == 10
