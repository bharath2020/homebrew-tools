from __future__ import annotations

from unittest.mock import patch


@patch("jaala.readiness.probe_simulator_cert_status")
@patch("jaala.readiness.resolve_simulator")
@patch("jaala.readiness.get_ca_cert_status")
def test_collect_cert_probe_status_requires_macos_trust_even_when_simulator_probe_is_ready(
    mock_get_ca_cert_status,
    mock_resolve_simulator,
    mock_probe_simulator_cert_status,
):
    mock_get_ca_cert_status.return_value = {
        "path": "/tmp/mitmproxy-ca-cert.pem",
        "exists": True,
        "trusted_in_macos": False,
        "ready": False,
    }
    mock_resolve_simulator.return_value = {"udid": "NEW-SIM-123", "name": "iPhone 17"}
    mock_probe_simulator_cert_status.return_value = {
        "device_name": "iPhone 17",
        "udid": "NEW-SIM-123",
        "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-26-0",
        "booted": True,
        "cert_path": "/Users/test/.mitmproxy/mitmproxy-ca-cert.pem",
        "cert_exists": True,
        "trust_store_path": "/Users/test/Library/Developer/CoreSimulator/Devices/NEW-SIM-123/data/private/var/protected/trustd/private/TrustStore.sqlite3",
        "trust_store_exists": False,
        "probe_action": "installed",
        "probe_returncode": 0,
        "probe_stderr": "",
        "installed": True,
        "ready": True,
    }

    from jaala.readiness import collect_cert_probe_status

    status = collect_cert_probe_status("NEW-SIM-123")

    assert status["ready"] is False
    assert status["blockers"] == ["CA certificate is not trusted in the macOS System keychain."]


@patch("jaala.readiness.probe_simulator_cert_status")
@patch("jaala.readiness.resolve_simulator")
@patch("jaala.readiness.get_ca_cert_status")
def test_collect_cert_probe_status_reports_not_booted_fresh_simulator(
    mock_get_ca_cert_status,
    mock_resolve_simulator,
    mock_probe_simulator_cert_status,
):
    mock_get_ca_cert_status.return_value = {
        "path": "/tmp/mitmproxy-ca-cert.pem",
        "exists": True,
        "trusted_in_macos": True,
        "ready": True,
    }
    mock_resolve_simulator.return_value = {"udid": "NEW-SIM-456", "name": "iPhone 16e"}
    mock_probe_simulator_cert_status.return_value = {
        "device_name": "iPhone 16e",
        "udid": "NEW-SIM-456",
        "runtime": "com.apple.CoreSimulator.SimRuntime.iOS-18-5",
        "booted": False,
        "cert_path": "/Users/test/.mitmproxy/mitmproxy-ca-cert.pem",
        "cert_exists": True,
        "trust_store_path": "/Users/test/Library/Developer/CoreSimulator/Devices/NEW-SIM-456/data/private/var/protected/trustd/private/TrustStore.sqlite3",
        "trust_store_exists": False,
        "probe_action": "not_run",
        "probe_returncode": None,
        "probe_stderr": "",
        "installed": False,
        "ready": False,
    }

    from jaala.readiness import collect_cert_probe_status

    status = collect_cert_probe_status("NEW-SIM-456")

    assert status["ready"] is False
    assert status["blockers"] == [
        "Simulator NEW-SIM-456 is not booted.",
        "Simulator certificate probe failed.",
    ]


def test_print_cert_probe_status_marks_boot_state_in_output(capsys):
    from jaala.readiness import print_cert_probe_status

    status = {
        "ready": False,
        "blockers": ["Simulator NEW-SIM-456 is not booted."],
        "cert": {
            "path": "/tmp/mitmproxy-ca-cert.pem",
            "exists": True,
            "macos_system_trusted": True,
        },
        "simulator": {
            "device_name": "iPhone 16e",
            "udid": "NEW-SIM-456",
            "booted": False,
            "trust_store_path": "/tmp/TrustStore.sqlite3",
            "probe_action": "not_run",
            "probe_stderr": "",
        },
    }

    print_cert_probe_status(status, as_json=False)

    output = capsys.readouterr().out
    assert "Simulator: iPhone 16e (NEW-SIM-456) [booted=no]" in output
    assert "Simulator probe: not_run" in output
    assert "Blocker: Simulator NEW-SIM-456 is not booted." in output
