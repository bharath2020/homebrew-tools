#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
SUBMODULE_DIR="$ROOT_DIR/demo-apps/wikipedia-ios"
OUTPUT_DIR="$ROOT_DIR/demo/wikipedia/output/openai"
BUILD_DIR="$ROOT_DIR/build/wikipedia-ios"
APP_PATH="$BUILD_DIR/Build/Products/Debug-iphonesimulator/Wikipedia.app"
APP_BUNDLE_ID="org.wikimedia.wikipedia"
APP_SCHEME="Wikipedia"
APP_PROJECT="$SUBMODULE_DIR/Wikipedia.xcodeproj"

ARTICLE_URL="wikipedia://en.wikipedia.org/wiki/OpenAI"
ARTICLE_TITLE="OpenAI"
SEARCH_URL="wikipedia://search"
ARTICLE_FILTER='re:https://en\.wikipedia\.org/(api/rest_v1/page/mobile-html/OpenAI$|api/rest_v1/page/summary/OpenAI$|w/api\.php\?.*prop=categories.*titles=OpenAI)'
SUMMARY_PATTERN='re:https://en\.wikipedia\.org/api/rest_v1/page/summary/OpenAI$'
MOBILE_HTML_PATTERN='re:https://en\.wikipedia\.org/api/rest_v1/page/mobile-html/OpenAI$'
CATEGORIES_PATTERN='re:https://en\.wikipedia\.org/w/api\.php\?.*prop.categories.*titles.OpenAI'
SEARCH_PATTERN='prefixsearch'
FEATURED_FEED_PATTERN='feed/featured'
PLACES_PATTERN='nearcoord:'

JSONL_FILE="$OUTPUT_DIR/live-capture.jsonl"
HAR_FILE="$OUTPUT_DIR/live-capture.har"
JAAALA_LOG="$OUTPUT_DIR/jaala.log"
FIXTURE_SUMMARY="$OUTPUT_DIR/summary-openai.json"
FIXTURE_MOBILE_HTML="$OUTPUT_DIR/mobile-html-openai.html"
FIXTURE_CATEGORIES="$OUTPUT_DIR/categories-openai.json"
SEARCH_MUTATED_FIXTURE="$OUTPUT_DIR/search-mutated.json"

SIM_UDID=""
JAAALA_PID=""
JAAALA_PORT=""
LAST_ELAPSED_MS="0"
OWNS_JAALA_SESSION="0"
PRESENT_DELAY_MS="${JAAALA_PRESENT_DELAY_MS:-5000}"
PRESENT_FAILURE_CODE="${JAAALA_PRESENT_FAILURE_CODE:-503}"
PRESENT_BODY_SEARCH="${JAAALA_PRESENT_BODY_SEARCH:-OpenAI</b> is an American}"
PRESENT_BODY_REPLACE="${JAAALA_PRESENT_BODY_REPLACE:-OpenAI</b> is <span style=\"background:#ffe066;color:#111;padding:2px 6px;border-radius:4px;font-weight:700;box-shadow:0 0 0 1px rgba(0,0,0,0.08);\">JAALA DEMO ARTICLE. THIS TEXT WAS REWRITTEN LIVE BY THE PROXY.</span> OpenAI is an American}"
SHOWCASE_DELAY_MS="${JAAALA_SHOWCASE_DELAY_MS:-8000}"
SHOWCASE_OBSERVE_SECONDS="${JAAALA_SHOWCASE_OBSERVE_SECONDS:-6}"
SHOWCASE_BODY_REPLACE="${JAAALA_SHOWCASE_BODY_REPLACE:-OpenAI</b> is <span style=\"background:#ffe066;color:#111;padding:2px 6px;border-radius:4px;font-weight:700;box-shadow:0 0 0 1px rgba(0,0,0,0.08);\">JAALA DEMO ARTICLE. THIS TEXT WAS REWRITTEN LIVE BY THE PROXY.</span> OpenAI is an American}"
REFRESH_OBSERVE_SECONDS="${JAAALA_REFRESH_OBSERVE_SECONDS:-8}"
SEARCH_QUERY="${JAAALA_SEARCH_QUERY:-Anthropic}"
SEARCH_COMPARE_OBSERVE_SECONDS="${JAAALA_SEARCH_COMPARE_OBSERVE_SECONDS:-6}"
SEARCH_MUTATED_TITLE="${JAAALA_SEARCH_MUTATED_TITLE:-JAALA SEARCH DEMO}"
SEARCH_MUTATED_DESCRIPTION="${JAAALA_SEARCH_MUTATED_DESCRIPTION:-THIS RESULT WAS REWRITTEN BY THE PROXY}"
SEARCH_RULE_NAME="${JAAALA_SEARCH_RULE_NAME:-wiki-search-demo}"
SEARCH_RULE_SEARCH="${JAAALA_SEARCH_RULE_SEARCH:-US-based AI company}"
SEARCH_RULE_REPLACE="${JAAALA_SEARCH_RULE_REPLACE:-JAALA TEMP ITEM}"
EXPLORE_RULE_NAME="${JAAALA_EXPLORE_RULE_NAME:-wiki-explore-demo}"
EXPLORE_RULE_REPLACE="${JAAALA_EXPLORE_RULE_REPLACE:-JAALA FEED DEMO}"
PLACES_LATITUDE="${JAAALA_PLACES_LATITUDE:-37.786}"
PLACES_LONGITUDE="${JAAALA_PLACES_LONGITUDE:--122.406}"
PLACES_RULE_NAME="${JAAALA_PLACES_RULE_NAME:-wiki-places-demo}"
PLACES_RULE_SEARCH="${JAAALA_PLACES_RULE_SEARCH:-Alcatraz Island}"
PLACES_RULE_REPLACE="${JAAALA_PLACES_RULE_REPLACE:-JAALA PLACES DEMO}"

require_cmd() {
    command -v "$1" >/dev/null 2>&1 || {
        echo "Missing required command: $1" >&2
        exit 1
    }
}

ensure_submodule() {
    if [[ ! -d "$SUBMODULE_DIR/.git" ]] && [[ ! -f "$SUBMODULE_DIR/.git" ]]; then
        echo "Wikipedia submodule is not initialized." >&2
        echo "Run: git submodule update --init --recursive" >&2
        exit 1
    fi
}

detect_booted_simulator() {
    SIM_UDID="$(xcrun simctl list devices booted -j 2>/dev/null | python3 -c '
import json
import sys

data = json.load(sys.stdin)
for runtime_devices in data.get("devices", {}).values():
    for device in runtime_devices:
        if device.get("state") == "Booted":
            print(device.get("udid", ""))
            raise SystemExit(0)
print("")
')"
    if [[ -z "$SIM_UDID" ]]; then
        echo "No booted simulator found. Boot a simulator and retry." >&2
        exit 1
    fi
}

ensure_output_dir() {
    mkdir -p "$OUTPUT_DIR"
}

ensure_bundle_id_config() {
    (cd "$SUBMODULE_DIR" && ./scripts/setup_bundle_id ci)
}

build_app() {
    ensure_submodule
    detect_booted_simulator
    ensure_bundle_id_config
    xcodebuild \
        -project "$APP_PROJECT" \
        -scheme "$APP_SCHEME" \
        -configuration Debug \
        -sdk iphonesimulator \
        -destination "id=$SIM_UDID" \
        -derivedDataPath "$BUILD_DIR" \
        build
}

install_app() {
    detect_booted_simulator
    if [[ ! -d "$APP_PATH" ]]; then
        echo "App is not built yet. Run '$0 build' first." >&2
        exit 1
    fi
    xcrun simctl uninstall "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
    xcrun simctl install "$SIM_UDID" "$APP_PATH"
}

describe_ui() {
    axe describe-ui --udid "$SIM_UDID" 2>/dev/null || true
}

ui_contains() {
    local needle="$1"
    describe_ui | grep -Fq "$needle"
}

wait_for_ui() {
    local needle="$1"
    local timeout_seconds="$2"
    local deadline=$(( $(date +%s) + timeout_seconds ))
    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if ui_contains "$needle"; then
            return 0
        fi
        sleep 1
    done
    return 1
}

maybe_tap_label() {
    local label="$1"
    if ui_contains "$label"; then
        axe tap --label "$label" --udid "$SIM_UDID" >/dev/null
        return 0
    fi
    return 1
}

pull_to_refresh_article() {
    axe swipe \
        --start-x 195 \
        --start-y 170 \
        --end-x 195 \
        --end-y 460 \
        --duration 0.7 \
        --post-delay 1.0 \
        --udid "$SIM_UDID" >/dev/null
}

launch_app() {
    xcrun simctl terminate "$SIM_UDID" "$APP_BUNDLE_ID" >/dev/null 2>&1 || true
    xcrun simctl launch "$SIM_UDID" "$APP_BUNDLE_ID" -AppleLanguages '(en)' -AppleLocale en_US >/dev/null
}

open_article() {
    xcrun simctl openurl "$SIM_UDID" "$ARTICLE_URL"
    sleep 2
    maybe_tap_label "Open" || true
}

open_search() {
    xcrun simctl openurl "$SIM_UDID" "$SEARCH_URL"
    sleep 2
}

open_places() {
    xcrun simctl openurl "$SIM_UDID" "wikipedia://places"
    sleep 2
}

wait_for_article() {
    local deadline=$(( $(date +%s) + 55 ))
    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if ui_contains "\"AXUniqueId\" : \"$ARTICLE_TITLE\"" || ui_contains "Table of contents"; then
            return 0
        fi
        if ui_contains "Close"; then
            maybe_tap_label "Close" || true
        fi
        sleep 1
    done
    return 1
}

prepare_app_for_article() {
    install_app
    launch_app
    wait_for_ui "Skip" 20 || true
    maybe_tap_label "Skip" || true
    sleep 2
    open_article
    if ! wait_for_article; then
        echo "Timed out waiting for the Wikipedia article view." >&2
        echo "Last UI snapshot:" >&2
        describe_ui >&2
        exit 1
    fi
}

build_search_mutated_fixture() {
    python3 - "$SEARCH_QUERY" "$SEARCH_MUTATED_TITLE" "$SEARCH_MUTATED_DESCRIPTION" "$SEARCH_MUTATED_FIXTURE" <<'PY'
import json
import sys
import urllib.parse
import urllib.request
from pathlib import Path

query = sys.argv[1]
title = sys.argv[2]
description = sys.argv[3]
output_path = Path(sys.argv[4])

params = {
    "action": "query",
    "continue": "",
    "coprop": "type|dim",
    "format": "json",
    "generator": "prefixsearch",
    "gpslimit": "24",
    "gpsnamespace": "0",
    "gpssearch": query,
    "list": "search",
    "pilimit": "24",
    "piprop": "thumbnail",
    "pithumbsize": "120",
    "ppprop": "displaytitle",
    "prop": "description|pageprops|pageimages|revisions|coordinates",
    "redirects": "1",
    "rvprop": "ids",
    "srinfo": "suggestion",
    "srlimit": "1",
    "srnamespace": "0",
    "sroffset": "0",
    "srprop": "",
    "srsearch": query,
    "srwhat": "text",
}

url = "https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode(params)
request = urllib.request.Request(
    url,
    headers={
        "User-Agent": "WikipediaApp/8.0.0.0 (iOS 18.2; Phone)",
        "Accept": "application/json; charset=utf-8",
        "Accept-Language": "en",
    },
)

with urllib.request.urlopen(request, timeout=20) as response:
    payload = json.load(response)

pages = payload.get("query", {}).get("pages", {})
target_page = None

for page in pages.values():
    if page.get("title", "").lower() == query.lower():
        target_page = page
        break

if target_page is None and pages:
    target_page = min(pages.values(), key=lambda page: page.get("index", 999999))

if target_page is None:
    raise SystemExit(f"No search results found for query {query!r}")

target_page["title"] = title
target_page["description"] = description

output_path.write_text(json.dumps(payload), encoding="utf-8")
print(output_path)
PY
}

prepare_app_for_search_query() {
    local query="$1"
    install_app
    launch_app
    wait_for_ui "Skip" 20 || true
    maybe_tap_label "Skip" || true
    sleep 2
    open_search
    maybe_tap_label "Close" || true
    maybe_tap_label "Clear text" || true
    axe tap -x 190 -y 790 --udid "$SIM_UDID" --post-delay 0.5 >/dev/null
    printf '%s' "$query" | axe type --stdin --udid "$SIM_UDID" >/dev/null
    sleep 5
}

set_places_demo_location() {
    xcrun simctl location "$SIM_UDID" set "${PLACES_LATITUDE},${PLACES_LONGITUDE}" >/dev/null
}

current_featured_feed_url() {
    python3 - <<'PY'
from datetime import datetime, timezone

now = datetime.now(timezone.utc)
print(f"https://en.wikipedia.org/api/rest_v1/feed/featured/{now.year}/{now.month:02d}/{now.day:02d}")
PY
}

current_featured_description() {
    local feed_url
    feed_url="$(current_featured_feed_url)"

    curl -s --noproxy '*' \
        -H 'User-Agent: WikipediaApp/8.0.0.0 (iOS 26.2; Phone)' \
        -H 'Accept: application/json; charset=utf-8' \
        -H 'Accept-Language: en-us' \
        "$feed_url" | python3 -c 'import json,sys; obj=json.load(sys.stdin); print(obj["tfa"].get("description", ""))'
}

wait_for_explore() {
    local deadline=$(( $(date +%s) + 30 ))
    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if ui_contains "Featured article" && ui_contains "From English Wikipedia"; then
            return 0
        fi
        maybe_tap_label "Close" || true
        maybe_tap_label "dismiss popup" || true
        sleep 1
    done
    return 1
}

prepare_app_for_explore() {
    install_app
    launch_app
    wait_for_ui "Skip" 20 || true
    maybe_tap_label "Skip" || true
    if ! wait_for_explore; then
        echo "Timed out waiting for the Wikipedia Explore screen." >&2
        echo "Last UI snapshot:" >&2
        describe_ui >&2
        exit 1
    fi
}

wait_for_places() {
    local deadline=$(( $(date +%s) + 40 ))
    while [[ "$(date +%s)" -le "$deadline" ]]; do
        if ui_contains "JAALA PLACES DEMO" || ui_contains "$PLACES_RULE_SEARCH" || ui_contains "Places"; then
            return 0
        fi
        maybe_tap_label "Enable location" || true
        maybe_tap_label "Allow While Using App" || true
        maybe_tap_label "Allow Once" || true
        sleep 1
    done
    return 1
}

prepare_app_for_places() {
    install_app
    set_places_demo_location
    launch_app
    wait_for_ui "Skip" 20 || true
    maybe_tap_label "Skip" || true
    sleep 1
    open_places
    maybe_tap_label "Enable location" || true
    maybe_tap_label "Allow While Using App" || true
    maybe_tap_label "Allow Once" || true
    if ! wait_for_places; then
        echo "Timed out waiting for the Wikipedia Places screen." >&2
        echo "Last UI snapshot:" >&2
        describe_ui >&2
        exit 1
    fi
}

prepare_app_for_article_nonfatal() {
    install_app
    launch_app
    wait_for_ui "Skip" 20 || true
    maybe_tap_label "Skip" || true
    sleep 2
    open_article
    if ! wait_for_article; then
        echo "Wikipedia did not fully load the article view, which is expected for some failure demos."
        echo "Last UI snapshot:"
        describe_ui
        return 1
    fi
}

timed_prepare_app_for_article() {
    local start_ms end_ms
    start_ms="$(now_ms)"
    prepare_app_for_article
    end_ms="$(now_ms)"
    LAST_ELAPSED_MS=$(( end_ms - start_ms ))
}

find_free_port() {
    python3 - <<'PY'
import socket

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    sock.bind(("127.0.0.1", 0))
    print(sock.getsockname()[1])
PY
}

now_ms() {
    python3 - <<'PY'
import time

print(int(time.time() * 1000))
PY
}

wait_for_port() {
    local port="$1"
    local timeout_seconds="$2"
    python3 - "$port" "$timeout_seconds" <<'PY'
import socket
import sys
import time

port = int(sys.argv[1])
deadline = time.monotonic() + float(sys.argv[2])
while time.monotonic() < deadline:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.2):
            raise SystemExit(0)
    except OSError:
        time.sleep(0.1)
raise SystemExit(1)
PY
}

start_jaala() {
    ensure_output_dir
    rm -f "$JSONL_FILE" "$HAR_FILE" "$JAAALA_LOG"
    JAAALA_PORT="$(find_free_port)"
    python3 -m jaala \
        --quiet \
        --port "$JAAALA_PORT" \
        --json-file "$JSONL_FILE" \
        --save-har "$HAR_FILE" \
        "$@" >"$JAAALA_LOG" 2>&1 &
    JAAALA_PID=$!
    OWNS_JAALA_SESSION="1"
    if ! wait_for_port "$JAAALA_PORT" 30; then
        echo "Jaala did not start on port $JAAALA_PORT" >&2
        sed -n '1,200p' "$JAAALA_LOG" >&2 || true
        exit 1
    fi
}

start_fixture_jaala() {
    start_jaala \
        --filter "$ARTICLE_FILTER" \
        --map-local "$MOBILE_HTML_PATTERN=$FIXTURE_MOBILE_HTML" \
        "$@"
}

stop_jaala() {
    if [[ -n "${JAAALA_PID:-}" ]] && kill -0 "$JAAALA_PID" >/dev/null 2>&1; then
        kill -TERM "$JAAALA_PID" >/dev/null 2>&1 || true
        wait "$JAAALA_PID" >/dev/null 2>&1 || true
    fi
    JAAALA_PID=""
    OWNS_JAALA_SESSION="0"
    python3 -m jaala --cleanup >/dev/null 2>&1 || true
}

wait_for_jaala() {
    if [[ -n "${JAAALA_PID:-}" ]]; then
        wait "$JAAALA_PID" || true
    fi
}

extract_fixtures() {
    python3 - "$JSONL_FILE" "$FIXTURE_SUMMARY" "$FIXTURE_MOBILE_HTML" "$FIXTURE_CATEGORIES" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
summary_path = Path(sys.argv[2])
mobile_html_path = Path(sys.argv[3])
categories_path = Path(sys.argv[4])

records = [json.loads(line) for line in jsonl_path.read_text(encoding="utf-8").splitlines() if line.strip()]

targets = {
    "summary": None,
    "mobile_html": None,
    "categories": None,
}

for record in records:
    url = record.get("url", "")
    response = record.get("response", {})
    body = response.get("body")
    if url.endswith("/page/summary/OpenAI") and body is not None:
        targets["summary"] = body
    elif url.endswith("/page/mobile-html/OpenAI") and body is not None:
        targets["mobile_html"] = body
    elif "prop=categories" in url and "titles=OpenAI" in url and body is not None:
        targets["categories"] = body

missing = [name for name, body in targets.items() if body is None]
if missing:
    raise SystemExit(f"Missing bodies for fixtures: {missing}")

summary_path.write_text(
    json.dumps(targets["summary"], ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)
mobile_html_path.write_text(str(targets["mobile_html"]), encoding="utf-8")
categories_path.write_text(
    json.dumps(targets["categories"], ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)
PY
}

require_fixtures() {
    for path in "$FIXTURE_SUMMARY" "$FIXTURE_MOBILE_HTML" "$FIXTURE_CATEGORIES"; do
        if [[ ! -f "$path" ]]; then
            echo "Missing fixture: $path" >&2
            echo "Run '$0 record' first." >&2
            exit 1
        fi
    done
}

assert_capture_contains_targets() {
    python3 - "$JSONL_FILE" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
urls = {record.get("url", "") for record in records}
required = [
    "https://en.wikipedia.org/api/rest_v1/page/mobile-html/OpenAI",
    "https://en.wikipedia.org/api/rest_v1/page/summary/OpenAI",
]
missing = [url for url in required if url not in urls]
if missing:
    raise SystemExit(f"Capture missing URLs: {missing}")

if not any("prop=categories" in url and "titles=OpenAI" in url for url in urls):
    raise SystemExit("Capture missing categories request for OpenAI")
PY
}

assert_capture_matches_fixtures() {
    python3 - "$JSONL_FILE" "$FIXTURE_SUMMARY" "$FIXTURE_MOBILE_HTML" "$FIXTURE_CATEGORIES" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
summary_path = Path(sys.argv[2])
mobile_html_path = Path(sys.argv[3])
categories_path = Path(sys.argv[4])

records = [json.loads(line) for line in jsonl_path.read_text(encoding="utf-8").splitlines() if line.strip()]

def normalize(value):
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith("{") or stripped.startswith("["):
            try:
                return json.loads(stripped)
            except json.JSONDecodeError:
                return value
    return value

captured = {}
for record in records:
    url = record.get("url", "")
    body = normalize(record.get("response", {}).get("body"))
    if url.endswith("/page/summary/OpenAI") and body is not None:
        captured["summary"] = body
    elif url.endswith("/page/mobile-html/OpenAI") and body is not None:
        captured["mobile_html"] = body
    elif "prop=categories" in url and "titles=OpenAI" in url and body is not None:
        captured["categories"] = body

expected = {
    "summary": normalize(summary_path.read_text(encoding="utf-8")),
    "mobile_html": normalize(mobile_html_path.read_text(encoding="utf-8")),
    "categories": normalize(categories_path.read_text(encoding="utf-8")),
}

missing = [name for name in expected if name not in captured]
if missing:
    raise SystemExit(f"Capture missing bodies for replay verification: {missing}")

for key, expected_body in expected.items():
    if captured[key] != expected_body:
        raise SystemExit(f"Replay body mismatch for {key}")
PY
}

assert_url_status() {
    local expected_url="$1"
    local expected_status="$2"
    python3 - "$JSONL_FILE" "$expected_url" "$expected_status" <<'PY'
import json
import sys
from pathlib import Path

jsonl_path = Path(sys.argv[1])
expected_url = sys.argv[2]
expected_status = int(sys.argv[3])

records = [json.loads(line) for line in jsonl_path.read_text(encoding="utf-8").splitlines() if line.strip()]

statuses = [
    record.get("status")
    for record in records
    if record.get("url") == expected_url
]

if not statuses:
    raise SystemExit(f"Capture missing URL for status assertion: {expected_url}")

if expected_status not in statuses:
    raise SystemExit(
        f"Expected status {expected_status} for {expected_url}, saw {statuses}"
    )
PY
}

record_demo() {
    build_app
    start_jaala --filter "$ARTICLE_FILTER"
    prepare_app_for_article
    sleep 5
    stop_jaala
    assert_capture_contains_targets
    extract_fixtures
    echo "Recorded live Wikipedia traffic to:"
    echo "  $JSONL_FILE"
    echo "  $HAR_FILE"
    echo "Generated fixtures:"
    echo "  $FIXTURE_SUMMARY"
    echo "  $FIXTURE_MOBILE_HTML"
    echo "  $FIXTURE_CATEGORIES"
}

replay_demo() {
    build_app
    require_fixtures
    start_fixture_jaala
    prepare_app_for_article
    sleep 5
    stop_jaala
    assert_capture_contains_targets
    assert_capture_matches_fixtures
    echo "Replayed OpenAI fixtures through Jaala."
    echo "Capture artifacts:"
    echo "  $JSONL_FILE"
    echo "  $HAR_FILE"
}

replay_delay_demo() {
    build_app
    require_fixtures
    start_fixture_jaala \
        --delay "$MOBILE_HTML_PATTERN=1500"
    timed_prepare_app_for_article
    sleep 5
    stop_jaala
    assert_capture_contains_targets
    assert_capture_matches_fixtures
    if (( LAST_ELAPSED_MS < 1500 )); then
        echo "Expected delayed replay to take at least 1500ms, saw ${LAST_ELAPSED_MS}ms" >&2
        exit 1
    fi
    echo "Replayed OpenAI fixtures with delayed mobile-html response (${LAST_ELAPSED_MS}ms)."
}

replay_status_demo() {
    build_app
    require_fixtures
    start_fixture_jaala \
        --status-code "$SUMMARY_PATTERN=503"
    prepare_app_for_article
    sleep 5
    stop_jaala
    assert_capture_contains_targets
    assert_url_status "https://en.wikipedia.org/api/rest_v1/page/summary/OpenAI" 503
    echo "Replayed OpenAI fixtures with summary status override to 503."
}

present_delay_demo() {
    build_app
    require_fixtures
    start_fixture_jaala \
        --delay "$MOBILE_HTML_PATTERN=${PRESENT_DELAY_MS}"
    echo "Wikipedia visible demo: delayed article body replay"
    echo "What to watch in Simulator:"
    echo "  - Wikipedia opens the OpenAI article"
    echo "  - article content should remain loading for about ${PRESENT_DELAY_MS}ms"
    echo "  - then the cached fixture-backed article appears"
    echo ""
    echo "Press Ctrl+C when you are done observing the delayed load."
    prepare_app_for_article
    wait_for_jaala
}

present_failure_demo() {
    build_app
    require_fixtures
    start_fixture_jaala \
        --status-code "$MOBILE_HTML_PATTERN=${PRESENT_FAILURE_CODE}"
    echo "Wikipedia visible demo: forced article failure"
    echo "What to watch in Simulator:"
    echo "  - Wikipedia opens the OpenAI article"
    echo "  - Jaala forces the main article HTML endpoint to HTTP ${PRESENT_FAILURE_CODE}"
    echo "  - the article should fail or render an obvious error/empty state"
    echo ""
    echo "Press Ctrl+C when you are done observing the failure state."
    prepare_app_for_article_nonfatal || true
    wait_for_jaala
}

present_body_demo() {
    build_app
    require_fixtures
    start_fixture_jaala \
        --body-replace "$MOBILE_HTML_PATTERN=${PRESENT_BODY_SEARCH}>>>${PRESENT_BODY_REPLACE}"
    echo "Wikipedia visible demo: mutated article body"
    echo "What to watch in Simulator:"
    echo "  - Wikipedia opens the OpenAI article"
    echo "  - the opening paragraph should contain a yellow highlighted block that says:"
    echo "      JAALA DEMO ARTICLE. THIS TEXT WAS REWRITTEN LIVE BY THE PROXY."
    echo ""
    echo "Press Ctrl+C when you are done observing the body mutation."
    prepare_app_for_article
    wait_for_jaala
}

present_refresh_body_demo() {
    build_app
    require_fixtures
    stop_jaala
    echo "Wikipedia visible demo: refresh into mutated article"
    echo "What to watch in Simulator:"
    echo "  - the OpenAI article first loads normally from live Wikipedia"
    echo "  - Jaala then starts with a highlighted body mutation rule"
    echo "  - a pull-to-refresh updates the already-open article into the highlighted proxy-mutated version"
    echo ""
    echo "The script will perform the refresh gesture automatically."
    prepare_app_for_article
    sleep 2
    start_fixture_jaala \
        --body-replace "$MOBILE_HTML_PATTERN=${PRESENT_BODY_SEARCH}>>>${PRESENT_BODY_REPLACE}"
    sleep 1
    pull_to_refresh_article
    sleep "$REFRESH_OBSERVE_SECONDS"
    wait_for_jaala
}

showcase_phase() {
    local title="$1"
    local watch_text="$2"
    local observe_seconds="$3"
    local prepare_mode="${4:-normal}"
    shift 4

    echo ""
    echo "============================================================"
    echo "$title"
    echo "Watch for: $watch_text"
    echo "============================================================"
    start_fixture_jaala "$@"
    if [[ "$prepare_mode" == "nonfatal" ]]; then
        prepare_app_for_article_nonfatal || true
    else
        prepare_app_for_article
    fi
    sleep "$observe_seconds"
    stop_jaala
}

present_showcase_demo() {
    build_app
    require_fixtures
    echo "Wikipedia feature showcase"
    echo "This runs four visible Jaala scenarios against the same familiar OpenAI article."
    echo "Each phase relaunches the official Wikipedia app on the booted simulator."
    echo ""
    echo "Phases:"
    echo "  1. baseline local replay"
    echo "  2. body mutation in the rendered article"
    echo "  3. delayed article HTML response"
    echo "  4. forced server failure"

    showcase_phase \
        "Phase 1/4: Baseline replay" \
        "The OpenAI article should load normally from local Jaala fixtures, not live Wikipedia responses." \
        "$SHOWCASE_OBSERVE_SECONDS" \
        normal

    showcase_phase \
        "Phase 2/4: Visible body mutation" \
        "The opening paragraph should visibly announce that the article text was rewritten by the proxy." \
        "$SHOWCASE_OBSERVE_SECONDS" \
        normal \
        --body-replace "$MOBILE_HTML_PATTERN=${PRESENT_BODY_SEARCH}>>>${SHOWCASE_BODY_REPLACE}"

    showcase_phase \
        "Phase 3/4: Delay injection" \
        "The article should sit loading for about ${SHOWCASE_DELAY_MS}ms before content appears." \
        "$SHOWCASE_OBSERVE_SECONDS" \
        normal \
        --delay "$MOBILE_HTML_PATTERN=${SHOWCASE_DELAY_MS}"

    showcase_phase \
        "Phase 4/4: Forced article failure" \
        "The app should show the article load error state after Jaala forces HTTP ${PRESENT_FAILURE_CODE}." \
        "$SHOWCASE_OBSERVE_SECONDS" \
        nonfatal \
        --status-code "$MOBILE_HTML_PATTERN=${PRESENT_FAILURE_CODE}"

    echo ""
    echo "Showcase complete."
}

present_search_compare_demo() {
    build_app
    build_search_mutated_fixture
    stop_jaala

    echo "Wikipedia visible demo: search before/after proxy rewrite"
    echo "What to watch in Simulator:"
    echo "  1. Wikipedia searches for ${SEARCH_QUERY} and shows the real result list first"
    echo "  2. The app relaunches and searches for the same query again through Jaala"
    echo "  3. The first result is replaced with:"
    echo "      ${SEARCH_MUTATED_TITLE}"
    echo "      ${SEARCH_MUTATED_DESCRIPTION}"
    echo ""
    echo "Baseline search is shown for ${SEARCH_COMPARE_OBSERVE_SECONDS}s before the injected rerun begins."

    prepare_app_for_search_query "$SEARCH_QUERY"
    sleep "$SEARCH_COMPARE_OBSERVE_SECONDS"

    start_jaala \
        --filter-user-agent 'WikipediaApp/' \
        --filter "$SEARCH_PATTERN" \
        --map-local "$SEARCH_PATTERN=$SEARCH_MUTATED_FIXTURE"
    prepare_app_for_search_query "$SEARCH_QUERY"

    echo ""
    echo "Injected search result is now on screen."
    echo "Press Ctrl+C when you are done observing the rewritten result."
    wait_for_jaala
}

present_search_live_start_demo() {
    build_app
    start_jaala \
        --filter-user-agent 'WikipediaApp/'

    echo "Wikipedia live search demo: pass-through first, injection later"
    echo "Jaala is already running and proxying Wikipedia app traffic."
    echo "What to watch in Simulator now:"
    echo "  - the app searches for ${SEARCH_QUERY}"
    echo "  - the result list is the real Wikipedia response"
    echo ""
    echo "Then, in another terminal, run:"
    echo "  ./demo/wikipedia/jaala-wikipedia-demo.sh present-search-live-inject"
    echo ""
    echo "That command uses 'jaala rules add body-replace' and reruns the same query."
    echo "Press Ctrl+C here when you want to stop the live Jaala session."

    prepare_app_for_search_query "$SEARCH_QUERY"
    wait_for_jaala
}

present_search_live_inject_demo() {
    detect_booted_simulator

    python3 -m jaala rules add body-replace \
        --name "$SEARCH_RULE_NAME" \
        --match-url "$SEARCH_PATTERN" \
        --search "$SEARCH_RULE_SEARCH" \
        --replace "$SEARCH_RULE_REPLACE"

    echo "Updated the running Jaala session through the CLI runtime-rules interface."
    echo "Rerunning the same query now."
    prepare_app_for_search_query "$SEARCH_QUERY"
}

present_explore_live_start_demo() {
    build_app
    start_jaala \
        --filter-user-agent 'WikipediaApp/'

    echo "Wikipedia live Explore demo: pass-through first, injection later"
    echo "Jaala is already running and proxying Wikipedia app traffic."
    echo "What to watch in Simulator now:"
    echo "  - the app opens on Explore"
    echo "  - the Featured article card shows the real subtitle from live Wikipedia"
    echo ""
    echo "Then, in another terminal, run:"
    echo "  ./demo/wikipedia/jaala-wikipedia-demo.sh present-explore-live-inject"
    echo ""
    echo "That command uses 'jaala rules add body-replace' and reinstalls the app"
    echo "so Explore refetches the featured feed without restarting Jaala."
    echo "Press Ctrl+C here when you want to stop the live Jaala session."

    prepare_app_for_explore
    wait_for_jaala
}

present_explore_live_inject_demo() {
    local featured_description

    detect_booted_simulator
    featured_description="$(current_featured_description)"
    if [[ -z "$featured_description" ]]; then
        echo "Could not determine the current featured-article subtitle." >&2
        exit 1
    fi

    python3 -m jaala rules add body-replace \
        --name "$EXPLORE_RULE_NAME" \
        --match-url "$FEATURED_FEED_PATTERN" \
        --search "$featured_description" \
        --replace "$EXPLORE_RULE_REPLACE"

    echo "Updated the running Jaala session through the CLI runtime-rules interface."
    echo "Current featured subtitle: $featured_description"
    echo "Relaunching Explore now so the featured feed is fetched through the updated proxy."
    prepare_app_for_explore
}

present_places_live_start_demo() {
    build_app
    start_jaala \
        --filter-user-agent 'WikipediaApp/'

    echo "Wikipedia live Places demo: pass-through first, injection later"
    echo "Jaala is already running and proxying Wikipedia app traffic."
    echo "What to watch in Simulator now:"
    echo "  - the app opens on Places with a fixed San Francisco simulator location"
    echo "  - the map shows the real nearby article annotations first"
    echo ""
    echo "Then, in another terminal, run:"
    echo "  ./demo/wikipedia/jaala-wikipedia-demo.sh present-places-live-inject"
    echo ""
    echo "That command uses 'jaala rules add body-replace' and reinstalls the app"
    echo "so Places refetches the nearby query without restarting Jaala."
    echo "Press Ctrl+C here when you want to stop the live Jaala session."

    prepare_app_for_places
    wait_for_jaala
}

present_places_live_inject_demo() {
    detect_booted_simulator

    python3 -m jaala rules add body-replace \
        --name "$PLACES_RULE_NAME" \
        --match-url "$PLACES_PATTERN" \
        --search "$PLACES_RULE_SEARCH" \
        --replace "$PLACES_RULE_REPLACE"

    echo "Updated the running Jaala session through the CLI runtime-rules interface."
    echo "Relaunching Places now so the nearby query is fetched through the updated proxy."
    prepare_app_for_places
}

validate_demo() {
    record_demo
    replay_demo
    replay_delay_demo
    replay_status_demo
}

usage() {
    cat <<EOF
Usage: $0 <command>

Commands:
  build      Build the official Wikipedia iOS app for the booted simulator
  record     Capture live OpenAI article traffic and extract Jaala fixtures
  replay     Replay the extracted fixtures through Jaala
  present-body    Show a visibly mutated OpenAI article body in Simulator
  present-search-compare Show live search results first, then rerun the same query with an injected result
  present-search-live-start Start Jaala in pass-through mode for live search, then wait for an inject command
  present-search-live-inject Add a live body-replace rule through Jaala CLI and rerun the same query
  present-explore-live-start Start Jaala in pass-through mode for Explore, then wait for an inject command
  present-explore-live-inject Add a live body-replace rule for the Explore featured card and relaunch the app
  present-places-live-start Start Jaala in pass-through mode for Places, then wait for an inject command
  present-places-live-inject Add a live body-replace rule for the Places map and relaunch the app
  present-refresh-body Load live article first, then pull-to-refresh into a visible mutation
  present-delay   Show a visibly delayed OpenAI article load in Simulator
  present-failure Show a visibly failed OpenAI article load in Simulator
  present-showcase Run a multi-phase visible Jaala feature showcase in Simulator
  validate   Run record, replay, delayed replay, and status-override replay
EOF
}

main() {
    require_cmd python3
    require_cmd xcodebuild
    require_cmd xcrun
    require_cmd axe
    require_cmd mitmdump

    case "${1:-}" in
        build)
            build_app
            ;;
        record)
            record_demo
            ;;
        replay)
            replay_demo
            ;;
        present-body)
            present_body_demo
            ;;
        present-search-compare)
            present_search_compare_demo
            ;;
        present-search-live-start)
            present_search_live_start_demo
            ;;
        present-search-live-inject)
            present_search_live_inject_demo
            ;;
        present-explore-live-start)
            present_explore_live_start_demo
            ;;
        present-explore-live-inject)
            present_explore_live_inject_demo
            ;;
        present-places-live-start)
            present_places_live_start_demo
            ;;
        present-places-live-inject)
            present_places_live_inject_demo
            ;;
        present-refresh-body)
            present_refresh_body_demo
            ;;
        present-delay)
            present_delay_demo
            ;;
        present-failure)
            present_failure_demo
            ;;
        present-showcase)
            present_showcase_demo
            ;;
        validate)
            validate_demo
            ;;
        *)
            usage
            exit 1
            ;;
    esac
}

trap 'if [[ "${OWNS_JAALA_SESSION:-0}" == "1" ]]; then stop_jaala; fi' EXIT INT TERM

main "$@"
