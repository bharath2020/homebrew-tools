# Jaala Wikipedia Demo

This demo uses the official Wikimedia iOS app from the pinned submodule at
`demo-apps/wikipedia-ios`.

It demonstrates a small Pact-style workflow around one stable read-only flow:
opening the `OpenAI` article from the official app and capturing the core
provider responses Jaala sees on the simulator.

## What It Does

The demo script:

1. builds the official Wikipedia iOS app for the booted simulator
2. installs a clean copy
3. skips onboarding if it appears
4. deep-links to `wikipedia://en.wikipedia.org/wiki/OpenAI`
5. records the article traffic through Jaala
6. extracts local fixtures for the core article endpoints
7. validates the same flow under exact replay, delayed replay, and status-override replay

The core endpoints used for this demo are:

- `page/mobile-html/OpenAI`
- `page/summary/OpenAI`
- the `prop=categories&titles=OpenAI` query

## Prerequisites

- booted iOS Simulator
- Xcode
- `axe`
- `mitmdump`
- initialized submodule:

```bash
git submodule update --init --recursive
```

## Commands

Build the app:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh build
```

Record live traffic and generate local fixtures:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh record
```

Replay the generated fixtures through Jaala:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh replay
```

Run a presenter-friendly visible delay demo in the simulator:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh present-delay
```

Run a presenter-friendly visible body-mutation demo in the simulator:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh present-body
```

Run a presenter-friendly visible search before/after demo in the simulator:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh present-search-compare
```

Run Jaala live first, then update the running proxy with a second command:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh present-search-live-start
./demo/wikipedia/jaala-wikipedia-demo.sh present-search-live-inject
```

Run the same no-restart runtime-rule demo against the Explore featured card:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh present-explore-live-start
./demo/wikipedia/jaala-wikipedia-demo.sh present-explore-live-inject
```

Run the same no-restart runtime-rule demo against the Places tab:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh present-places-live-start
./demo/wikipedia/jaala-wikipedia-demo.sh present-places-live-inject
```

Run a presenter-friendly visible failure demo in the simulator:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh present-failure
```

Run a multi-phase visible Jaala showcase in the simulator:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh present-showcase
```

Run the full demo flow:

```bash
./demo/wikipedia/jaala-wikipedia-demo.sh validate
```

The presentation commands assume `record` has already been run once so the
local OpenAI fixtures already exist.

## Output

Generated artifacts are written to `demo/wikipedia/output/openai/` and are not
tracked by git.

That directory contains:

- `live-capture.jsonl`
- `live-capture.har`
- `summary-openai.json`
- `mobile-html-openai.html`
- `categories-openai.json`

## Pact-Style Story

The demo is intentionally narrow:

- `record` captures live provider traffic from a real open-source client
- `extract` turns the captured responses into local contract fixtures
- `replay` proves the same client flow can be exercised through Jaala using the
  captured fixtures instead of depending entirely on live provider responses
- `present-body` rewrites visible article text in the captured HTML so the
  audience can see Jaala mutate real app content live
- `present-search-compare` shows a live Wikipedia search result list first, then
  reruns the same query through Jaala so the first result is visibly rewritten
  by the proxy
- `present-search-live-start` keeps Jaala running in pass-through mode so the
  audience sees a normal live search first, and
  `present-search-live-inject` adds a live `body-replace` rule through
  `jaala rules add body-replace ...` so rerunning the same query shows the
  injected result without restarting Jaala
- `present-explore-live-start` keeps Jaala running in pass-through mode on the
  Explore screen so the audience sees the real featured-article card first, and
  `present-explore-live-inject` adds a live `body-replace` rule through
  `jaala rules add body-replace ...` so reinstalling and relaunching the app
  fetches the same featured card through the updated proxy without restarting
  Jaala
- `present-places-live-start` keeps Jaala running in pass-through mode on the
  Places tab with a fixed San Francisco simulator location so the audience sees
  the real nearby map annotations first, and `present-places-live-inject` adds
  a live `body-replace` rule through `jaala rules add body-replace ...` so
  reinstalling and relaunching the app fetches the same nearby query through
  the updated proxy without restarting Jaala
- `present-delay` shows an intentionally slow article load using the captured
  fixtures so the delay is obvious to someone watching the simulator
- `present-failure` forces the main article HTML request to fail so the app's
  user-visible failure behavior can be demonstrated live
- `present-showcase` strings those visible scenarios together into one automated
  run so the audience can watch local replay, body mutation, delay injection,
  and failure injection in sequence without manually restarting the app
- `validate` extends that with delayed replay and forced status overrides on the
  same captured endpoints

From there, Jaala can add mutations such as delay, throttling, dropped requests,
status overrides, or body replacement on the same endpoints.
