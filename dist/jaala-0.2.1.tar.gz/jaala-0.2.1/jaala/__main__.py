"""Jaala entry point."""

from __future__ import annotations

import atexit
import json
import os
import signal
import sys
import uuid
from pathlib import Path

from .certs import ensure_ca_cert, trust_ca_cert_in_macos
from .cli import (
    cli_capabilities,
    emit_json,
    format_root_help,
    parse_args,
    parse_capabilities_args,
    parse_cert_args,
    parse_cleanup_args,
    parse_record_args,
    parse_replay_args,
    parse_rules_args,
    parse_run_args,
    parse_scenario_args,
    parse_sims_args,
    parse_sockets_args,
    parse_status_args,
    parse_streams_args,
)
from .filtering import build_matcher, resolve_filter_settings
from .network_conditions import build_network_condition_rules, resolve_network_condition_settings
from .network import ProxyConfig
from .preflight import run_all as preflight_checks
from .proxy import find_free_port, start_mitmdump
from .readiness import (
    collect_cert_probe_status,
    collect_readiness_status,
    print_cert_probe_status,
    print_readiness_status,
)
from .request_rules import build_request_rules, resolve_request_settings
from .response_rules import build_response_rules, resolve_response_settings
from .runtime_rules import (
    add_body_replace_rule,
    add_json_replace_rule,
    add_request_header_rule,
    build_runtime_http_config,
    enqueue_stream_event,
    enqueue_websocket_event,
    list_runtime_rules,
    runtime_config_path,
    runtime_status_path,
    remove_runtime_rule,
    set_runtime_rule_enabled,
    write_runtime_config,
)
from .session import LOCK_DIR, check_stale_session, do_cleanup, read_lock, remove_lock, write_lock
from .simulator import install_cert_in_simulator, print_simulators, resolve_simulator
from .websocket_message_rules import (
    build_websocket_message_rules,
    resolve_websocket_message_settings,
)
from .websocket_replay import build_websocket_replay, resolve_websocket_replay_settings


def _active_session_lock() -> dict:
    lock = read_lock()
    if lock is None:
        print("Error: No active Jaala session found.", file=sys.stderr)
        raise SystemExit(1)
    pid = lock.get("pid")
    from .session import is_process_running

    if not pid or not is_process_running(int(pid)):
        print("Error: Jaala session lock is stale. Run: jaala --cleanup", file=sys.stderr)
        raise SystemExit(1)
    return lock


def _load_json_file(path: str | None) -> dict:
    if not path:
        return {}
    file_path = Path(path)
    if not file_path.is_file():
        return {}
    with file_path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    return data if isinstance(data, dict) else {}


def _handle_rules(argv: list[str]) -> int:
    args = parse_rules_args(argv)
    lock = _active_session_lock()
    runtime_config = lock.get("runtime_config_path")
    runtime_status = lock.get("runtime_status_path")
    if not runtime_config:
        print("Error: Active session does not expose a runtime rules file.", file=sys.stderr)
        return 1

    if args.rules_command == "show":
        payload = {"runtime_config_path": runtime_config, "rules": list_runtime_rules(runtime_config)}
        if args.json_output:
            emit_json(payload)
        else:
            print(f"Runtime config: {runtime_config}")
            rules = payload["rules"]
            if not rules:
                print("No runtime rules configured.")
            for rule in rules:
                print(
                    f"{rule.get('name')} [{rule.get('type')}] "
                    f"enabled={'yes' if rule.get('enabled', True) else 'no'} "
                    f"match_url={rule.get('match_url')!r}"
                )
        return 0

    if args.rules_command == "status":
        payload = _load_json_file(runtime_status)
        if args.json_output:
            emit_json(payload)
        else:
            if not payload:
                print("Runtime status unavailable.")
            else:
                print(f"Outcome: {payload.get('outcome', '-')}")
                print(f"Reason: {payload.get('reason', '-')}")
                print(f"Config: {payload.get('config_path', '-')}")
                print(f"Active body_replace: {payload.get('active_body_replace') or '-'}")
                if payload.get("last_error"):
                    print(f"Error: {payload['last_error']}")
        return 0

    if args.rules_command in {"enable", "disable", "remove"}:
        try:
            if args.rules_command == "enable":
                set_runtime_rule_enabled(runtime_config, name=args.name, enabled=True)
            elif args.rules_command == "disable":
                set_runtime_rule_enabled(runtime_config, name=args.name, enabled=False)
            else:
                remove_runtime_rule(runtime_config, name=args.name)
        except ValueError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1

        action_label = {
            "enable": "Enabled",
            "disable": "Disabled",
            "remove": "Removed",
        }[args.rules_command]
        if args.json_output:
            emit_json({"updated": True, "name": args.name, "action": args.rules_command, "runtime_config_path": runtime_config})
        else:
            print(f"{action_label} runtime rule {args.name!r}.")
        return 0

    if args.rules_command == "add" and args.rule_type == "body-replace":
        add_body_replace_rule(
            runtime_config,
            name=args.name,
            match_url=args.match_url,
            search=args.search,
            replace=args.replace,
        )
        if args.json_output:
            emit_json({"updated": True, "name": args.name, "runtime_config_path": runtime_config})
        else:
            print(f"Updated runtime rule {args.name!r}.")
        return 0

    if args.rules_command == "add" and args.rule_type == "json-replace":
        value = args.value_string
        if args.value_json is not None:
            try:
                value = json.loads(args.value_json)
            except json.JSONDecodeError as exc:
                print(f"Error: invalid --value-json: {exc}", file=sys.stderr)
                return 1
        add_json_replace_rule(
            runtime_config,
            name=args.name,
            match_url=args.match_url,
            json_path=args.json_path,
            value=value,
        )
        if args.json_output:
            emit_json({"updated": True, "name": args.name, "runtime_config_path": runtime_config})
        else:
            print(f"Updated runtime rule {args.name!r}.")
        return 0

    if args.rules_command == "add" and args.rule_type == "request-header":
        add_request_header_rule(
            runtime_config,
            name=args.name,
            match_url=args.match_url,
            header_name=args.header_name,
            header_value=args.header_value,
        )
        if args.json_output:
            emit_json({"updated": True, "name": args.name, "runtime_config_path": runtime_config})
        else:
            print(f"Updated runtime rule {args.name!r}.")
        return 0

    print("Error: unsupported rules command.", file=sys.stderr)
    return 1


def _read_text_payload(*, text: str | None, text_file: str | None, label: str) -> str:
    if (text is not None) == (text_file is not None):
        raise ValueError(f"Provide exactly one of --{label} or --{label}-file")
    if text is not None:
        return text
    assert text_file is not None
    return Path(text_file).read_text(encoding="utf-8")


def _active_runtime_config_path() -> str:
    lock = _active_session_lock()
    runtime_config = lock.get("runtime_config_path")
    if not runtime_config:
        print("Error: Active session does not expose a runtime rules file.", file=sys.stderr)
        raise SystemExit(1)
    return runtime_config


def _handle_sockets(argv: list[str]) -> int:
    args = parse_sockets_args(argv)
    if args.sockets_command != "send":
        print("Error: unsupported sockets command.", file=sys.stderr)
        return 1
    try:
        payload = _read_text_payload(text=args.text, text_file=args.text_file, label="text")
        runtime_config = _active_runtime_config_path()
        event_id = args.id or f"ws-{uuid.uuid4().hex}"
        enqueue_websocket_event(
            runtime_config,
            event_id=event_id,
            match_url=args.match_url,
            text=payload,
            drop_live_server_messages=args.drop_live_server_messages,
        )
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    result = {
        "queued": True,
        "id": event_id,
        "match_url": args.match_url,
        "runtime_config_path": runtime_config,
    }
    if args.json_output:
        emit_json(result)
    else:
        print(f"Queued WebSocket event {event_id!r}.")
    return 0


def _format_stream_payload(args) -> str:
    raw_text = args.text is not None or args.text_file is not None
    sse_text = args.data is not None or args.data_json is not None or args.event is not None
    if raw_text and sse_text:
        raise ValueError("Use either --text/--text-file or SSE --event/--data/--data-json options")
    if raw_text:
        return _read_text_payload(text=args.text, text_file=args.text_file, label="text")
    if args.data is not None and args.data_json is not None:
        raise ValueError("Use only one of --data or --data-json")
    if args.data_json is not None:
        try:
            data = json.dumps(json.loads(args.data_json), separators=(",", ":"), ensure_ascii=False)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid --data-json: {exc}") from exc
    else:
        data = args.data or ""
    lines = []
    if args.event:
        lines.append(f"event: {args.event}")
    for line in data.splitlines() or [""]:
        lines.append(f"data: {line}")
    return "\n".join(lines) + "\n\n"


def _handle_streams(argv: list[str]) -> int:
    args = parse_streams_args(argv)
    if args.streams_command != "send":
        print("Error: unsupported streams command.", file=sys.stderr)
        return 1
    try:
        chunk = _format_stream_payload(args)
        runtime_config = _active_runtime_config_path()
        event_id = args.id or f"stream-{uuid.uuid4().hex}"
        enqueue_stream_event(
            runtime_config,
            event_id=event_id,
            match_url=args.match_url,
            chunk=chunk,
            event=args.event,
        )
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    result = {
        "queued": True,
        "id": event_id,
        "match_url": args.match_url,
        "runtime_config_path": runtime_config,
    }
    if args.json_output:
        emit_json(result)
    else:
        print(f"Queued stream event {event_id!r}.")
    return 0


def _record_argv(argv: list[str]) -> list[str]:
    args = parse_record_args(argv)
    translated: list[str] = []
    for name, flag in (
        ("sim", "--sim"),
        ("port", "--port"),
        ("filter", "--filter"),
        ("filter_user_agent", "--filter-user-agent"),
        ("json_file", "--json-file"),
        ("save_har", "--save-har"),
        ("config", "--config"),
        ("profile", "--profile"),
    ):
        value = getattr(args, name)
        if value:
            translated.extend([flag, str(value)])
    if args.json:
        translated.append("--json")
    if args.quiet:
        translated.append("--quiet")
    if args.verbose:
        translated.append("--verbose")
    return translated


def _append_scalar(translated: list[str], args, name: str, flag: str) -> None:
    value = getattr(args, name)
    if value:
        translated.extend([flag, str(value)])


def _append_bool(translated: list[str], args, name: str, flag: str) -> None:
    if getattr(args, name):
        translated.append(flag)


def _append_repeated(translated: list[str], args, name: str, flag: str) -> None:
    for value in getattr(args, name):
        translated.extend([flag, str(value)])


def _run_argv(argv: list[str]) -> list[str]:
    args = parse_run_args(argv)
    translated: list[str] = []
    for name, flag in (
        ("sim", "--sim"),
        ("port", "--port"),
        ("network_service", "--network-service"),
        ("json_file", "--json-file"),
        ("save_har", "--save-har"),
        ("output", "--output"),
        ("config", "--config"),
        ("profile", "--profile"),
        ("filter", "--filter"),
        ("filter_user_agent", "--filter-user-agent"),
        ("map_local", "--map-local"),
        ("map_remote", "--map-remote"),
        ("status_code", "--status-code"),
        ("add_header", "--add-header"),
        ("body_replace", "--body-replace"),
        ("request_header", "--request-header"),
        ("request_body_replace", "--request-body-replace"),
        ("websocket_message_replace", "--websocket-message-replace"),
        ("websocket_replay", "--websocket-replay"),
        ("websocket_replay_pattern", "--websocket-replay-pattern"),
    ):
        _append_scalar(translated, args, name, flag)
    for name, flag in (
        ("json", "--json"),
        ("no_headers", "--no-headers"),
        ("no_body", "--no-body"),
        ("no_websockets", "--no-websockets"),
        ("trust_macos_cert", "--trust-macos-cert"),
        ("quiet", "--quiet"),
        ("verbose", "--verbose"),
    ):
        _append_bool(translated, args, name, flag)
    for name, flag in (
        ("websocket_drop_message", "--websocket-drop-message"),
        ("websocket_fail_rate", "--websocket-fail-rate"),
        ("websocket_delay", "--websocket-delay"),
        ("websocket_throttle", "--websocket-throttle"),
        ("delay", "--delay"),
        ("throttle", "--throttle"),
        ("drop_connection", "--drop-connection"),
        ("fail_rate", "--fail-rate"),
    ):
        _append_repeated(translated, args, name, flag)
    return translated


def _replay_argv(argv: list[str]) -> list[str]:
    args = parse_replay_args(argv)
    translated = _record_argv(
        [
            *(["--sim", args.sim] if args.sim else []),
            *(["--port", str(args.port)] if args.port else []),
            *(["--filter", args.filter] if args.filter else []),
            *(["--filter-user-agent", args.filter_user_agent] if args.filter_user_agent else []),
            *(["--json-file", args.json_file] if args.json_file else []),
            *(["--save-har", args.save_har] if args.save_har else []),
            *(["--config", args.config] if args.config else []),
            *(["--profile", args.profile] if args.profile else []),
            *(["--quiet"] if args.quiet else []),
            *(["--verbose"] if args.verbose else []),
        ]
    )
    translated.extend(["--websocket-replay", args.capture])
    if args.websocket_pattern:
        translated.extend(["--websocket-replay-pattern", args.websocket_pattern])
    return translated


def _handle_status(argv: list[str]) -> int:
    args = parse_status_args(argv)
    status = collect_readiness_status(network_service=args.network_service)
    print_readiness_status(status, as_json=args.json_output)
    return 0 if status["ready"] else 1


def _handle_cert(argv: list[str]) -> int:
    args = parse_cert_args(argv)
    if args.cert_command == "status":
        status = collect_cert_probe_status(simulator_udid=args.sim)
        print_cert_probe_status(status, as_json=args.json_output)
        return 0 if status["ready"] else 1
    if args.cert_command == "trust-macos":
        ca_cert = ensure_ca_cert()
        trust_ca_cert_in_macos(str(ca_cert), quiet=args.quiet)
        return 0
    print("Error: unsupported cert command.", file=sys.stderr)
    return 1


def _handle_sims(argv: list[str]) -> int:
    args = parse_sims_args(argv)
    if args.sims_command == "list":
        print_simulators()
        return 0
    print("Error: unsupported sims command.", file=sys.stderr)
    return 1


def _handle_cleanup(argv: list[str]) -> int:
    parse_cleanup_args(argv)
    return 0 if do_cleanup() else 1


def _handle_capabilities(argv: list[str]) -> int:
    parse_capabilities_args(argv)
    emit_json(cli_capabilities())
    return 0


def _scenario_argv(argv: list[str]) -> list[str]:
    args = parse_scenario_args(argv)
    if args.scenario_command != "run":
        return []
    translated = _record_argv(
        [
            *(["--sim", args.sim] if args.sim else []),
            *(["--port", str(args.port)] if args.port else []),
            *(["--filter", args.filter] if args.filter else []),
            *(["--filter-user-agent", args.filter_user_agent] if args.filter_user_agent else []),
            *(["--json-file", args.json_file] if args.json_file else []),
            *(["--save-har", args.save_har] if args.save_har else []),
            "--config",
            args.config or args.scenario_file,
            *(["--profile", args.profile] if args.profile else []),
            *(["--quiet"] if args.quiet else []),
            *(["--verbose"] if args.verbose else []),
        ]
    )
    return translated


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if argv in (["--help"], ["-h"]):
        print(format_root_help())
        return 0
    if argv and argv[0] == "rules":
        return _handle_rules(argv[1:])
    if argv and argv[0] == "sockets":
        return _handle_sockets(argv[1:])
    if argv and argv[0] == "streams":
        return _handle_streams(argv[1:])
    if argv and argv[0] == "status":
        return _handle_status(argv[1:])
    if argv and argv[0] == "cert":
        return _handle_cert(argv[1:])
    if argv and argv[0] == "sims":
        return _handle_sims(argv[1:])
    if argv and argv[0] == "cleanup":
        return _handle_cleanup(argv[1:])
    if argv and argv[0] == "capabilities":
        return _handle_capabilities(argv[1:])
    if argv and argv[0] == "run":
        argv = _run_argv(argv[1:])
    elif argv and argv[0] == "record":
        argv = _record_argv(argv[1:])
    elif argv and argv[0] == "replay":
        argv = _replay_argv(argv[1:])
    elif argv and argv[0] == "scenario":
        argv = _scenario_argv(argv[1:])

    args = parse_args(argv)

    if args.status or args.status_json:
        status = collect_readiness_status(network_service=args.network_service)
        print_readiness_status(status, as_json=args.status_json)
        return 0 if status["ready"] else 1
    if args.probe_cert_readiness or args.probe_cert_readiness_json:
        status = collect_cert_probe_status(simulator_udid=args.sim)
        print_cert_probe_status(status, as_json=args.probe_cert_readiness_json)
        return 0 if status["ready"] else 1

    if args.cleanup:
        return 0 if do_cleanup() else 1

    if args.list_sims:
        print_simulators()
        return 0

    try:
        filter_settings = resolve_filter_settings(
            config_path=args.config,
            config_profile=args.profile,
            filter_pattern=args.filter,
            filter_user_agent=args.filter_user_agent,
        )
        build_matcher(filter_settings.get("filter"))
        build_matcher(filter_settings.get("filter_user_agent"))
        response_settings = resolve_response_settings(
            config_path=args.config,
            config_profile=args.profile,
            map_local=args.map_local,
            map_remote=args.map_remote,
            status_code=args.status_code,
            add_header=args.add_header,
            body_replace=args.body_replace,
        )
        build_response_rules(response_settings)
        request_settings = resolve_request_settings(
            config_path=args.config,
            config_profile=args.profile,
            request_header=args.request_header,
            request_body_replace=args.request_body_replace,
        )
        build_request_rules(request_settings)
        websocket_message_settings = resolve_websocket_message_settings(
            config_path=args.config,
            config_profile=args.profile,
            websocket_message_replace=args.websocket_message_replace,
            websocket_drop_message=args.websocket_drop_message,
            websocket_fail_rate=args.websocket_fail_rate,
            websocket_delay=args.websocket_delay,
            websocket_throttle=args.websocket_throttle,
        )
        build_websocket_message_rules(websocket_message_settings)
        websocket_replay_settings = resolve_websocket_replay_settings(
            config_path=args.config,
            config_profile=args.profile,
            replay_file=args.websocket_replay,
            replay_pattern=args.websocket_replay_pattern,
        )
        build_websocket_replay(
            replay_file=websocket_replay_settings.get("websocket_replay"),
            replay_pattern=websocket_replay_settings.get("websocket_replay_pattern"),
        )
        network_condition_settings = resolve_network_condition_settings(
            config_path=args.config,
            config_profile=args.profile,
            delay=args.delay,
            throttle=args.throttle,
            drop_connection=args.drop_connection,
            fail_rate=args.fail_rate,
        )
        build_network_condition_rules(network_condition_settings)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    preflight_checks()
    check_stale_session()

    device = resolve_simulator(args.sim)
    if not args.quiet:
        print(f'Using simulator: {device["name"]} ({device["udid"]})')

    ca_cert = ensure_ca_cert()
    if args.trust_macos_cert:
        trust_ca_cert_in_macos(str(ca_cert), quiet=args.quiet)

    if not args.quiet:
        print("Installing CA certificate in simulator...")
    install_cert_in_simulator(device["udid"], str(ca_cert))

    port = args.port or find_free_port()
    proxy_config = ProxyConfig(port=port, service=args.network_service, quiet=args.quiet)
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    runtime_config = runtime_config_path(LOCK_DIR, os.getpid())
    runtime_status = runtime_status_path(LOCK_DIR, os.getpid())
    runtime_http_config = build_runtime_http_config(
        filter_settings=filter_settings,
        response_settings=response_settings,
        request_settings=request_settings,
        network_condition_settings=network_condition_settings,
    )
    write_runtime_config(runtime_config, runtime_http_config)

    mitm_proc = None
    cleanup_done = False

    def cleanup() -> None:
        nonlocal cleanup_done
        if cleanup_done:
            return
        cleanup_done = True

        if not args.quiet:
            print("\nShutting down...")

        proxy_config.disable()
        remove_lock()
        for path in (runtime_config, runtime_status):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass

        if mitm_proc is not None and mitm_proc.poll() is None:
            mitm_proc.send_signal(signal.SIGTERM)
            try:
                mitm_proc.wait(timeout=3)
            except Exception:
                mitm_proc.kill()
                mitm_proc.wait()

        if not args.quiet:
            print("Done.")

    def on_signal(signum, frame) -> None:  # noqa: ARG001
        if mitm_proc is not None and mitm_proc.poll() is None:
            mitm_proc.send_signal(signal.SIGTERM)

    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)
    atexit.register(cleanup)

    try:
        proxy_config.enable()
        write_lock(
            pid=os.getpid(),
            network_service=proxy_config.service,
            port=port,
            original_http=proxy_config._original_http,
            original_https=proxy_config._original_https,
            runtime_config_path=str(runtime_config),
            runtime_status_path=str(runtime_status),
        )

        if not args.quiet:
            print(f"Starting proxy on port {port}...")
            print(f"Network service: {proxy_config.service}")
            print("Press Ctrl+C to stop.\n")

        mitm_proc = start_mitmdump(
            port=port,
            config_path=str(runtime_config),
            runtime_status_file=str(runtime_status),
            json_mode=args.json,
            json_file=args.json_file,
            save_har=args.save_har,
            no_headers=args.no_headers,
            no_body=args.no_body,
            no_websockets=args.no_websockets,
            output_file=args.output,
            websocket_message_replace=websocket_message_settings.get("websocket_message_replace"),
            websocket_drop_message=websocket_message_settings.get("websocket_drop_message"),
            websocket_fail_rate=websocket_message_settings.get("websocket_fail_rate"),
            websocket_delay=websocket_message_settings.get("websocket_delay"),
            websocket_throttle=websocket_message_settings.get("websocket_throttle"),
            websocket_replay_file=websocket_replay_settings.get("websocket_replay"),
            websocket_replay_pattern=websocket_replay_settings.get("websocket_replay_pattern"),
            quiet=args.quiet,
            verbose=args.verbose,
        )

        try:
            mitm_proc.wait()
        except (KeyboardInterrupt, OSError):
            pass
    finally:
        cleanup()

    return 0


if __name__ == "__main__":
    sys.exit(main())
