from __future__ import annotations

import json
import os
from unittest.mock import patch

from jaala.addon import JaalaAddon

from .test_addon import make_flow


def test_request_body_replace_mutates_matching_request_body(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"request_body_replace": "api.example.com=hello>>>world"}),
        encoding="utf-8",
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(method="POST", req_body=b"hello from Jaala")
    addon.request(flow)

    assert flow.request.content == b"world from Jaala"
    assert flow.request.headers.get("content-length") == str(len(flow.request.content))


def test_request_body_replace_skips_non_matching_request(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(
        json.dumps({"request_body_replace": "payments=hello>>>world"}),
        encoding="utf-8",
    )
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow(method="POST", req_body=b"hello from Jaala")
    addon.request(flow)

    assert flow.request.content == b"hello from Jaala"
