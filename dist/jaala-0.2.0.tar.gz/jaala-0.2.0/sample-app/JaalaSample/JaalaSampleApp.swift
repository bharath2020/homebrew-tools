import Foundation
import SwiftUI

@main
struct JaalaSampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var results: [RequestResult] = []
    @State private var isLoading = false
    @State private var streamFetch: HTTPStreamFetch?
    @State private var didAutoRunStream = false

    private let endpoints: [SampleEndpoint] = [
        SampleEndpoint(
            label: "Capture JSON: expect 200 body",
            title: "Capture JSON - expected 200 body",
            request: URLRequest(url: URL(string: "https://httpbin.org/json")!)
        ),
        SampleEndpoint(
            label: "Filter URL: expect Todo captured",
            title: "Filter URL - expected Todo capture",
            request: URLRequest(url: URL(string: "https://jsonplaceholder.typicode.com/todos/1")!)
        ),
        SampleEndpoint(
            label: "Network delay: expect slower Forecast",
            title: "Network delay - expected slower Forecast",
            request: URLRequest(url: URL(string: "https://api.open-meteo.com/v1/forecast?latitude=37.7749&longitude=-122.4194&current=temperature_2m")!)
        ),
        SampleEndpoint(
            label: "HAR export: expect Wikimedia entry",
            title: "HAR export - expected Wikimedia entry",
            request: URLRequest(url: URL(string: "https://en.wikipedia.org/w/api.php?action=query&meta=siteinfo&siprop=general&format=json")!)
        ),
        SampleEndpoint(
            label: "Body capture: expect YouTube oEmbed",
            title: "Body capture - expected YouTube oEmbed",
            request: URLRequest(url: URL(string: "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=dQw4w9WgXcQ&format=json")!)
        ),
        SampleEndpoint(
            label: "Request mutation: expect POST JSON",
            title: "Request mutation - expected POST JSON",
            request: SampleEndpoint.postRequest()
        ),
    ]
    private let websocketScenario = WebSocketScenario(
        label: "WebSocket echo: expect sent and received message",
        title: "WebSocket echo - expected sent and received message"
    )
    private let streamingScenario = StreamingScenario(
        label: "HTTP stream: expect modified chunks",
        title: "HTTP stream - expected modified chunks"
    )

    var body: some View {
        NavigationStack {
            List {
                Section("Actions") {
                    Button("Run full capture matrix: expect 6 results") {
                        runAll()
                    }
                    .accessibilityLabel("Run full capture matrix: expect 6 results")

                    Button(websocketScenario.label) {
                        runWebSocketEcho()
                    }
                    .accessibilityLabel(websocketScenario.label)

                    Button(streamingScenario.label) {
                        runHTTPStream()
                    }
                    .accessibilityLabel(streamingScenario.label)

                    ForEach(endpoints) { endpoint in
                        Button(endpoint.label) {
                            run(endpoint)
                        }
                        .accessibilityLabel(endpoint.label)
                    }
                }

                Section("Results (\(results.count))") {
                    if results.isEmpty {
                        Text("No results yet")
                            .foregroundStyle(.secondary)
                            .accessibilityLabel("No results yet")
                    }

                    ForEach(results) { result in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(result.title)
                                .font(.headline)
                            Text("Status: \(result.statusCode)")
                                .foregroundStyle(result.isSuccess ? .green : .red)
                            Text(result.preview)
                                .font(.caption)
                                .lineLimit(result.previewLineLimit)
                        }
                        .padding(.vertical, 4)
                        .accessibilityElement(children: .combine)
                        .accessibilityLabel("\(result.title), Status: \(result.statusCode), \(result.preview)")
                    }
                }
            }
            .navigationTitle("Jaala Sample")
            .accessibilityIdentifier("JaalaSampleRoot")
            .overlay {
                if isLoading {
                    ProgressView("Loading")
                        .accessibilityLabel("Loading")
                }
            }
            .task {
                guard !didAutoRunStream else {
                    return
                }
                if StreamingConfiguration.load().autoRun {
                    didAutoRunStream = true
                    runHTTPStream()
                }
            }
        }
    }

    private func runAll() {
        results.removeAll()
        for endpoint in endpoints {
            run(endpoint)
        }
    }

    private func run(_ endpoint: SampleEndpoint) {
        isLoading = true
        var request = endpoint.request
        request.setValue("JaalaSample/1.0", forHTTPHeaderField: "User-Agent")

        URLSession.shared.dataTask(with: request) { data, response, error in
            let statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
            let body = data.flatMap { String(data: $0, encoding: .utf8) }
                ?? error?.localizedDescription
                ?? "no data"

            DispatchQueue.main.async {
                results.insert(
                    RequestResult(
                        title: endpoint.title,
                        statusCode: statusCode,
                        preview: String(body.prefix(240))
                    ),
                    at: 0
                )
                isLoading = false
            }
        }.resume()
    }

    private func runWebSocketEcho() {
        isLoading = true
        let configuration = WebSocketConfiguration.load()

        Task {
            guard let url = configuration.url else {
                await MainActor.run {
                    results.insert(
                        RequestResult(
                            title: websocketScenario.title,
                            statusCode: 0,
                            preview: configuration.errorMessage
                        ),
                        at: 0
                    )
                    isLoading = false
                }
                return
            }

            let session = URLSession(configuration: configuration.sessionConfiguration)
            let task = session.webSocketTask(with: url)
            let sentMessage = configuration.sentMessage

            task.resume()

            do {
                try await task.send(.string(sentMessage))
                if configuration.streamSeconds > 0 {
                    try await receiveWebSocketStream(
                        task,
                        url: url,
                        sentMessage: sentMessage,
                        seconds: configuration.streamSeconds,
                        timeoutSeconds: configuration.timeoutSeconds
                    )
                    await MainActor.run {
                        isLoading = false
                    }
                    task.cancel(with: .normalClosure, reason: nil)
                    return
                }
                let received = try await receiveWebSocketMessage(task, timeoutSeconds: configuration.timeoutSeconds)
                let preview = websocketScenario.preview(
                    url: url,
                    sentMessage: sentMessage,
                    receivedMessage: received
                )

                await MainActor.run {
                    results.insert(
                        RequestResult(
                            title: websocketScenario.title,
                            statusCode: 101,
                            preview: preview
                        ),
                        at: 0
                    )
                    isLoading = false
                }
            } catch {
                await MainActor.run {
                    results.insert(
                        RequestResult(
                            title: websocketScenario.title,
                            statusCode: 0,
                            preview: "WebSocket error: \(error.localizedDescription)"
                        ),
                        at: 0
                    )
                    isLoading = false
                }
            }

            task.cancel(with: .normalClosure, reason: nil)
        }
    }

    private func runHTTPStream() {
        isLoading = true
        let configuration = StreamingConfiguration.load()

        guard let url = configuration.url else {
            results.insert(
                RequestResult(
                    title: streamingScenario.title,
                    statusCode: 0,
                    preview: configuration.errorMessage
                ),
                at: 0
            )
            isLoading = false
            return
        }

        var request = URLRequest(url: url)
        request.setValue("JaalaSample/1.0", forHTTPHeaderField: "User-Agent")
        request.setValue("text/event-stream", forHTTPHeaderField: "Accept")

        let fetch = HTTPStreamFetch(
            configuration: configuration.sessionConfiguration,
            resultTitle: streamingScenario.title,
            previewLineLimit: nil,
            preview: { body in streamingScenario.preview(url: url, body: body) },
            onUpdate: { result in
                results.removeAll { $0.title == streamingScenario.title }
                results.insert(result, at: 0)
                if result.preview.contains("JAALA_STREAM_MODIFIED") {
                    isLoading = false
                }
            },
            onComplete: {
                isLoading = false
                streamFetch = nil
            }
        )
        streamFetch = fetch
        fetch.start(request)
    }

    private func receiveWebSocketMessage(
        _ task: URLSessionWebSocketTask,
        timeoutSeconds: Double
    ) async throws -> URLSessionWebSocketTask.Message {
        try await withThrowingTaskGroup(of: URLSessionWebSocketTask.Message.self) { group in
            group.addTask {
                try await task.receive()
            }
            group.addTask {
                try await Task.sleep(for: .seconds(timeoutSeconds))
                throw WebSocketTimeoutError()
            }

            guard let message = try await group.next() else {
                throw WebSocketTimeoutError()
            }
            group.cancelAll()
            return message
        }
    }

    private func receiveWebSocketStream(
        _ task: URLSessionWebSocketTask,
        url: URL,
        sentMessage: String,
        seconds: Int,
        timeoutSeconds: Double
    ) async throws {
        var receivedTexts: [String] = []
        let deadline = Date().addingTimeInterval(TimeInterval(seconds))

        while Date() < deadline {
            let message = try await receiveWebSocketMessage(task, timeoutSeconds: timeoutSeconds)
            switch message {
            case .string(let text):
                receivedTexts.append(text)
            case .data(let data):
                receivedTexts.append("binary \(data.count) bytes")
            @unknown default:
                receivedTexts.append("unsupported message")
            }

            let preview = websocketScenario.streamPreview(
                url: url,
                sentMessage: sentMessage,
                receivedTexts: receivedTexts
            )

            await MainActor.run {
                results.removeAll { $0.title == websocketScenario.title }
                results.insert(
                    RequestResult(
                        title: websocketScenario.title,
                        statusCode: 101,
                        preview: preview,
                        previewLineLimit: nil
                    ),
                    at: 0
                )
            }
        }
    }
}

struct SampleEndpoint: Identifiable {
    let id = UUID()
    let label: String
    let title: String
    let request: URLRequest

    static func postRequest() -> URLRequest {
        var request = URLRequest(url: URL(string: "https://httpbin.org/post")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode([
            "message": "hello from jaala sample",
            "scenario": "contract fixture",
        ])
        return request
    }
}

struct RequestResult: Identifiable {
    let id: UUID
    let title: String
    let statusCode: Int
    let preview: String
    let previewLineLimit: Int?

    init(
        id: UUID = UUID(),
        title: String,
        statusCode: Int,
        preview: String,
        previewLineLimit: Int? = 3
    ) {
        self.id = id
        self.title = title
        self.statusCode = statusCode
        self.preview = preview
        self.previewLineLimit = previewLineLimit
    }

    var isSuccess: Bool {
        statusCode == 101 || (200..<300).contains(statusCode)
    }
}

struct WebSocketScenario {
    let label: String
    let title: String

    func preview(
        url: URL,
        sentMessage: String,
        receivedMessage: URLSessionWebSocketTask.Message
    ) -> String {
        switch receivedMessage {
        case .string(let text):
            let expectation = text == sentMessage
                ? "Expectation met: sent and received text matched."
                : "Expectation not met: the echoed text did not match."

            return [
                "URL: \(url.absoluteString)",
                "Sent: \(sentMessage)",
                "Received: \(text)",
                expectation,
            ].joined(separator: "\n")
        case .data(let data):
            return [
                "URL: \(url.absoluteString)",
                "Sent: \(sentMessage)",
                "Received binary message: \(data.count) bytes",
                "Expectation not met: expected an echoed text message.",
            ].joined(separator: "\n")
        @unknown default:
            return [
                "URL: \(url.absoluteString)",
                "Sent: \(sentMessage)",
                "Received an unsupported WebSocket message.",
            ].joined(separator: "\n")
        }
    }

    func streamPreview(
        url: URL,
        sentMessage: String,
        receivedTexts: [String]
    ) -> String {
        let lines = receivedTexts.enumerated().map { index, text in
            "\(index + 1): \(text)"
        }
        return [
            "URL: \(url.absoluteString)",
            "Sent: \(sentMessage)",
            "Received \(receivedTexts.count) WebSocket messages",
            lines.joined(separator: "\n"),
        ].joined(separator: "\n")
    }
}

struct WebSocketConfiguration {
    let urlString: String?
    let proxyHost: String?
    let proxyPort: Int?
    let sentMessage: String
    let timeoutSeconds: Double
    let streamSeconds: Int

    var url: URL? {
        guard let urlString else {
            return nil
        }
        return URL(string: urlString)
    }

    var errorMessage: String {
        guard let urlString else {
            return "Missing WebSocket URL. Pass --websocket-url <wss://...> or set JAALA_WEBSOCKET_URL."
        }
        return "Invalid WebSocket URL: \(urlString)"
    }

    var sessionConfiguration: URLSessionConfiguration {
        let configuration = URLSessionConfiguration.default
        guard let proxyHost, let proxyPort else {
            return configuration
        }
        configuration.connectionProxyDictionary = [
            kCFNetworkProxiesHTTPEnable as String: true,
            kCFNetworkProxiesHTTPProxy as String: proxyHost,
            kCFNetworkProxiesHTTPPort as String: proxyPort,
        ]
        return configuration
    }

    static func load(processInfo: ProcessInfo = .processInfo) -> WebSocketConfiguration {
        let proxyHost = launchArgument(named: "--websocket-proxy-host", processInfo: processInfo)
            ?? processInfo.environment["JAALA_WEBSOCKET_PROXY_HOST"]
        let proxyPort = (
            launchArgument(named: "--websocket-proxy-port", processInfo: processInfo)
                ?? processInfo.environment["JAALA_WEBSOCKET_PROXY_PORT"]
        ).flatMap(Int.init)
        let sentMessage = launchArgument(named: "--websocket-sent-text", processInfo: processInfo)
            ?? processInfo.environment["JAALA_WEBSOCKET_SENT_TEXT"]
            ?? "hello from jaala sample"
        let timeoutSeconds = (
            launchArgument(named: "--websocket-timeout-seconds", processInfo: processInfo)
                ?? processInfo.environment["JAALA_WEBSOCKET_TIMEOUT_SECONDS"]
        ).flatMap(Double.init) ?? 5
        let streamSeconds = (
            launchArgument(named: "--websocket-stream-seconds", processInfo: processInfo)
                ?? processInfo.environment["JAALA_WEBSOCKET_STREAM_SECONDS"]
        ).flatMap(Int.init) ?? 0

        if let urlString = launchArgument(named: "--websocket-url", processInfo: processInfo) {
            return WebSocketConfiguration(
                urlString: urlString,
                proxyHost: proxyHost,
                proxyPort: proxyPort,
                sentMessage: sentMessage,
                timeoutSeconds: timeoutSeconds,
                streamSeconds: streamSeconds
            )
        }

        if let urlString = processInfo.environment["JAALA_WEBSOCKET_URL"], !urlString.isEmpty {
            return WebSocketConfiguration(
                urlString: urlString,
                proxyHost: proxyHost,
                proxyPort: proxyPort,
                sentMessage: sentMessage,
                timeoutSeconds: timeoutSeconds,
                streamSeconds: streamSeconds
            )
        }

        return WebSocketConfiguration(
            urlString: nil,
            proxyHost: proxyHost,
            proxyPort: proxyPort,
            sentMessage: sentMessage,
            timeoutSeconds: timeoutSeconds,
            streamSeconds: streamSeconds
        )
    }

    private static func launchArgument(named name: String, processInfo: ProcessInfo) -> String? {
        let arguments = processInfo.arguments

        if let index = arguments.firstIndex(of: name), index + 1 < arguments.count {
            return arguments[index + 1]
        }

        let prefix = "\(name)="
        if let argument = arguments.first(where: { $0.hasPrefix(prefix) }) {
            return String(argument.dropFirst(prefix.count))
        }

        return nil
    }
}

struct WebSocketTimeoutError: LocalizedError {
    var errorDescription: String? {
        "Timed out waiting for a WebSocket response."
    }
}

struct StreamingScenario {
    let label: String
    let title: String

    func preview(url: URL, body: String) -> String {
        let lines = body
            .split(separator: "\n", omittingEmptySubsequences: true)
            .map(String.init)
        let latest = lines.suffix(4).joined(separator: "\n")
        return [
            "URL: \(url.absoluteString)",
            "Events: \(lines.count)",
            latest,
        ].joined(separator: "\n")
    }
}

struct StreamingConfiguration {
    let urlString: String?
    let proxyHost: String?
    let proxyPort: Int?
    let autoRun: Bool

    var url: URL? {
        guard let urlString else {
            return nil
        }
        return URL(string: urlString)
    }

    var sessionConfiguration: URLSessionConfiguration {
        let configuration = URLSessionConfiguration.default
        guard let proxyHost, let proxyPort else {
            return configuration
        }
        configuration.connectionProxyDictionary = [
            kCFNetworkProxiesHTTPEnable as String: true,
            kCFNetworkProxiesHTTPProxy as String: proxyHost,
            kCFNetworkProxiesHTTPPort as String: proxyPort,
        ]
        return configuration
    }

    var errorMessage: String {
        guard let urlString else {
            return "Missing stream URL. Pass --stream-url <http://...> or set JAALA_STREAM_URL."
        }
        return "Invalid stream URL: \(urlString)"
    }

    static func load(processInfo: ProcessInfo = .processInfo) -> StreamingConfiguration {
        let proxyHost = launchArgument(named: "--stream-proxy-host", processInfo: processInfo)
            ?? processInfo.environment["JAALA_STREAM_PROXY_HOST"]
        let proxyPort = (
            launchArgument(named: "--stream-proxy-port", processInfo: processInfo)
                ?? processInfo.environment["JAALA_STREAM_PROXY_PORT"]
        ).flatMap(Int.init)
        let autoRun = launchFlag(named: "--autorun-stream", processInfo: processInfo)
            || processInfo.environment["JAALA_AUTORUN_STREAM"] == "1"

        if let urlString = launchArgument(named: "--stream-url", processInfo: processInfo) {
            return StreamingConfiguration(urlString: urlString, proxyHost: proxyHost, proxyPort: proxyPort, autoRun: autoRun)
        }

        if let urlString = processInfo.environment["JAALA_STREAM_URL"], !urlString.isEmpty {
            return StreamingConfiguration(urlString: urlString, proxyHost: proxyHost, proxyPort: proxyPort, autoRun: autoRun)
        }

        return StreamingConfiguration(urlString: nil, proxyHost: proxyHost, proxyPort: proxyPort, autoRun: autoRun)
    }

    private static func launchArgument(named name: String, processInfo: ProcessInfo) -> String? {
        let arguments = processInfo.arguments

        if let index = arguments.firstIndex(of: name), index + 1 < arguments.count {
            return arguments[index + 1]
        }

        let prefix = "\(name)="
        if let argument = arguments.first(where: { $0.hasPrefix(prefix) }) {
            return String(argument.dropFirst(prefix.count))
        }

        return nil
    }

    private static func launchFlag(named name: String, processInfo: ProcessInfo) -> Bool {
        processInfo.arguments.contains(name)
    }
}

final class HTTPStreamFetch: NSObject, URLSessionDataDelegate {
    private let configuration: URLSessionConfiguration
    private let resultTitle: String
    private let previewLineLimit: Int?
    private let preview: (String) -> String
    private let onUpdate: (RequestResult) -> Void
    private let onComplete: () -> Void
    private var receivedBody = ""
    private var statusCode = 0
    private var session: URLSession?

    init(
        configuration: URLSessionConfiguration,
        resultTitle: String,
        previewLineLimit: Int? = 3,
        preview: @escaping (String) -> String,
        onUpdate: @escaping (RequestResult) -> Void,
        onComplete: @escaping () -> Void
    ) {
        self.configuration = configuration
        self.resultTitle = resultTitle
        self.previewLineLimit = previewLineLimit
        self.preview = preview
        self.onUpdate = onUpdate
        self.onComplete = onComplete
    }

    func start(_ request: URLRequest) {
        let session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        self.session = session
        session.dataTask(with: request).resume()
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive response: URLResponse,
        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
    ) {
        statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        receivedBody += String(data: data, encoding: .utf8) ?? ""
        let result = RequestResult(
            title: resultTitle,
            statusCode: statusCode,
            preview: preview(receivedBody),
            previewLineLimit: previewLineLimit
        )
        DispatchQueue.main.async {
            self.onUpdate(result)
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error, self.receivedBody.isEmpty {
            let result = RequestResult(
                title: resultTitle,
                statusCode: statusCode,
                preview: error.localizedDescription,
                previewLineLimit: previewLineLimit
            )
            DispatchQueue.main.async {
                self.onUpdate(result)
                self.onComplete()
            }
            return
        }

        DispatchQueue.main.async {
            self.onComplete()
        }
    }
}
