from __future__ import annotations

import json
import os
from unittest.mock import patch

import pytest

from jaala.addon import JaalaAddon
from jaala.cli import parse_args, parse_delay_rules

from .test_addon import make_flow


def test_delay_flag_parses():
    args = parse_args(["--delay", "api.example.com=2000", "--delay", "cdn.example.com=500"])
    assert args.delay == ["api.example.com=2000", "cdn.example.com=500"]


def test_parse_delay_rules_validates():
    rules = parse_delay_rules(["api.example.com=2000"])
    assert rules == [{"pattern": "api.example.com", "delay_ms": 2000}]


def test_parse_delay_rules_rejects_bad_delay():
    with pytest.raises(ValueError):
        parse_delay_rules(["api.example.com=-1"])


def test_delay_applies_sleep_and_metadata(tmp_path):
    config_path = tmp_path / "jaala.json"
    config_path.write_text(json.dumps({"delay": ["api.example.com=2000"]}), encoding="utf-8")
    with patch.dict(os.environ, {"JAALA_CONFIG": str(config_path)}, clear=False):
        addon = JaalaAddon()

    flow = make_flow()

    with patch("jaala.network_conditions.time.sleep") as mock_sleep:
        addon.response(flow)

    mock_sleep.assert_called_once_with(2.0)
    assert flow.metadata["jaala_delayed_ms"] == 2000
