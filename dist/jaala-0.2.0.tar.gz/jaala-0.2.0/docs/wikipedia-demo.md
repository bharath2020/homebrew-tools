# Wikipedia Demo

Jaala pins the official Wikimedia iOS app as a git submodule at
`demo-apps/wikipedia-ios`.

This keeps the Jaala repo focused on the proxy, validators, and demo harness
while still letting us build a real open-source iOS client and demonstrate a
Pact-style workflow against live Wikipedia traffic.

## Initialize

```bash
git submodule update --init --recursive
```

## Why A Submodule

- Jaala does not vendor the Wikipedia app into its own source tree.
- The demo is pinned to an exact upstream commit.
- We can update the demo target incrementally with normal git history.
- The Wikipedia app remains independently buildable and reviewable.

## Intended Demo Flow

1. Build the app from `demo-apps/wikipedia-ios`.
2. Drive a stable read-only article flow with the repo-local harness in
   `demo/wikipedia/`.
3. Capture live traffic with Jaala to JSONL and HAR.
4. Save a known-good fixture from that capture.
5. Replay or mutate the fixture with Jaala to validate the consumer under:
   - exact contract replay
   - delayed replay on the article HTML response
   - status overrides on the summary response
   - additional future mutations such as malformed bodies or dropped requests

## Repo Boundary

For now, the existing `sample-app/` remains the fast Jaala feature-validation
target. The Wikipedia submodule is the external demo target for the larger
Pact-style story.

## Current Harness

The current harness lives at:

- `demo/wikipedia/jaala-wikipedia-demo.sh`
- `demo/wikipedia/README.md`

It builds the pinned Wikimedia app, opens the `OpenAI` article, records the
core article endpoints, extracts local fixtures, and replays or mutates those
fixtures through Jaala.
