"""WebSocket message replacement rules for Jaala."""

from __future__ import annotations

import json
import os
import random
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass

from .filtering import build_matcher, load_merged_config

ENV_CONFIG = "JAALA_CONFIG"
ENV_WEBSOCKET_MESSAGE_REPLACE = "JAALA_WEBSOCKET_MESSAGE_REPLACE"
ENV_WEBSOCKET_DROP_MESSAGE = "JAALA_WEBSOCKET_DROP_MESSAGE"
ENV_WEBSOCKET_FAIL_RATE = "JAALA_WEBSOCKET_FAIL_RATE"
ENV_WEBSOCKET_DELAY = "JAALA_WEBSOCKET_DELAY"
ENV_WEBSOCKET_THROTTLE = "JAALA_WEBSOCKET_THROTTLE"

WEBSOCKET_MESSAGE_KEYS = (
    "websocket_message_replace",
    "websocket_drop_message",
    "websocket_fail_rate",
    "websocket_delay",
    "websocket_throttle",
)


def _normalize(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _split_once(value: str, separator: str, label: str) -> tuple[str, str]:
    left, found, right = value.partition(separator)
    if not found or not left.strip() or not right.strip():
        raise ValueError(f"Invalid {label} rule {value!r}")
    return left.strip(), right.strip()


def _load_json_list(raw_value: str | None, label: str) -> list[str]:
    normalized = _normalize(raw_value)
    if normalized is None:
        return []

    try:
        value = json.loads(normalized)
    except (json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"{label} must be a JSON array of strings") from exc

    if not isinstance(value, list):
        raise ValueError(f"{label} must be a JSON array of strings")

    result: list[str] = []
    for item in value:
        if not isinstance(item, str):
            raise ValueError(f"{label} entries must be strings")
        normalized_item = _normalize(item)
        if normalized_item is not None:
            result.append(normalized_item)
    return result


def _coerce_raw_rules(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        normalized = _normalize(value)
        if normalized is None:
            return []
        if normalized.startswith("["):
            return _load_json_list(normalized, "websocket message rules")
        return [normalized]
    result: list[str] = []
    for item in value:
        normalized = _normalize(item)
        if normalized is not None:
            result.append(normalized)
    return result


def _validate_pattern(pattern: str, label: str) -> str:
    normalized = _normalize(pattern)
    if normalized is None:
        raise ValueError(f"Invalid {label} rule: pattern must not be empty")
    build_matcher(normalized)
    return normalized


def _content_bytes(content: bytes | bytearray | memoryview | None) -> bytes:
    if content is None:
        return b""
    if isinstance(content, bytes):
        return content
    if isinstance(content, bytearray):
        return bytes(content)
    if isinstance(content, memoryview):
        return content.tobytes()
    return bytes(content)


def _decode_text(content: bytes | bytearray | memoryview | None) -> str | None:
    data = _content_bytes(content)
    if not data:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _set_message_text(message, text: str) -> None:
    try:
        message.text = text
    except Exception:
        pass


def _drop_message(message) -> None:
    drop = getattr(message, "drop", None)
    if callable(drop):
        drop()
        return
    try:
        message.dropped = True
    except Exception:
        pass


def parse_websocket_drop_message_rules(raw_rules) -> list[str]:
    rules: list[str] = []
    for raw in raw_rules:
        rules.append(_validate_pattern(raw, "websocket-drop-message"))
    return rules


def parse_websocket_fail_rate_rules(raw_rules) -> list[dict[str, int | str]]:
    rules: list[dict[str, int | str]] = []
    for raw in raw_rules:
        normalized = _normalize(raw)
        if normalized is None:
            raise ValueError("Invalid websocket-fail-rate rule: pattern and percent must not be empty")
        pattern, percent_text = _split_once(normalized, "=", "websocket-fail-rate")
        pattern = _validate_pattern(pattern, "websocket-fail-rate")
        try:
            percent = int(percent_text)
        except ValueError as exc:
            raise ValueError(f"Invalid websocket-fail-rate rule {raw!r}: percent must be an integer") from exc
        if percent < 0 or percent > 100:
            raise ValueError(f"Invalid websocket-fail-rate rule {raw!r}: percent must be between 0 and 100")
        rules.append({"pattern": pattern, "percent": percent})
    return rules


def parse_websocket_delay_rules(raw_rules) -> list[dict[str, int | str]]:
    rules: list[dict[str, int | str]] = []
    for raw in raw_rules:
        normalized = _normalize(raw)
        if normalized is None:
            raise ValueError("Invalid websocket-delay rule: pattern and milliseconds must not be empty")
        pattern, ms_text = _split_once(normalized, "=", "websocket-delay")
        pattern = _validate_pattern(pattern, "websocket-delay")
        try:
            delay_ms = int(ms_text)
        except ValueError as exc:
            raise ValueError(f"Invalid websocket-delay rule {raw!r}: milliseconds must be an integer") from exc
        if delay_ms < 0:
            raise ValueError(f"Invalid websocket-delay rule {raw!r}: milliseconds must be non-negative")
        rules.append({"pattern": pattern, "delay_ms": delay_ms})
    return rules


def parse_websocket_throttle_rules(raw_rules) -> list[dict[str, int | str]]:
    rules: list[dict[str, int | str]] = []
    for raw in raw_rules:
        normalized = _normalize(raw)
        if normalized is None:
            raise ValueError("Invalid websocket-throttle rule: pattern and KBPS must not be empty")
        pattern, kbps_text = _split_once(normalized, "=", "websocket-throttle")
        pattern = _validate_pattern(pattern, "websocket-throttle")
        try:
            kbps = int(kbps_text)
        except ValueError as exc:
            raise ValueError(f"Invalid websocket-throttle rule {raw!r}: KBPS must be an integer") from exc
        if kbps <= 0:
            raise ValueError(f"Invalid websocket-throttle rule {raw!r}: KBPS must be positive")
        rules.append({"pattern": pattern, "kbps": kbps})
    return rules


@dataclass(slots=True)
class WebSocketMessageRuleSet:
    websocket_message_replace: tuple[Callable[[str], bool], tuple[str, str]] | None = None
    websocket_drop_message: list[Callable[[str], bool]] | None = None
    websocket_fail_rate: list[tuple[Callable[[str], bool], int]] | None = None
    websocket_delay: list[tuple[Callable[[str], bool], int]] | None = None
    websocket_throttle: list[tuple[Callable[[str], bool], int]] | None = None

    def _url(self, flow) -> str:
        return getattr(flow.request, "pretty_url", "")

    def _flow_metadata(self, flow) -> dict:
        metadata = getattr(flow, "metadata", None)
        if metadata is None:
            metadata = {}
            flow.metadata = metadata
        return metadata

    def _drop(self, flow, message, reason: str, **metadata_values) -> bool:
        metadata = self._flow_metadata(flow)
        metadata["jaala_websocket_dropped"] = True
        metadata[f"jaala_websocket_{reason}"] = True
        metadata.update(metadata_values)
        _drop_message(message)
        return True

    def _apply_websocket_drop_message(self, flow, message) -> bool:
        rules = self.websocket_drop_message or []
        url = self._url(flow)
        if not any(matcher(url) for matcher in rules):
            return False
        return self._drop(flow, message, "drop_message")

    def _apply_websocket_fail_rate(self, flow, message) -> bool:
        rules = self.websocket_fail_rate or []
        url = self._url(flow)
        for matcher, percent in rules:
            if not matcher(url) or percent <= 0:
                continue
            if percent >= 100 or random.randint(1, 100) <= percent:
                return self._drop(flow, message, "fail_rate", jaala_websocket_fail_rate_percent=percent)
        return False

    def _apply_websocket_delay(self, flow, message) -> bool:
        del message
        url = self._url(flow)
        for matcher, delay_ms in self.websocket_delay or []:
            if not matcher(url):
                continue
            if delay_ms > 0:
                time.sleep(delay_ms / 1000.0)
            metadata = self._flow_metadata(flow)
            metadata["jaala_websocket_delayed_ms"] = delay_ms
            return True
        return False

    def _apply_websocket_throttle(self, flow, message) -> bool:
        url = self._url(flow)
        for matcher, kbps in self.websocket_throttle or []:
            if not matcher(url):
                continue
            content_size = len(_content_bytes(getattr(message, "content", None)))
            sleep_seconds = content_size / (kbps * 1024)
            if sleep_seconds > 0:
                time.sleep(sleep_seconds)
            metadata = self._flow_metadata(flow)
            metadata["jaala_websocket_throttled_kbps"] = kbps
            return True
        return False

    def _apply_websocket_message_replace(self, flow, message) -> bool:
        if self.websocket_message_replace is None:
            return False
        if not getattr(message, "is_text", False):
            return False

        matcher, (search, replace) = self.websocket_message_replace
        if not matcher(self._url(flow)):
            return False

        text = getattr(message, "text", None)
        if text is None:
            text = _decode_text(getattr(message, "content", None))
        if text is None or search not in text:
            return False

        new_text = text.replace(search, replace)
        message.content = new_text.encode("utf-8")
        _set_message_text(message, new_text)
        return True

    def apply_websocket_message(self, flow, message) -> bool:
        if self._apply_websocket_fail_rate(flow, message):
            return True
        if self._apply_websocket_drop_message(flow, message):
            return True
        self._apply_websocket_delay(flow, message)
        self._apply_websocket_throttle(flow, message)
        self._apply_websocket_message_replace(flow, message)
        return False


def build_websocket_message_rules(settings: Mapping[str, str] | None = None) -> WebSocketMessageRuleSet:
    settings = settings or {}

    websocket_message_replace = _normalize(settings.get("websocket_message_replace"))
    websocket_drop_message_raw = _coerce_raw_rules(settings.get("websocket_drop_message"))
    websocket_fail_rate_raw = _coerce_raw_rules(settings.get("websocket_fail_rate"))
    websocket_delay_raw = _coerce_raw_rules(settings.get("websocket_delay"))
    websocket_throttle_raw = _coerce_raw_rules(settings.get("websocket_throttle"))
    compiled = WebSocketMessageRuleSet()

    if websocket_message_replace is not None:
        pattern, replacement_text = _split_once(
            websocket_message_replace,
            "=",
            "websocket-message-replace",
        )
        matcher = build_matcher(pattern)
        search, replace = _split_once(replacement_text, ">>>", "websocket-message-replace replacement")
        compiled.websocket_message_replace = (matcher, (search, replace))

    compiled.websocket_drop_message = [
        build_matcher(pattern)
        for pattern in parse_websocket_drop_message_rules(websocket_drop_message_raw)
    ]
    compiled.websocket_fail_rate = [
        (build_matcher(str(rule["pattern"])), int(rule["percent"]))
        for rule in parse_websocket_fail_rate_rules(websocket_fail_rate_raw)
    ]
    compiled.websocket_delay = [
        (build_matcher(str(rule["pattern"])), int(rule["delay_ms"]))
        for rule in parse_websocket_delay_rules(websocket_delay_raw)
    ]
    compiled.websocket_throttle = [
        (build_matcher(str(rule["pattern"])), int(rule["kbps"]))
        for rule in parse_websocket_throttle_rules(websocket_throttle_raw)
    ]

    return compiled


def load_websocket_message_config(path: str | None, profile: str | None = None) -> dict[str, str]:
    data = load_merged_config(path, profile=profile)

    result: dict[str, str] = {}
    for key in WEBSOCKET_MESSAGE_KEYS:
        value = data.get(key)
        if value is None:
            continue
        if key == "websocket_message_replace":
            if not isinstance(value, str):
                raise ValueError(f"WebSocket message config {path!r} field {key!r} must be a string")
            normalized = _normalize(value)
            if normalized is not None:
                result[key] = normalized
            continue
        if not isinstance(value, list):
            raise ValueError(f"WebSocket message config {path!r} field {key!r} must be a JSON array")
        normalized_values: list[str] = []
        for item in value:
            if not isinstance(item, str):
                raise ValueError(f"WebSocket message config {path!r} field {key!r} entries must be strings")
            normalized = _normalize(item)
            if normalized is not None:
                normalized_values.append(normalized)
        result[key] = normalized_values
    return result


def resolve_websocket_message_settings(
    *,
    config_path: str | None = None,
    config_profile: str | None = None,
    env: Mapping[str, str] | None = None,
    websocket_message_replace: str | None = None,
    websocket_drop_message=None,
    websocket_fail_rate=None,
    websocket_delay=None,
    websocket_throttle=None,
) -> dict[str, str]:
    env = env or os.environ
    resolved = load_websocket_message_config(config_path or env.get(ENV_CONFIG), profile=config_profile)

    env_websocket_message_replace = _normalize(env.get(ENV_WEBSOCKET_MESSAGE_REPLACE))
    if env_websocket_message_replace is not None:
        resolved["websocket_message_replace"] = env_websocket_message_replace
    env_websocket_drop_message = _load_json_list(env.get(ENV_WEBSOCKET_DROP_MESSAGE), ENV_WEBSOCKET_DROP_MESSAGE)
    if env_websocket_drop_message:
        resolved.setdefault("websocket_drop_message", []).extend(env_websocket_drop_message)
    env_websocket_fail_rate = _load_json_list(env.get(ENV_WEBSOCKET_FAIL_RATE), ENV_WEBSOCKET_FAIL_RATE)
    if env_websocket_fail_rate:
        resolved.setdefault("websocket_fail_rate", []).extend(env_websocket_fail_rate)
    env_websocket_delay = _load_json_list(env.get(ENV_WEBSOCKET_DELAY), ENV_WEBSOCKET_DELAY)
    if env_websocket_delay:
        resolved.setdefault("websocket_delay", []).extend(env_websocket_delay)
    env_websocket_throttle = _load_json_list(env.get(ENV_WEBSOCKET_THROTTLE), ENV_WEBSOCKET_THROTTLE)
    if env_websocket_throttle:
        resolved.setdefault("websocket_throttle", []).extend(env_websocket_throttle)

    cli_websocket_message_replace = _normalize(websocket_message_replace)
    if cli_websocket_message_replace is not None:
        resolved["websocket_message_replace"] = cli_websocket_message_replace
    if websocket_drop_message:
        resolved.setdefault("websocket_drop_message", []).extend(_coerce_raw_rules(websocket_drop_message))
    if websocket_fail_rate:
        resolved.setdefault("websocket_fail_rate", []).extend(_coerce_raw_rules(websocket_fail_rate))
    if websocket_delay:
        resolved.setdefault("websocket_delay", []).extend(_coerce_raw_rules(websocket_delay))
    if websocket_throttle:
        resolved.setdefault("websocket_throttle", []).extend(_coerce_raw_rules(websocket_throttle))

    return resolved
