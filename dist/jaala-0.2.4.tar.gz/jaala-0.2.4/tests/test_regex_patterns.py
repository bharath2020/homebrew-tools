from __future__ import annotations

import pytest

from jaala.filtering import build_matcher


def test_substring_filter_matches_case_insensitively():
    matcher = build_matcher("Api.Example")

    assert matcher is not None
    assert matcher("https://api.example.com/data") is True
    assert matcher("https://other.example.com/data") is False


def test_regex_filter_matches_case_insensitively():
    matcher = build_matcher("re:api\\.(example|test)\\.com")

    assert matcher is not None
    assert matcher("HTTPS://API.EXAMPLE.COM/V1") is True
    assert matcher("https://service.example.org") is False


def test_invalid_regex_filter_is_rejected():
    with pytest.raises(ValueError):
        build_matcher("re:[")
